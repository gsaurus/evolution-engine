#include "EffectsManager.h"
#include "GameInvariants.h"

#include "SoundEffectHeader.h"
#include "SmpAnimEffectHeader.h"
#include "Layer.h"


//#include <iostream>


AEffectHeader* EffectsManager::hitEffect = 0;



EffectsManager::EffectsManager(){
    // does nothing, at least for now
}

EffectsManager::~EffectsManager(){
    deleteAllEffects();
    // TODO: free effects data?
}

/** Load effects data, like animations and audio */
void EffectsManager::loadEffectsData() throw(IOException){
    // TODO: load some stuff on the database/AudioManager
}




void EffectsManager::addEffectToCurrentManager(AEffect* effect){
    Layer* currLayer = Layer::getCurrentLayer();
    if (currLayer!=0){
        currLayer->addEffect(effect);
    }
}



void EffectsManager::deleteAllEffects(){
    std::list<AEffect*>::iterator it;
    for(it = effects.begin() ; it!=effects.end(); ++it){
        delete *it;
    }
    effects.clear();
}


/** add the given effect to the active list */
void EffectsManager::addEffect(AEffect* effect){
    // just put it into the list
    effects.push_back(effect);
}


bool EffectsManager::update(){
    // update all effects and mark the ones that are about to die
    std::list<std::list<AEffect*>::iterator> toRemove;
    std::list<AEffect*>::iterator it;
    for(it = effects.begin() ; it!=effects.end(); ++it){
        if (!(*it)->update())
            toRemove.push_back(it);
    }

    // remove death effects
    std::list<std::list<AEffect*>::iterator>::iterator removeIt;
    for(removeIt = toRemove.begin() ; removeIt!=toRemove.end(); ++removeIt){
        effects.erase(*removeIt);
    }
    return !effects.empty();
}


void EffectsManager::display(sf::RenderTarget* target){
    // display all effects
    std::list<AEffect*>::iterator it;
    for(it = effects.begin() ; it!=effects.end(); ++it){
        (*it)->display(target);
    }
}







AEffectHeader* EffectsManager::readHeader(DataInputStream& dis, int type) throw(IOException){
    if (type == GameInvariants::FX_SOUND)
        return new SoundEffectHeader(dis);
    if (type == GameInvariants::FX_SMP_ANIM)
        return new SmpAnimEffectHeader(dis);
    //else if ...
    return 0;
}
