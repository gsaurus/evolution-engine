#include "Scene.h"

#include "AudioManager.h"

#include "DataBase.h"

#include "SmpAnimEffectHeader.h"
#include <math.h>
#include <iostream>



long Scene::clock = 0;
Scene* Scene::currentScene = 0;

int Scene::currLayerId = 0;


long Scene::getTimeSeconds() { return clock/60; }
long Scene::getClocks() { return clock; }
int Scene::getCurrLayerId(){ return currLayerId; }

int Scene::heightmap[][49] = {
    {999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999},
    {999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999},
    {999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999},
    {999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999},
    {999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999},
    {999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999},
    {999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999},
    {999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999, 999},
    {999, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 0, 0, 0, 0, 0, 0, 0, 0, -999, -999, -999, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 999},
    {999, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 0, 0, 0, 0, 0, 0, 0, 0, 0, -999, -999, -999, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 999},
    {999, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 0, 0, 0, 0, 0, 0, 0, 0, 0, -999, -999, -999, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 999},
    {999, 32, 32, 32, 32, 32, 32, 32, 32, 32, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -999, -999, -999, -999, -999, -999, -999, -999, -999, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 999},
    {999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, 0, 0, 0, 0, 0, 0, 0, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -32, -32, -32, -32, -32, -32, 999},
    {999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, 0, 0, 0, 0, 0, 0, 0, -999, -999, 0, 0, 0, 0, 0, 0, -999, -999, -999, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -32, -32, -32, -32, -32, -32, -32, 999},
    {999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, 0, 0, 0, 0, 0, 0, 0, -999, -999, 0, 0, 0, 0, 0, 0, -999, -999, -999, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -32, -32, -32, -32, -32, -32, -32, 999},
    {999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, 0, 0, 0, 0, -32, -32, -32, -32, -32, -32, -32, -32, 999},
    {999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, -999, 999},
};

int Scene::getHeight(int x, int y){
    if (x<0 || y < 0) return 999;
    int rx = x/16; int ry = y/16;
    if (rx>=49 || ry>=17) return 999;
//    std::cout << rx << "," << ry << "\t-->" << heightmap[rx][ry] << "\n";
    return heightmap[ry][rx];
}
bool Scene::validPosition(int x, int y, int currentHeight){
    return getHeight(x,y) <= currentHeight;
}


//--------------------
// -- CONSTRUCTORS --
//--------------------
Scene::Scene():AFileResolver(GameInvariants::SCENES_VERSION){
    currentScene = this;
    sceneState = 0;
}

Scene::Scene(const std::string& fileName):AFileResolver(GameInvariants::SCENES_VERSION){
    setFileName(fileName);
    currentScene = this;
    sceneState = 0;
}

void Scene::setFileName(const std::string& fileName) throw(){
    std::string tmp(GameInvariants::LEVELS_DIR); tmp += fileName;
    AFileResolver::setFileName(tmp);
}

Scene::~Scene(){
    currentScene = 0;
//    std::vector<Layer*>::iterator it1 = layers.begin();
//    for(; it1!=layers.end(); ++it1){
//        delete *it1;
//    }
}


//---------------
// -- METHODS --
//---------------


void Scene::readData(DataInputStream& dis) throw(IOException){

    // layers
    int size = dis.readInt16();
    layers.reserve(size);
    for(int i=0; i<size; ++i){
        Layer* layer = new Layer(this);
        layer->readData(dis);
        layers.push_back(layer);
    }
}



//void Scene::writeData(DataOutputStream& dos){ //throws IOException
//}


sf::Vector2i* Scene::getTarget(){
    sf::Vector2i* target = new sf::Vector2i(0,0);
    if (sceneState ==21){
        target->x = (int)car->getX();
    }else{
        std::map<AEntity*,int>::iterator it;
        for(it = scrollingEntities.begin(); it != scrollingEntities.end(); ++it) {
            // TODO: add the % component of the layer!!
            AEntity* entity = it->first;;
            target->x += (int)layers[it->second]->layer2worldX(entity->getX());
            target->y += (int)layers[it->second]->layer2worldY(entity->getZ() - entity->getY()-25);
        }
        target->x /= scrollingEntities.size();
        target->y /= scrollingEntities.size();

//        if (target->x > scrollerCenter.x - 200 && target->x < scrollerCenter.x)
//            target->x = (int)(scrollerCenter.x);
    }
    return target;
}


void Scene::updateScrollPosition(){
    sf::Vector2i* target = getTarget();
    if (scrollerCenter.x + toleratedBox.x < target->x && scrollerCenter.x < window.Right - screenAlfSize.x)
        scrollerCenter.x += std::min(scrollerSpeed.x,target->x-(scrollerCenter.x + toleratedBox.x));
    else if (scrollerCenter.x - toleratedBox.x > target->x && scrollerCenter.x > window.Left + screenAlfSize.x)
        scrollerCenter.x -= std::min(scrollerSpeed.x,(scrollerCenter.x - toleratedBox.x)-target->x);
    else if (sceneState == 23)
        sceneState = 24;

    if (scrollerCenter.y + toleratedBox.y < target->y && scrollerCenter.y < window.Bottom - screenAlfSize.y){
        scrollerCenter.y += std::min(scrollerSpeed.y,target->y-(scrollerCenter.y + toleratedBox.y));
    }else if (scrollerCenter.y - toleratedBox.y > target->y && scrollerCenter.y > window.Top + screenAlfSize.y){
        scrollerCenter.y -= std::min(scrollerSpeed.y,(scrollerCenter.y - toleratedBox.y)-target->y);
    }

//    scrollerCenter.y = (window.GetHeight()/2)-16 + 14*::pow(::cos(clock/52.f),2);
    if (scrollerCenter.x < screenAlfSize.x) scrollerCenter.x = screenAlfSize.x;
    //std::cout << target->x << ", " << target->y << "\t---> (" << scrollerCenter.x << ", " << scrollerCenter.y << ")\n";
    delete target;
}




void Scene::updateControls(){
    clock++;


//    // TODO: ######## ...SCENE SPECIFIC CODE...






    std::vector<Layer*>::iterator it;
    currLayerId = 0;
    for(it = layers.begin(); it!=layers.end(); ++it){
        (*it)->updateControls();
        ++currLayerId;
    }
}


void Scene::updateViews(){

    // TODO: ##### ...
    // if someone to move, do it
    while (!toMove.empty()){
//        std::cout << "move object\n";
        moveObjectNow();
//        std::cout << "DONE\n";
    }

//    std::cout << "update SCROLL\n";
    // Update ScrollPosition
    updateScrollPosition();
    AudioManager::clearInactiveSounds();
    AudioManager::updateListener(scrollerCenter.x, 0, scrollerCenter.y+screenAlfSize.y);
//    std::cout << "DONE\n";

//    std::cout << "update views\n";
    // Update Views
    currLayerId = 0;
    std::vector<Layer*>::iterator it;
    for(it = layers.begin(); it!=layers.end(); ++it){
        (*it)->updateViews();
        ++currLayerId;
    }

//    std::cout << "DONE\n";

}


void Scene::display(sf::RenderTarget* target){
    std::vector<Layer*>::iterator it;
    currLayerId = 0;
    for(it = layers.begin(); it!=layers.end(); ++it){
//        int oldAlfX = screenAlfSize.x;
//        int oldAlfY = screenAlfSize.y;
//        if (currLayerId == 2){
//            screenAlfSize.x = (int)(screenAlfSize.x*2);
//            screenAlfSize.y = (int)(screenAlfSize.y*2);
//        }
        (*it)->display(target);
//        screenAlfSize.x = oldAlfX;
//        screenAlfSize.y = oldAlfY;
        ++currLayerId;
    }
}


void Scene::addCharacter(CharEntity* entity, int controlKey, int layer){
    layers[layer]->addCharacter(entity,controlKey);
}

void Scene::addScrollingCharacter(CharEntity* entity, int controlKey, int layer){
    layers[layer]->addCharacter(entity,controlKey);
    scrollingEntities[entity] = layer;
}

void Scene::removeScrollingEntity(AEntity* entity){
    scrollingEntities.erase(entity);
}




// -------------------------
//  -- Window Operations --

void Scene::setScreenAlfSize(int alfWidth, int alfHeight){
    screenAlfSize.x = alfWidth;
    screenAlfSize.y = alfHeight;
}

void Scene::setToleratedBox(int alfWidth, int alfHeight){
    toleratedBox.x = alfWidth;
    toleratedBox.y = alfHeight;
}

void Scene::setWindow(int left, int top, int right, int bottom){
    window.Top = top;
    window.Bottom = bottom;
    window.Left = left;
    window.Right = right;
}

void Scene::setScrollerCenter(int x, int y){
    scrollerCenter.x = x;
    scrollerCenter.y = y;
}

void Scene::setScrollerSpeed(float xSpeed, float ySpeed){
    scrollerSpeed.x = xSpeed;
    scrollerSpeed.y = ySpeed;
}

const sf::Vector2f& Scene::getScrollerPosition(){
    return scrollerCenter;
}

const sf::Vector2i& Scene::getSreenAlfSize(){
    return screenAlfSize;
}





sf::Vector2f Scene::moveObject(AObject* obj, int targLayer){
    toMove.push_back(obj->getKey());
    this->srcLayer = Layer::getCurrentLayer();
    if (targLayer > 0 && targLayer <(int)layers.size()){
        this->trgLayer = layers[targLayer];
        float wx = srcLayer->layer2worldX(obj->getX());
        float wy = srcLayer->layer2worldY(obj->getY());
        return sf::Vector2f(
            this->trgLayer->world2layerX(wx),
            this->trgLayer->world2layerY(wy)
        );
    }else{
        trgLayer = 0;
        return sf::Vector2f(-1,-1);
    }
}


void Scene::moveObjectNow(){
    if (srcLayer->controllers.players.find(toMove.back()) == srcLayer->controllers.players.end()){
         toMove.pop_back();
         return;
    }
    AController* controller = srcLayer->controllers.players[toMove.back()];
    if (trgLayer == 0){
        if (scrollingEntities.find(controller->getEntity())!=scrollingEntities.end()){
            CharEntity* ent = static_cast<CharEntity*>(controller->getEntity());
            ent->setAnimation(GameInvariants::IN_AIR);
            ent->reborn((int)(getScrollerPosition().x-64), 200, 150);

//            std::map<UInt,AController*>::iterator it;
//            for(it = srcLayer->controllers.players.begin(); it!=srcLayer->controllers.players.end(); ++it){
//                if (it->second != 0){
//                    CharEntity* ent2 = static_cast<CharEntity*>(it->second->getEntity());
//                    if (ent2 != ent && !ent2->state->invincible){
    //                    if (ent2->getTheGrabber() != 0){
    //                        ent2->getTheGrabber()->knockDown();
    //                    }
    //                    if (ent2->getGrabbed() != 0){
    //                        ent2->knockDown();
    //                    }
    //                    ent2->state->gotHit = ent2->state->gotKnocked = true;
//                        std::cout << "knock Down\n";
//                        ent2->state->hitInfo.hits = 0;
//                        ent2->state->hitInfo.hitterState = 0;
//                        ent2->knockDown();
//                        std::cout << "DONE\n";
//                    }
//                }
//            }

        }else{
            controller = srcLayer->removeController(toMove.back());
            View* view = srcLayer->removeView(toMove.back());
            delete controller;
            delete view;
        }
    }else{
        controller = srcLayer->removeController(toMove.back());
        View* view = srcLayer->removeView(toMove.back());
        if (controller != 0){
            trgLayer->addController(controller);
        }

        if (view != 0){
            trgLayer->addView(view);
        }
    }

    toMove.pop_back();
}
