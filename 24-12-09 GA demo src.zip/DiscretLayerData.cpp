#include "DiscretLayerData.h"

#include "GameInvariants.h"
#include "DataBase.h"


// default constructor
DiscretLayerData::DiscretLayerData():ALayerData(){
    // Does nothing
}


// Destructor
DiscretLayerData::~DiscretLayerData(){
    // delete objects
    if (!objects.empty()){
        // delete objects
        std::vector<LayerObj*>::iterator it1 = objects.begin();
        for(; it1!=objects.end(); ++it1){
            delete *it1;
        }
    }
}



//-----------------------------
// ------- LOAD / SAVE -------



void DiscretLayerData::readObjects(DataInputStream& dis) throw(IOException){
    // -- read layer objects --
    // read number of objects
    int N = dis.readInt16();
    objects.reserve(N);
    // read all objects
    for(int i=0; i<N ; ++i){
        LayerObj* obj = new LayerObj(this);
        obj->readData(dis);
        objects.push_back(obj);
    }
}



void DiscretLayerData::loadData(){
    collection = DataBase::getICL(dataFilename);
}


bool DiscretLayerData::ready() const throw(){
    if (collection == 0) return false;
    return collection->isLoaded();
}


bool DiscretLayerData::applyToSprite(sf::Sprite& sprite, int index) const{
    if (collection!=0){
        const sf::Image* img = sprite.GetImage();
        if (index < 0){
            if (index <= -GameInvariants::MAX_ANIMATIONS){
                // TODO: special effects
            }else{
                // TODO: ask something about alternative animations
                const Frame& f = collection->get(anims[-index-1]->getCurrFrame());
                img = &f.getImage();
                sprite.SetCenter(f.getCM().x, f.getCM().y);
            }

        }else{
            const Frame& f = collection->get(index);
            img = &f.getImage();
            sprite.SetCenter(f.getCM().x, f.getCM().y);
        }
        sprite.SetImage(*img);
        sprite.SetSubRect(sf::IntRect(0,0,img->GetWidth(), img->GetHeight()));
        return true;
    }
    return false;
}


UInt DiscretLayerData::getNumObjects() const{
    return objects.size();
}

int DiscretLayerData::getFrameWidth(int index) const{
    return collection->get(index).getImage().GetWidth();
}
int DiscretLayerData::getFrameHeight(int index) const{
    return collection->get(index).getImage().GetHeight();
}
LayerObj* DiscretLayerData::getLayerObj(int index) const{
    return objects[index];
}
