#include "SmpAnimEffect.h"
#include "GameInvariants.h"
#include "AudioManager.h"
#include "Layer.h"

SmpAnimEffect::SmpAnimEffect(const SimpleAnimation* anim, float x, float y, float z){
    this->anim = anim;
    pos.x = x;
    pos.y = y;
    pos.z = z;
    time = currFrame = 0;
    createView();
}


SmpAnimEffect::SmpAnimEffect(const SimpleAnimation* anim){
    this->anim = anim;
    time = currFrame = 0;
}

SmpAnimEffect::~SmpAnimEffect(){
    // stop and remove view
    removeView();
}



void SmpAnimEffect::createView(){
    Layer* currLayer = Layer::getCurrentLayer();
    if (currLayer!=0)
        currLayer->addView(new View(this));
}

void SmpAnimEffect::removeView(){
    Layer* currLayer = Layer::getCurrentLayer();
    if (currLayer!=0)
        currLayer->removeView( this->getKey() );
}


void SmpAnimEffect::setPosition(float x, float y, float z){
    pos.x = x;
    pos.y = y;
    pos.z = z;
}



bool SmpAnimEffect::update(){
    if (++time >= anim->getFrameDuration(currFrame)){
        currFrame = currFrame+1;
        time = 0;
        if (currFrame >= anim->size()){
            currFrame = 0;
            removeView();
            return false;
        }
    }
    return true;
}


void SmpAnimEffect::updateSprite(sf::Sprite& sprite){
    const Frame& frame = anim->getFrame(currFrame);
    const sf::Image& img = frame.getImage();
    sprite.SetImage( img );
    sprite.SetSubRect(sf::IntRect(0,0,img.GetWidth(), img.GetHeight()));
    sprite.SetCenter( frame.getCM().x, frame.getCM().y);
    sprite.SetPosition(pos.x, pos.z - pos.y);
}



float SmpAnimEffect::getX() const{ return pos.x; }
float SmpAnimEffect::getY() const{ return pos.y; }
float SmpAnimEffect::getZ() const{ return pos.z; }
