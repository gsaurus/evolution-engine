#ifndef AOBJECT_H_INCLUDED
#define AOBJECT_H_INCLUDED

#include "TypeUtils.h"

#include "AUpdatable.h"
#include "AEntityState.h"
#include "HitInfo.h"

/**
 * Objects interface
 * things that has a 3D position
 *
 * @author Gil Costa
 */
class AObject{
    // each object has a key identification, for controllers and views adds/removals
    private:
        static UInt keyGen;
        UInt key;
    public:
        AObject();
        UInt getKey() const;
        virtual float getX() const = 0;
        virtual float getY() const = 0;
        virtual float getZ() const = 0;
        virtual void updateSprite(sf::Sprite& sprite) = 0;
};

#endif // AOBJECT_H_INCLUDED
