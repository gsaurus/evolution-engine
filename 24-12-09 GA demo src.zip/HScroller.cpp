#include "HScroller.h"

#include "GameInvariants.h"
#include "TypeUtils.h"
#include "DiscretLayerData.h"
//#include <iostream>



HScroller::HScroller(Layer* layer):
    AScroller(layer), start(0), end(0), lastXPos(-10000)
{
    UInt size = layer->data->getNumObjects();
    starts.reserve(size);
    ends.reserve(size);
    for(UInt i=0; i < size; ++i){
        starts.push_back(i);
        ends.push_back(i);
    }
    std::sort(starts.begin(), starts.end(), cmpStarts(this));
    std::sort(ends.begin(), ends.end(), cmpEnds(this));

//    std::cout << "STARTS: ";
//    for(UInt i=0; i<starts.size(); ++i)
//        std::cout << starts[i] << " ";
//    std::cout << "\n";
//
//    std::cout << "ENDS: ";
//    for(UInt i=0; i<ends.size(); ++i)
//        std::cout << ends[i] << " ";
//    std::cout << "\n";

//    organizeScroll();
}

HScroller::~HScroller(){

}

LayerObj* HScroller::getObj(int index) const{
    return (static_cast<DiscretLayerData*> (layer->data))->getLayerObj(index);
}

int HScroller::getStart(int index) const{
    return getObj(index)->getX();
}

int HScroller::getEnd(int index) const{
    const LayerObj* obj = getObj(index);
//    layer->data->collection->get(obj->frameIndex);
    int res = obj->getX() + layer->data->getFrameWidth(obj->frameIndex);
    return res;
}




void HScroller::restartScroll(){
    objBuffer.clear();
    // treath start:
    start = 0;
    while(start < starts.size()-1 && getStart(starts[++start]) < layer->screenXEnd()){
        if (getEnd(starts[start]) > layer->screenXStart())  // if intersects screen
            objBuffer.insert(starts[start]);                // add to buffer
    }

    // treath end:
    end = ends.size();
    while(end > 0 && getEnd(ends[--end]) > layer->screenXStart()){
        if (getStart(ends[end]) < layer->screenXEnd())  // if intersects screen
            objBuffer.insert(ends[end]);                // add to buffer
    }

    // TODO: now, add more objects for tiling
//    std::cout << "scroll restarted\n";
}



void HScroller::organizeScroll(){

    int differenceX = lastXPos - (int)(layer->scene->scrollerCenter.x);

    // if didn't move, exit;
    if (differenceX == 0) return;

    // store new position
    lastXPos = (int)(layer->scene->scrollerCenter.x);

    // if the change is too big, remake the scroller positionings with full iteration
    if (::abs(differenceX)>=layer->scene->screenAlfSize.x){
        restartScroll();
        return;
    }


    UInt size = ends.size();
    UInt count = 0;

    // -- Scroll moved left or right, treat new enterigns and exitings --
    if (differenceX > 0){   // -- if moved to left --
        // remove all right exiting objects
        while(count != size && getStart(starts[start]) > layer->screenXEnd()){
            objBuffer.erase(starts[start]);     // remove from buffer
            start = (start-1)%starts.size();    // move index
            ++count;
        }

        // add all left entering objects
        count = 0;
        while(count != size && getEnd(ends[end]) > layer->screenXStart()){
            objBuffer.insert(ends[end]);    // add to buffer
            end = (end-1)%ends.size();      // move index
            ++count;
        }
    }else{ // -- moved to right --
        // remove all left exiting objects
        while(count != size && getEnd(ends[end]) < layer->screenXStart()){
            objBuffer.erase(ends[end]);     // remove from buffer
            end = (end+1)%ends.size();      // move index
            ++count;
        }
        // add all right entering objects
        count = 0;
        while(count != size && getStart(starts[start]) < layer->screenXEnd()){
            objBuffer.insert(starts[start]);       // add to buffer
            start = (start+1)%starts.size();    // move index
            ++count;
        }
    }

    // TODO: now, add more objects for tiling
}


void HScroller::display(sf::RenderTarget* target){
    // before draw, test/make changes
    organizeScroll();

    // TODO: calc new positions when tiling

    // draw all objects
    std::set<int>::iterator it;
    for(it = objBuffer.begin(); it != objBuffer.end(); ++it){
        getObj(*it)->display(target);
    }

}


