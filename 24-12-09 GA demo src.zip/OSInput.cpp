#include "OSInput.h"



// ---------------------------
// -- setting configuration --

void OSInput::setWindow(sf::Window* app){
    OSInput::app = app;
}

void OSInput::setKeyboardListening(bool listen){
    hasKeyboard = listen;
}

void OSInput::setJoystickListening(bool listen){
    hasJoystick = listen;
}
void OSInput::clearEvents(){
    keyButsWaiting.clear();
    joyButsWaiting.clear();
}



// --------------------
// -- getting events --

std::list<OSInput::KeyBut>::iterator OSInput::keyButsBegin(){
    return keyButsWaiting.begin();
}
std::list<OSInput::JoyBut>::iterator OSInput::joyButsBegin(){
    return joyButsWaiting.begin();
}
std::list<OSInput::KeyBut>::iterator OSInput::keyButsEnd(){
    return keyButsWaiting.end();
}
std::list<OSInput::JoyBut>::iterator OSInput::joyButsEnd(){
    return joyButsWaiting.end();
}

void OSInput::removeKeyBut(std::list<KeyBut>::iterator it){
    keyButsWaiting.erase(it);
}
void OSInput::removeJoyBut(std::list<JoyBut>::iterator it){
    joyButsWaiting.erase(it);
}


// ----------------------
// -- listening events --

bool OSInput::listeningEvents(){
    if (app == 0) return false;
    sf::Event e;
    while (app->GetEvent(e)){
        if (e.Type == sf::Event::Closed)
            return false;
        // -- keyboard press/release --
        if (hasKeyboard){
            if (e.Type == sf::Event::KeyPressed){
                OSInput::KeyBut but;
                but.code = e.Key.Code;
                but.pressed = true;
                OSInput::keyButsWaiting.push_back(but);
                continue;
            }else if (e.Type == sf::Event::KeyReleased){
                OSInput::KeyBut but;
                but.code = e.Key.Code;
                but.pressed = false;
                OSInput::keyButsWaiting.push_back(but);
                continue;
            }
        }
        // -- joystick press/release --
        if (hasJoystick){
            if (e.Type == sf::Event::JoyButtonPressed){
                OSInput::JoyBut but;
                but.joyId = e.JoyButton.JoystickId;
                but.button = e.JoyButton.Button;
                but.pressed = true;
                joyButsWaiting.push_back(but);
                continue;
            }else if (e.Type == sf::Event::JoyButtonReleased){
                OSInput::JoyBut but;
                but.joyId = e.JoyButton.JoystickId;
                but.button = e.JoyButton.Button;
                but.pressed = false;
                joyButsWaiting.push_back(but);
                continue;
            }
        }
    }
    return true;
}


