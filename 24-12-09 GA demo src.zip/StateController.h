#ifndef STATE_CONTROLLER_H_INCLUDED
#define STATE_CONTROLLER_H_INCLUDED

#include <vector>

/**
 * Controls the game states:
 *    - save state
 *    - load state
 *    - states stack
 *    - ...
 *
 * @author Gil Costa
 */
class StateController{
    UInt nextRandIndex;
};

#endif // STATE_CONTROLLER_H_INCLUDED
