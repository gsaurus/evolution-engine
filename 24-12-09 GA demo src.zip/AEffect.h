#ifndef AEFFECT_H_INCLUDED
#define AEFFECT_H_INCLUDED

#include "AUpdateAndDisplay.h"

class AEffect: public AUpdateAndDisplay{
 public:
    virtual void setPosition(float x, float y, float z) = 0;

    // note: update should return false when the effect [is inactive, and] should be removed

    virtual void display(sf::RenderTarget* target){
        // does nothing by default
    }

    virtual bool update() = 0;

};

#endif // AEFFECT_H_INCLUDED
