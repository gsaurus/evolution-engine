#ifndef LAYER_OBJ_H_INCLUDED
#define LAYER_OBJ_H_INCLUDED


#include "AReadable.h"
#include "ADisplayable.h"
#include "FramesCollection.h"
#include "ALayerData.h"
#include <SFML/Graphics.hpp>


class ALayerData;
/**
 * Layer Object
 * @see AReadable.h
 *
 * @author Gil Costa
 */
class LayerObj: public AReadable, ADisplayable{
    public:
        //--------------
        // -- FIELDS --
        //--------------

        // -- Readable Data --
        int frameIndex;     // int16
        std::vector<UByte> alternativeAnims;
        int parameters;


        // -- in game data --
        const ALayerData* data;
        sf::Sprite sprite;

        //--------------------
        // -- CONSTRUCTORS --
        //--------------------
        /** default constructor */
        LayerObj(const ALayerData* data);
        /** destructor */
        ~LayerObj();


        //---------------
        // -- METHODS --
        //---------------


        void readData(DataInputStream& dis) throw(IOException);
        //void writeData(DataOutputStream& dos);

        int getX() const;
        int getY() const;

        void setPosition(int x, int y);

        void display(sf::RenderTarget* target);
        void display(sf::RenderTarget* target, const sf::Vector2i& offset);

};

#endif // LAYER_OBJ_H_INCLUDED
