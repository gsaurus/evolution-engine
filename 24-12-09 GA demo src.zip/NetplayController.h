#ifndef NETPLAY_CONTROLLER_H_INCLUDED
#define NETPLAY_CONTROLLER_H_INCLUDED


#include "AController.h"


/**
 * Input data comes from network sockets
 *
 * @author ?
 */
//TODO

#endif // NETPLAY_CONTROLLER_H_INCLUDED
