#include "ControlsMapper.h"
#include "KeyboardController.h"
#include "AITrivialController.h"
#include "AITrivialFighter.h"
#include "AIFFBongo.h"
#include "AISor1Electra.h"
#include "AISor1Haku.h"
#include "AISor1Signal.h"

AController* ControlsMapper::getController(AControlledEntity* entity, int ctrlKey){
    switch (ctrlKey){
        case -1:{
            KeyboardController* res = new KeyboardController(entity);
            res->setKeys(
                sf::Key::Up,
                sf::Key::Down,
                sf::Key::Left,
                sf::Key::Right,
                sf::Key::Z,
                sf::Key::X,
                sf::Key::C,
                sf::Key::N,
                sf::Key::B,
                sf::Key::Num0,
                sf::Key::Return,
                sf::Key::V
            );
            return res;
        break;
        }

        case -2:{
            KeyboardController* res = new KeyboardController(entity);
            res->setKeys(
                sf::Key::I,
                sf::Key::K,
                sf::Key::J,
                sf::Key::L,
                sf::Key::Q,
                sf::Key::W,
                sf::Key::E,
                sf::Key::D,
                sf::Key::S,
                sf::Key::Num0,
                sf::Key::Space,
                sf::Key::A
            );
            return res;
        break;
        }

        case -3:{
            KeyboardController* res = new KeyboardController(entity);
            res->setKeys(
                sf::Key::T,
                sf::Key::G,
                sf::Key::F,
                sf::Key::H,
                sf::Key::Num1,
                sf::Key::Num2,
                sf::Key::Num3,
                sf::Key::Num4,
                sf::Key::Num5,
                sf::Key::Dash,
                sf::Key::Space,
                sf::Key::A
            );
            return res;
        break;
        }


        case 0: return new AITrivialController(entity);
        case 1: return new AITrivialFighter(entity);
        case 2: return new AIFFBongo(entity);
        case 3: return new AISor1Electra(entity);
        case 4: return new AISor1Haku(entity);
        case 5: return new AISor1Signal(entity);

        default:
            return new AITrivialController(entity);
    }

}
