#include "AEntity.h"

//AEntity::AEntity()::AObject(){}

AEntity::~AEntity(){
    // Do nothing
}


//void AEntity::setActive(bool active){
//    state.active = active;
//}

//const AEntityState* AEntity::getState() const{
//    return lastState;
//}

//void AEntity::update(){
//    // finish the state
//    lastState.copyFrom(state);
//}


UInt AEntity::beingHit(const HitInfo& hitInfo){
    return 0;   // No hit by default
}


bool AEntity::testGrab(AEntity* other){ return false; }
