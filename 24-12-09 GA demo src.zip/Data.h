#ifndef DATA_H_INCLUDED
#define DATA_H_INCLUDED

#include "TypeUtils.h"

/**
 * dinamic byte array with associated lenght
 *
 * @author Gil Costa
 */
class Data{
    protected:
        char* array;
        UInt lenght;
    public:
        // -- constructors --
        Data(UInt size);
        Data(const char* data, UInt size);
        Data(const Data& other);
        // -- destructor --
        virtual ~Data();

        // indexing operator
        char& operator[](UInt index);

        UInt size() const throw();
        char* getData() const throw();

        void clean() throw();

};

#endif // DATA_H_INCLUDED
