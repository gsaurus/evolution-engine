#ifndef AI_SOR1_ELECTRA_H_INCLUDED
#define AI_SOR1_ELECTRA_H_INCLUDED


#include "AITrivialController.h"


/**
 * Control by keyboard input
 * it comes from system events (OSInput)
 *
 * @author Gil Costa
 */
class AISor1Electra: public AITrivialController{
    protected:

    public:
        AISor1Electra();
        AISor1Electra(AControlledEntity* entity);

        void applyKeys();

};

#endif // AI_SOR1_ELECTRA_H_INCLUDED

