#ifndef AI_TRIVIAL_FIGHTER_H_INCLUDED
#define AI_TRIVIAL_FIGHTER_H_INCLUDED


#include "AITrivialController.h"


/**
 * Control by keyboard input
 * it comes from system events (OSInput)
 *
 * @author Gil Costa
 */
class AITrivialFighter: public AITrivialController{
    protected:

    public:
        AITrivialFighter();
        AITrivialFighter(AControlledEntity* entity);

        void applyKeys();

};

#endif // AI_TRIVIAL_FIGHTER_H_INCLUDED

