#include "CharEntity.h"
#include "AudioManager.h"
#include "EffectsManager.h"

#include "Scene.h"

#include <math.h>
#include <iostream>





CharEntity::CharEntity():
    AControlledEntity(), state(0),lastState(0),
    currentSound(-1), soundKey(-1), lastFrame(-1), lastAnimation(-1)
{
    // Does nothing
}


//void CharEntity::copyTo(CharEntity& other){
//    if (other.state != 0) delete other.state;
//    if (other.lastState != 0) delete other.lastState;
//    other.state = new CharState(state);
//    other.lastState = new CharState(lastState);
//}

//void CharEntity::reload(){
//    charHeader->load();
//    this->charObj = charHeader->charObj;
//    this->bodyObj = charHeader->bodyObj;
//    this->headObj = charHeader->headObj;
//    if (nameIndex < charObj->names.size()) this->name = &charObj->names.at(nameIndex);
//    else name = 0;
//    // set animation and position states
//    this->SetPosition(pos.x,pos.y-pos.z);
//    currentAnim = charObj->animSet.get(currAnimIndex);
//    setFrame(currentAnim->fixedFrames[currentFrame]);
//}



void CharEntity::initialize(const Character* charObj, CharacterHeader* charHeader, const FramesCollection* bodyObj, const FramesCollection* headObj,
                            UInt name, UInt energy, IntVector3D startPos, UInt anim)
{
    if (state != 0) delete state;
    state = new CharState();
    state->charObj = charObj;
    state->charHeader = charHeader;
    state->bodyObj = bodyObj;
    state->headObj = headObj;
    if (name < charObj->names.size()) state->name = &charObj->names.at(name);
    else state->name = 0;
    state->nameIndex = name;
    state->maxEnergy = energy;
    state->energy = energy;
    state->pos.x = startPos.x;
    state->pos.y = startPos.y;
    state->pos.z = startPos.z;
    state->airPlayerVelX = 0;
    state->airPlayerVelZ = 0;
    state->blockHitTime = 0;
    state->attackWaitTolerance = 0;
    state->gotKnocked = state->gotHit = false;

    state->active = false;
    state->invincible = false;
    state->facedLeft = false;
    state->beingThrown = false;
    state->running = false;

    stopAll();
    setAnimation(anim);

    if (lastState != 0) delete lastState;
    lastState = new CharState(*state);

    currentSound = soundKey = lastFrame = lastAnimation = -1;

    // ####### SCENE SPECIFIC ########
    int sound = (int)(::round(state->charObj->runJumpVel*GameInvariants::VEL_DIVIDER));

//    std::cout << sound << "!!!!\n";
    AudioManager::loadSpecificSound(sound);
//    if (sound == 9)
//        AudioManager::loadSpecificSound(10);
}


void CharEntity::setCenter(int x, int y){
    state->center.x = x;
    state->center.y = y;
}

void CharEntity::setRotation(float rotation){
    state->rotation = rotation;
}



void CharEntity::setFrame(FixedFrame* f){
    int index = f->frameIndex;
    const sf::Image& img = state->bodyObj->get(index).getImage();

    if (state->beingThrown){
        // being thrown, base point on image center
        this->setCenter(img.GetWidth()/2, img.GetHeight()/2);
    }else{
        // change base point
        const Point16& pt = state->bodyObj->get(index).getCM();
        // if fliped, flip the center
        if (state->facedLeft) this->setCenter(img.GetWidth()-pt.x,pt.y);
        else this->setCenter(pt.x,pt.y);

        // grabbing someone, control it's position
        if (state->grabbedOne != 0){
            if (f->grab!=0){
                // set it's position
                // TODO: add y? (z??)
                if (state->facedLeft) state->grabbedOne->state->pos.x = state->pos.x - f->grab->x;
                else state->grabbedOne->state->pos.x = state->pos.x + f->grab->x;
                // set y & z
                state->grabbedOne->state->pos.z = state->pos.z-1;   // to be shown behind? TODO?
                state->grabbedOne->state->pos.y = state->pos.y - f->grab->y;
                // set it's animation
                if (state->grabbedOne->getCurrentAnimIndex() != f->grab->anim
                    && state->grabbedOne->getCurrentAnimIndex() != GameInvariants::BEING_BACK_GRABBED_DEFENCE){
                    state->grabbedOne->setAnimation(f->grab->anim);
                    state->grabbedOne->reloadCurrentFrame();
                }
                if (state->facedLeft)
                    state->grabbedOne->setRotation(360-f->grab->angle);
                else state->grabbedOne->setRotation(f->grab->angle);
            }
            else{
                unGrab();
            }
        }
    }
}



void CharEntity::updateGrabbedPosition(){
    const FixedFrame* f = state->currentAnim->fixedFrames[state->currentFrame];
    if (f->grab!=0){
        // set it's position
        if (state->facedLeft) state->grabbedOne->state->pos.x = state->pos.x - f->grab->x;
        else state->grabbedOne->state->pos.x = state->pos.x + f->grab->x;
        state->grabbedOne->state->pos.z = state->pos.z-2;   // to show it behind?
        state->grabbedOne->state->pos.y = state->pos.y - f->grab->y;
    }
    else unGrab();
}


//void CharEntity::updatePositionFromTheGrabber(){
//    CharState* otherState = state->theGrabber->lastState;
//    const FixedFrame* f = otherState->currentAnim->fixedFrames[otherState->currentFrame];
//    if (f->grab!=0){
//        // set it's position
//        if (otherState->facedLeft) state->pos.x = otherState->pos.x - f->grab->x;
//        else state->pos.x = otherState->pos.x + f->grab->x;
//        state->pos.z = otherState->pos.z-1;   // to show it behind?
//        state->pos.y = otherState->pos.y - f->grab->y;
//    }
//    else unGrab();
//}




// ----------------------------
//  --------- UPDATE ---------
// ----------------------------



bool CharEntity::updateState(){
//    std::cout << "clock: " << Scene::getClocks() << "\n";
    if (state->currentAnim == 0 || state->bodyObj == 0) return false;
    int dura;   // frame duration
    if (state->currentFrame<0)
        dura = -1;
    else{
        const FixedFrame* f = state->currentAnim->fixedFrames[state->currentFrame];
        dura = ( f!=0 ? (int)f->duration : -1 );
    }
    bool frameChanged = ++(state->animTimer) >= dura;
    if (frameChanged){
        if (state->hitPause > GameInvariants::GRAB_PAUSE)
            state->hitPause = GameInvariants::GRAB_PAUSE;    // reset hitting pause // TODO: weird, before this it was missing 1 clock frames
        state->animTimer = 0;  // reset timer
        ++(state->currentFrame); // next frame
        // end animation, send message and loop animation if the answer is false
        if (state->currentFrame==(int)state->currentAnim->fixedFrames.size()){
            // has end position changing?
            if (state->currentAnim->endPosition!=0){
                if (state->facedLeft){
                    if (Scene::validPosition((int)(state->pos.x - state->currentAnim->endPosition->getX()),(int)(state->pos.z),(int)(state->pos.y)))
                        state->pos.x -= state->currentAnim->endPosition->getX();
                }else{
                    if (Scene::validPosition((int)(state->pos.x + state->currentAnim->endPosition->getX()),(int)(state->pos.z),(int)(state->pos.y)))
                        state->pos.x += state->currentAnim->endPosition->getX();
                }
                if (Scene::validPosition((int)(state->pos.x), (int)(state->pos.z + state->currentAnim->endPosition->getZ()),(int)(state->pos.y)))
                    state->pos.z += state->currentAnim->endPosition->getZ();
                if (state->currentAnim->endFlip){
                    faceLeft(!state->facedLeft);
                }

                if (Scene::validPosition((int)(state->pos.x), (int)(state->pos.z),(int)(state->pos.y + state->currentAnim->endPosition->getY())))
                state->pos.y += state->currentAnim->endPosition->getY();
            }
            // test if the animation breaks
            if (animationBreak()) return true;
            state->currentFrame = 0;   // if no break, loop
        }
        setFrame(state->currentAnim->fixedFrames[state->currentFrame]);

        // Test if is a KeyFrame
        if (state->currentAnim->keyFrames.containsKey(state->currentFrame)){
            const KeyFrame* kf = state->currentAnim->keyFrames.get(state->currentFrame);
            // Character Impulse
            if (kf->impulse != 0 && kf->impulse->x != KeyFrame::INVALID_VEL){
                if (kf->impulse->x != KeyFrame::NO_CHANGE_VEL){
                    // if it's faced left, the x speed is contrary
                    state->velocity.x = (state->facedLeft ? -kf->impulse->x : kf->impulse->x );
                }
                if (kf->impulse->y != KeyFrame::NO_CHANGE_VEL)
                    state->velocity.y = kf->impulse->y;
                if (kf->impulse->z != KeyFrame::NO_CHANGE_VEL)
                    state->velocity.z = kf->impulse->z;
            }
        }
    }
//    float oldZ = state->getZ();

    updatePosition();
    if (state->grabbedOne!=0) updateGrabbedPosition();

//    // TODO: ######## SCENE SPECIFIC



    return frameChanged;
}


void CharEntity::updatePlayerVelComponent(float& posComp, float& airVel, bool negative, bool vertical){
    float delta;
    // set the component correctly
    if (vertical){
        if (state->velocity.x!=0){
            float mod = ::fabs(state->velocity.x);
            delta = std::min(state->charObj->walkVel*GameInvariants::VERTICAL_VEL_FACTOR,mod*GameInvariants::VERTICAL_VEL_FACTOR);
        }else delta = state->charObj->walkVel*GameInvariants::VERTICAL_VEL_FACTOR;
    }else delta = state->charObj->walkVel;

    if (state->pos.y <= Scene::getHeight((int)(state->pos.x), (int)(state->pos.z))){
        if (negative) posComp-=delta;
        else posComp+=delta;
    }else{
        delta = (state->running? (state->charObj->runJumpVel*2.2) : state->charObj->jumpVel);
        if (vertical) airVel*=GameInvariants::VERTICAL_VEL_FACTOR;
        if (negative) airVel-=GameInvariants::AIR_CONTROL; //GameInvariants::AIR_CONTROL*delta;
        else airVel+=GameInvariants::AIR_CONTROL; //GameInvariants::AIR_CONTROL*delta;
        if (airVel > 0){
            if (airVel > delta) airVel = delta;
        }else if (airVel < -delta) airVel = -delta;
        posComp += airVel;
    }
}


// Control walk, jump and other animations that allows horizontal and/or vertical user ment
void CharEntity::updatePlayerVelocity(){
    // Horizontally (X)
    if (state->currentAnim->allowH){
        if (state->movingLeft || state->movingRight){
            float newX = state->pos.x;
            updatePlayerVelComponent(newX, state->airPlayerVelX, state->movingLeft);
            if (Scene::validPosition((int)newX,(int)(state->pos.z),(int)(state->pos.y)))
                state->pos.x = newX;
        }
        else if (state->pos.y != Scene::getHeight((int)(state->pos.x), (int)(state->pos.z)) && state->airPlayerVelX!=0){
            if (Scene::validPosition((int)(state->pos.x + state->airPlayerVelX),(int)(state->pos.z),(int)(state->pos.y)))
                state->pos.x += state->airPlayerVelX;
        }
    }
    // Vertically (Z)
    if (state->currentAnim->allowV){
        if(state->movingUp || state->movingDown){
            float newZ = state->pos.z;
            updatePlayerVelComponent(newZ, state->airPlayerVelZ, state->movingUp, true);
            if (Scene::validPosition((int)(state->pos.x),(int)newZ,(int)(state->pos.y)))
                state->pos.z = newZ;

        }
        else if (state->pos.y != Scene::getHeight((int)(state->pos.x), (int)(state->pos.z)) && state->airPlayerVelZ!=0)
            if (Scene::validPosition((int)(state->pos.x), (int)(state->pos.z + state->airPlayerVelZ),(int)(state->pos.y)))
                state->pos.z += state->airPlayerVelZ;
    }
    if (state->currentAnim->allowFlip && (state->movingLeft || state->movingRight))
        if (faceLeft(state->movingLeft))
            state->theHittenOnes.clear();   // TODO: this only to simulate sor1 bug
}



void CharEntity::updatePosition(){
    if (state->pos.y < -200){
        if (state->energy > 0){
            state->energy = -1;
            testDying();
        }
//        setAnimation(GameInvariants::DYING);
        Scene::currentScene->moveObject(this,-1);
    }
    // do not update position if being grabbed
    if (state->theGrabber==0){
//        std::cout << "VEL: x = "<< state->velocity.x << "\n"; //<< ", y =" << state->pos.y << ", z =" << state->pos.z << "\n";
        // state->velocity control
        float nextX = state->pos.x+state->velocity.x;
        float nextZ = state->pos.z+state->velocity.z;
        if (Scene::validPosition((int)nextX,(int)nextZ,(int)state->pos.y)){
            state->pos.x=nextX;
            state->pos.z=nextZ;
        }
//        else if (Scene::validPosition((int)(state->pos.x),(int)nextZ,(int)(state->pos.y))){
//            state->pos.z=nextZ;
//        }else if (Scene::validPosition((int)nextX,(int)(state->pos.z),(int)(state->pos.y))){
//            state->pos.x=nextX;
//        }

        int height = Scene::getHeight((int)(state->pos.x),(int)(state->pos.z));
//        std::cout << height << "!!!!\n";

        // don't update y if not needed
        if (state->pos.y>height || state->velocity.y>0) state->pos.y+=state->velocity.y;
        // player movement control (x & y only)
        updatePlayerVelocity();
        // vertical gravity control
        // TODO: different to when being thrown
        // test floor colision
        if (state->pos.y<height){
            state->pos.y = height;
            state->velocity.y = 0;
            // reset vel control
            state->airPlayerVelX = 0;
            state->airPlayerVelZ = 0;
            animationBreak();
        }else if (state->pos.y>height){
            if (    state->theGrabber == 0 &&
                getCurrentAnimIndex()!= GameInvariants::IN_AIR &&
                getCurrentAnimIndex()!= GameInvariants::JUMP &&
                getCurrentAnimIndex()!= GameInvariants::JUMP_DOWN_ATTACK &&
                getCurrentAnimIndex()!= GameInvariants::JUMP_MOVE_ATTACK &&
                getCurrentAnimIndex()!= GameInvariants::RUN_JUMP &&
                getCurrentAnimIndex()!= GameInvariants::JUMP_RUN_ATTACK &&
                getCurrentAnimIndex()!= GameInvariants::BEING_KNOCKED &&
                getCurrentAnimIndex()!= GameInvariants::BEING_THROWN &&
                getCurrentAnimIndex()!= GameInvariants::GROUND_BOUNCING &&
                getCurrentAnimIndex()!= GameInvariants::DYING &&
                getCurrentAnimIndex()!= GameInvariants::RUN_ATTACK_STAR_0
            ){
                setAnimation(GameInvariants::IN_AIR);
            }
//            std::cout << "b\n";
            state->velocity.y+=GameInvariants::GRAVITY;
        }
        if (state->rotationalVel!=0) this->setRotation(state->rotation+state->rotationalVel);
    }
//    else // update accordingly to the grabber position:
//        updatePositionFromTheGrabber();

    // finally update
    //renderPosition();
}


//void CharEntity::renderPosition(){
//    SetPosition(pos.x, pos.y-pos.z);
//}

void CharEntity::resetSpeed(){
    // reset, only on x and z
    state->velocity.x = state->velocity.z = 0;
    // and rotation too
    state->rotationalVel = 0;
}



bool CharEntity::setAnimation(UInt anim){
    this->setRotation(0);
    // filter invalid animations
    if (state->charObj == 0 || !hasAnimation(anim)
        || (state->charObj->animSet.get(anim)->onlyYUp && state->velocity.y < 0)
        || (state->charObj->animSet.get(anim)->onlyYDown && state->velocity.y > GameInvariants::FALLING_LIMIAR)
    ){
        //if (controller!=0) controller->animationBreak();
        return false;
    }
    state->currAnimIndex = anim;
    state->currentAnim = state->charObj->animSet.get(anim);
    state->currentFrame = -1;  // to be updated in update()
    state->animTimer = 0;
    if (state->recoverTime<=0)
        state->invincible = state->currentAnim->invinsible;
    if (!state->beingThrown)
        resetSpeed();
    updateState();
    // set the first frame
    //setFrame(currentAnim->fixedFrames[0]);
    return true;
}


void CharEntity::grab(CharEntity* other, bool fromBack){
    state->grabbedOne = other;
    if (other != 0){
        state->grabbingOnBack = fromBack;
        other->state->theGrabber = this;
        other->state->grabbedBack = fromBack;
        other->stopAll();
    }
}


void CharEntity::unGrab(){
    if (state->grabbedOne==0) return;
    state->grabbedOne->state->theGrabber = 0;
    state->grabbedOne->breakAnim();
    state->grabbedOne = 0;
    state->attackNum = 0;
}


void CharEntity::knockDown(){
    if (getCurrentAnimIndex() == GameInvariants::DYING || getCurrentAnimIndex() == GameInvariants::BEING_THROWN || getCurrentAnimIndex() == GameInvariants::BEING_KNOCKED) return;
    // if grabbed, ungrab imediactly
//    std::cout << "1\n";
    if (state->theGrabber!=0){
        CharEntity* grabber = state->theGrabber;
        state->theGrabber->unGrab();
        // only break anim if the grabber isn't knock attacking it
        if (state->hitInfo.hitterState != grabber->lastState)
            grabber->breakAnim();
    }
//    std::cout << "2\n";
    setAnimation(GameInvariants::BEING_KNOCKED);
    state->velocity.x = GameInvariants::KNOKED_X_VEL;  // TODO: add random
    state->velocity.y = GameInvariants::KNOKED_Y_VEL;
    // look at the hit information
//    std::cout << "3\n";
    if (state->hitInfo.hitterState!=0){
        //face to the hitter
        faceLeft(state->hitInfo.fromLeft);
//        std::cout << "4\n";
//        std::cout << " first " << ((state->hitInfo.hits==0)? "it's null":"the prob is other") << "\n";
//        std::cout << " -> " << ((state->hitInfo.hits->sparseKnock)? "yes":"no") << "\n";
        if (state->hitInfo.hits->sparseKnock){
//            std::cout << "5\n";
            // it's a sparse knock, throw the character away
            double angle = angleBetween(state->hitInfo.hitterState->pos.x, state->hitInfo.hitterState->pos.z,state->pos.x,state->pos.z);
            state->velocity.z = (::sin(angle)*state->velocity.x)/2;
            state->velocity.x*= ::cos(angle);
//            std::cout << "6\n";
        }else{
            if (!state->facedLeft) state->velocity.x*=-1;
        }
    }
//    std::cout << "DONE\n";

}


void CharEntity::breakAnim(){
    state->currentFrame = state->currentAnim->fixedFrames.size()-1;
    animationBreak();
}



void CharEntity::beThrown(const HitFrame* throwInfo){
    const sf::Image& img = getCurrentImage();
    int cX = img.GetWidth()/2;
    int cY = img.GetHeight()/2;
    float dx = state->center.x - cX;
    float dy = state->center.y - cY;
    float angle = ::toRadians(state->rotation);

    rotate(dx,dy,angle);

    state->pos.x+=dx;
    state->pos.y+=dy;
    this->setCenter(cX,cY);
    state->velocity.x = throwInfo->throwImpulse->x;
    state->velocity.y = throwInfo->throwImpulse->y;
    state->velocity.z = throwInfo->throwImpulse->z;
    state->rotationalVel = throwInfo->throwRot;
    if (state->theGrabber!=0 && state->theGrabber->isFacedLeft()){
        state->velocity.x*=-1;
        state->rotationalVel*=-1;
    }
    state->beingThrown = true;
    state->invincible = true;
    state->waitingDamage = throwInfo->throwDamage;
//    std::cout << state->waitingDamage << " it is\n";
}

void CharEntity::setBeingThrown(bool thrown){
    state->beingThrown = thrown;
}


bool CharEntity::isBeingThrown() const{ return state->beingThrown; }
//bool CharEntity::isBeingKnocked() const{ return beingKnocked; }

UInt CharEntity::getCurrentAnimIndex() const{ return state->currAnimIndex; }
UInt CharEntity::getCurrentAnimFrame() const{ return state->currentFrame; }
UInt CharEntity::getAnimTotalFrames() const{ return state->currentAnim->fixedFrames.size(); }

UInt CharEntity::getRotation() const{ return (UInt)state->rotation; }


const sf::Image& CharEntity::getCurrentImage() const{
    return state->getCurrentImage();
}


void CharEntity::reloadCurrentFrame(){
    if (state->currentFrame>=0 && state->currentFrame < (int)(state->currentAnim->fixedFrames.size()))
        setFrame(state->currentAnim->fixedFrames[state->currentFrame]);
    else setFrame(state->currentAnim->fixedFrames[0]);
}


bool CharEntity::faceLeft(bool faceLeft){
    if (state->facedLeft == faceLeft || state->currentAnim==0) return false;  // same way, does nothing
    state->facedLeft = faceLeft;
    if (state->currentFrame>=0 && state->currentFrame<(int)state->currentAnim->fixedFrames.size())
        setFrame(state->currentAnim->fixedFrames[state->currentFrame]);
    return true;
}

//void CharEntity::setAirVelX(float airvel){
//    if (state->movingLeft || state->movingRight || state->running)
//        state->airPlayerVelX = airvel;
//    else state->airPlayerVelX = 0;
//}
//
//void CharEntity::setAirVelZ(float airvel){
//    if (state->movingUp || state->movingDown)
//        state->airPlayerVelZ = airvel;
//    else state->airPlayerVelZ = 0;
//}

// Player movement control
void CharEntity::moveLeft(bool move){
    state->movingLeft = move;
}
void CharEntity::moveRight(bool move){
    state->movingRight = move;
}
void CharEntity::moveUp(bool move){
    state->movingUp = move;
}
void CharEntity::moveDown(bool move){
    state->movingDown = move;
}
void CharEntity::run(bool runMove){
    state->running = runMove;
    // just in case of a jump, set the airVel to it's current vel
//    setAirVelX();
}

bool CharEntity::isRunning() const{ return state->running; }
bool CharEntity::isFacedLeft() const{ return state->facedLeft; }
bool CharEntity::isInAir() const{ return state->pos.y>Scene::getHeight((int)(state->pos.x), (int)(state->pos.z)); }
bool CharEntity::isMovingLeft() const { return state->movingLeft; }
bool CharEntity::isMovingRight() const { return state->movingRight; }
bool CharEntity::isMovingUp() const { return state->movingUp; }
bool CharEntity::isMovingDown() const { return state->movingDown; }
bool CharEntity::isStaticJumping() const{
    return state->airPlayerVelX == 0 && state->airPlayerVelZ == 0;
}
bool CharEntity::isInvincibleAnimPlaying() const{ return state->currentAnim->invinsible; }
bool CharEntity::isOnBlockingMove() const{
    return state->currentAnim->block;
}
bool CharEntity::attackedFromBack() const{
    return state->hitInfo.fromLeft != state->facedLeft;
}
void CharEntity::faceToHitter(){
//    faceLeft(state->hitInfo.fromLeft);
    faceLeft(!state->hitInfo.hitterState->isFacedLeft());
}


/** stop all player movement */
void CharEntity::stopAll(){
    state->movingLeft = state->movingRight = state->movingUp = state->movingDown = false;
}


bool CharEntity::animationEnded() const{
    return state->currentFrame>=(int)state->currentAnim->fixedFrames.size()-1;
}

CharEntity* CharEntity::getGrabbed() const{ return state->grabbedOne; }
CharEntity* CharEntity::getTheGrabber() const{ return state->theGrabber; }
bool CharEntity::isBeingBackGrabbed() const{ return state->grabbedBack; }
bool CharEntity::isGrabbingOnBack() const{ return state->grabbingOnBack; }


const IntVector3D* CharEntity::getEndPosition() const{
    if (state->currentAnim == 0) return 0;
    return state->currentAnim->endPosition;
}

bool CharEntity::hasKeyFrame() const{
    // TODO: ask about action type?
    return state->currentAnim != 0 && state->currentAnim->keyFrames.containsKey(state->currentFrame);
}

bool CharEntity::hasAnimation(int animIndex) const{
    return state->charObj->animSet.containsKey(animIndex);
}

const HitFrame* CharEntity::getHits() const{
    return getCurrentKeyFrame();
}

const KeyFrame* CharEntity::getCurrentKeyFrame() const{
    if (!hasKeyFrame()) return 0;
    return state->currentAnim->keyFrames.get(state->currentFrame);
}



void CharEntity::move(float dx, float dz){
    state->pos.x+=dx;
    state->pos.z+=dz;
    // also move who's grabbing it
    if (state->theGrabber!=0) state->theGrabber->move(dx,dz);
}


//void CharEntity::updateLastPos(){
//    lastPos = pos;
//}
//void CharEntity::simulate(float percentageDone){
//    FloatVector3D tmp;
//    if (pos.x == lastPos.x) tmp.x = pos.x;
//    //else tmp.x = pos.x*percentageDone + lastPos.x*(1-percentageDone);
//    else tmp.x = lastPos.x + (pos.x-lastPos.x)*percentageDone;
//    if (pos.y == lastPos.y) tmp.y = pos.y;
//    else tmp.y = pos.y*percentageDone + lastPos.y*(1-percentageDone);
//    if (pos.z == lastPos.z) tmp.z = pos.z;
//    else tmp.z = pos.z*percentageDone + lastPos.z*(1-percentageDone);
//    // TODO: shadow without the Z
//    this->SetPosition(tmp.x,tmp.y+tmp.z);
//}




















// ---------------------------
// ===========================
//    ----- CONTROL -----
// ===========================
// ---------------------------







bool CharEntity::update(){
    // TODO: return true somewhere
    if (state->hitPause>0) --(state->hitPause);
    if (state->hitPause <= GameInvariants::GRAB_PAUSE){ // means it is being updated
        // clear the hitten ones when sprite animation frame changes
        if (updateState()) state->theHittenOnes.clear();

        // test ungrabbing
        int index = getCurrentAnimIndex();
        if ((index == GameInvariants::GRABBING_FRONT || index == GameInvariants::GRABBING_BACK)
            && (state->presses[GameInvariants::Key::LEFT] && !state->isFacedLeft() || state->presses[GameInvariants::Key::RIGHT] && isFacedLeft())
        ){
            ++state->ungrabTime;
            if (state->ungrabTime==GameInvariants::UNGRAB_TIME){
                unGrab();
                animationBreak();
            }
        }else state->ungrabTime = 0;

        // hit reaction
        if (state->gotKnocked || state->gotHit){
//            std::cout << "OUCH!!\n";
            bool fromBack = attackedFromBack();
            if (isOnBlockingMove() && !fromBack){
                state->blockHitTime = GameInvariants::BLOCK_HIT_TIME;
            // hit if being attacked from back or has no grabbed one
            }else{ //if (fromBack || getGrabbed()==0){
                state->blockHitTime = 0;
                // be knocked down
                if (state->gotKnocked){
                    knockDown();
                // be hit
                }else if (state->gotHit){
                    if (getTheGrabber()!=0){
                        if (isBeingBackGrabbed() && setAnimation(GameInvariants::BEING_GRABBED_HIT_BACK));
                        else setAnimation(GameInvariants::BEING_GRABBED_HIT_FRONT);
                    }else setAnimation(GameInvariants::BEING_HIT);
                    // face to hitter if that flag is defined true (and not grabbed)
                    if ( getTheGrabber()==0 && GameInvariants::FACE_WHEN_HIT)
                        faceToHitter();
                }
            }
            state->gotKnocked = state->gotHit = false;
        }

        // if blocking attack
        if (state->blockHitTime>1){
//            std::cout << "BLOCK: " <<  (int)(state->blockHitTime) << "\n";
            --(state->blockHitTime);
            state->velocity.x = GameInvariants::BLOCK_HIT_VEL;
            if (state->isFacedLeft()) state->velocity.x*=-1;
        }else if (state->blockHitTime == 1){
            state->blockHitTime = 0;
            state->velocity.x = 0;
        }


        // timing controllers:
        if (state->runTime>0) --(state->runTime);
        if (state->runTime == 1) state->setRun = false;
        if (state->attackCounter>0) --(state->attackCounter);
        if (state->knockCounter>1) --(state->knockCounter);
        if (state->attackWaitTolerance>0) --(state->attackWaitTolerance);
        if (state->afterAttackPause>0){
            --(state->afterAttackPause);
            // when time ends, test walk
            if (state->afterAttackPause == 0)
                testWalk();
        }


        if (state->recoverTime>0){
            --(state->recoverTime);
            if (state->recoverTime==0 && !isInvincibleAnimPlaying())
                state->invincible = false;
        }
    }

    // Update the state
    if (lastState != 0) delete lastState;
    lastState = new CharState(*state);

    return false;
}



bool CharEntity::animationBreak(){

    UInt anim = getCurrentAnimIndex();

    if (anim == GameInvariants::DYING){
        Scene::currentScene->moveObject(this,-1);
        return false;
    }

    // if grabbing, its another story...
    if (getGrabbed() != 0) return grabAnimationBreak();
    // if being grabbed, restore the grabber power
    if (getTheGrabber()!=0){
        getTheGrabber()->reloadCurrentFrame();
    }

    if (!isInAir()){
        if (isBeingThrown() || anim == GameInvariants::BEING_KNOCKED){
            // TODO: safe landing
            // TODO: quaque
            setBeingThrown(false);
            if (anim == GameInvariants::BEING_THROWN || anim == GameInvariants::BEING_KNOCKED)
                groundBounce();
            else
                groundSuffer();
            return true;
        }
        else if (anim == GameInvariants::GROUND_BOUNCING || anim == GameInvariants::LYING){
            groundSuffer();
            return true;
        }
    }

    if (   anim == GameInvariants::NORMAL
        || anim == GameInvariants::WALK
        || anim == GameInvariants::RUN
        || (getTheGrabber() != 0 && anim != GameInvariants::BEING_BACK_GRABBED_DEFENCE)// if grabbed, nothing to do
    ) return false;
    // landing
    if (anim == GameInvariants::IN_AIR || anim == GameInvariants::STATIC_JUMP || anim == GameInvariants::JUMP || anim == GameInvariants::RUN_JUMP
        || anim == GameInvariants::JUMP_DOWN_ATTACK || anim == GameInvariants::JUMP_MOVE_ATTACK
        || anim == GameInvariants::JUMP_RUN_ATTACK || anim == GameInvariants::JUMP_STATIC_ATTACK){
        if (!isInAir()){
            state->hitPause = 0;
            if (!setAnimation(GameInvariants::LAND)){
                setAnimation(GameInvariants::NORMAL);
                testWalk();
            }
        }else // else if jump anim ends, set in air
//            if (anim == GameInvariants::STATIC_JUMP || anim == GameInvariants::JUMP || anim == GameInvariants::RUN_JUMP)
            setAnimation(GameInvariants::IN_AIR);
//        else return false;
    }
    // jump!
    else if (anim == GameInvariants::PREPARE_JUMP){

        if(isRunning() && state->isFacedLeft() != isMovingRight()){
            state->airPlayerVelX = state->charObj->runJumpVel*2.2*GameInvariants::JUMP_X_IMPULSE_FACT;
            if (state->isFacedLeft()) state->airPlayerVelX*=-1;
            if (!setAnimation(GameInvariants::RUN_JUMP) && !setAnimation(GameInvariants::JUMP))
                setAnimation(GameInvariants::STATIC_JUMP);
        }else if (isMovingLeft() || isMovingRight()){
            state->airPlayerVelX = state->charObj->jumpVel*GameInvariants::JUMP_X_IMPULSE_FACT;
            if (state->movingLeft) state->airPlayerVelX*=-1;
            if (!setAnimation(GameInvariants::JUMP))
                setAnimation(GameInvariants::STATIC_JUMP);
        }else{
            if (!setAnimation(GameInvariants::STATIC_JUMP))
                setAnimation(GameInvariants::JUMP);
        }
    }
    // attacking
    else if (anim >= GameInvariants::ATTACK_1 && anim <= GameInvariants::ATTACK_5){
        if (anim < GameInvariants::ATTACK_5 && state->hitSomeone){
            state->attackCounter = GameInvariants::ATTACK_TIME;
            ++(state->attackNum);
        }else state->attackCounter = state->attackNum = 0;
        state->hitSomeone = false;
        state->afterAttackPause = GameInvariants::AFTER_ATTACK_PAUSE;
        setAnimation(GameInvariants::NORMAL);
        testWalk();
    }
    // defending from grab
    else if ( anim == GameInvariants::BEING_BACK_GRABBED_DEFENCE){
        if (state->grabbedToThrow && setAnimation(GameInvariants::THROWS_WHOS_GRABBING) && getTheGrabber()){
            state->grabbedToThrow = false;
            grab(getTheGrabber());
            getTheGrabber()->state->grabbedOne = 0;
            state->theGrabber = 0;
//            getTheGrabber()->unGrab();
        }else{
            setAnimation(GameInvariants::NORMAL);
            if (getTheGrabber())
                getTheGrabber()->reloadCurrentFrame();
        }

    //default:
//    }else if (isInAir()){
//        if (anim == GameInvariants::BEING_THROWN || anim == GameInvariants::ATOMIC_FALLING) return false;
//        setAnimation(GameInvariants::IN_AIR);
    }else if (animationEnded()){
        // ######## Game specific.,,.
        if (anim>100){
            // reload the same
            this->setAnimation(anim);
            return true;
        }
        // In air
        if (isInAir()){
            if (state->beingThrown && setAnimation(GameInvariants::BEING_THROWN))
                return true;
            else return setAnimation(GameInvariants::IN_AIR);
        }
        // TODO: lying?
        // recover from knock hit?
        if (anim == GameInvariants::STANDING_UP){
            state->recoverTime = GameInvariants::RECOVER_TIME;
            state->invincible = true;
        }
        setAnimation(GameInvariants::NORMAL);
        // if directional keys pressed, walk
        testWalk();
    }else return false;

    // animation ended, try attack move
    if (state->attackWaitTolerance>0)
        performAttack();

    return true;
}







bool CharEntity::grabAnimationBreak(){
    UInt anim = getCurrentAnimIndex();
    if (   anim == GameInvariants::GRABBING_FRONT
        || anim == GameInvariants::GRABBING_BACK
        || anim == GameInvariants::GRAB_WALK
        || anim == GameInvariants::GRAB_BACK_WALK
        || anim == GameInvariants::GRAB_RUN
    ) return false;
    //grabbing
    if (anim == GameInvariants::GRABBING_UP){
        if (isGrabbingOnBack()) setAnimation(GameInvariants::GRABBING_BACK);
        else setAnimation(GameInvariants::GRABBING_FRONT);
        testWalk();
    }
    // landing
    else if (anim == GameInvariants::GRAB_JUMP || anim == GameInvariants::FRONT_GRAB_JUMP_ATTACK
        || anim == GameInvariants::BACK_GRAB_JUMP_ATTACK){
        if (!isInAir()){
            if (anim == GameInvariants::GRAB_JUMP || anim == GameInvariants::FRONT_GRAB_JUMP_ATTACK && !setAnimation(GameInvariants::FRONT_GRAB_JUMP_ATTACK_LAND)
             || anim == GameInvariants::BACK_GRAB_JUMP_ATTACK && !setAnimation(GameInvariants::BACK_GRAB_JUMP_ATTACK_LAND)
            ){
                setAnimation(GameInvariants::LAND);
                unGrab();
            }
//            std::cout << "landing, Ungrab\n";

            testWalk();
        }
        else return false;
    }
    // attacking
    else if (anim >= GameInvariants::FRONT_GRAB_FRONT_ATTACK_1 && anim <= GameInvariants::FRONT_GRAB_FRONT_ATTACK_5){
        if (anim < GameInvariants::FRONT_GRAB_FRONT_ATTACK_5){
            state->attackCounter = GameInvariants::ATTACK_TIME;
            ++(state->attackNum);
        }else state->attackCounter = state->attackNum = 0;

        if (isGrabbingOnBack()) setAnimation(GameInvariants::GRABBING_BACK);
        else setAnimation(GameInvariants::GRABBING_FRONT);
        testWalk();
    }
    // flip
    else if (anim == GameInvariants::FLIP_OVER || anim == GameInvariants::FAILED_FLIP_OVER){
        if (!state->noMoreFlip){
            grab(getGrabbed(),!isGrabbingOnBack());
            if (isGrabbingOnBack()) setAnimation(GameInvariants::GRABBING_BACK);
            else setAnimation(GameInvariants::GRABBING_FRONT);
            state->noMoreFlip = true;
        }else{
            setAnimation(GameInvariants::NORMAL);
            unGrab();
            testWalk();
        }
    }
    //default:
    else if (animationEnded()){
        if (isGrabbingOnBack()) setAnimation(GameInvariants::GRABBING_BACK);
        else setAnimation(GameInvariants::GRABBING_FRONT);
            // if directional keys pressed, walk
            testWalk();
    }else return false;

    // animation ended, try attack move
    if (state->attackWaitTolerance>0)
        performAttack();

    return true;
}







void CharEntity::testWalk(){
    // test walk occurs after a break or stop, so no run possibility
    //state->runTime = 0;
    run(false);
    // test if is still moving
    bool moving = true;
    state->tryingRoll = false;
    // left/right
    if (state->presses[GameInvariants::Key::LEFT]){ moveLeft(true); }
    else if (state->presses[GameInvariants::Key::RIGHT]){ moveRight(true); }
    else moving = false;
    // up/down
    if (state->presses[GameInvariants::Key::UP]){ moveUp(true); moving = true; }
    else if (state->presses[GameInvariants::Key::DOWN]){ moveDown(true); moving = true; }

    if (moving){
        state->tryingRoll = !state->presses[GameInvariants::Key::LEFT] && !state->presses[GameInvariants::Key::RIGHT];
        if (getGrabbed() != 0)
            grabWalk();
        else walk();
    }
}



// walk, run, and roll up/down
void CharEntity::walk(){
    UInt anim = getCurrentAnimIndex();

    // if on normal or waiting, put it walking
    if (anim == GameInvariants::NORMAL || anim == GameInvariants::WAITING){
        if (state->afterAttackPause > 0){
            //may flip
            if (state->presses[GameInvariants::Key::LEFT] || state->presses[GameInvariants::Key::RIGHT]){
                faceLeft(state->presses[GameInvariants::Key::LEFT]);
            }
            return; // no walk
        }
        setAnimation(GameInvariants::WALK);
    }
    // if walking and press left or right
    if (getCurrentAnimIndex() == GameInvariants::WALK){
        // flip if needed
        if (state->presses[GameInvariants::Key::LEFT] || state->presses[GameInvariants::Key::RIGHT]){
            faceLeft(state->presses[GameInvariants::Key::LEFT]);
        }

        // pressing oposite directions, stop and don't run
        if (state->presses[GameInvariants::Key::LEFT] && state->presses[GameInvariants::Key::RIGHT] || state->presses[GameInvariants::Key::UP] && state->presses[GameInvariants::Key::DOWN]){
            state->setRun = false;
            run(false);
            return;
        }

        // test run or roll
        if (state->setRun && state->runTime>0){
            state->setRun = false;
            // left or right, means to run
            if (!state->tryingRoll){
                setAnimation(GameInvariants::RUN);
                run(true);
            // else test roll up or down
            }else if (state->presses[GameInvariants::Key::UP]) setAnimation(GameInvariants::ROLL_UP);
            else if (state->presses[GameInvariants::Key::DOWN]) setAnimation(GameInvariants::ROLL_DOWN);
            //state->runTime = 0;
        }//else state->runTime = GameInvariants::RUN_TIME;
    }
}

// stops the movement if any move key is pressed/released
void CharEntity::stop(){
    UInt anim = getCurrentAnimIndex();
    // some animations ignores the stop
    if (anim == GameInvariants::PREPARE_JUMP || isInAir()) return;
    // walk or run, what to do
    if (anim == GameInvariants::WALK || anim == GameInvariants::RUN){
        // do not keep runing if faced in wrong direction
        if (anim == GameInvariants::RUN && ( isFacedLeft() && !state->presses[GameInvariants::Key::LEFT] || (!isFacedLeft() && !state->presses[GameInvariants::Key::RIGHT])) ){
            state->setRun = false;
            run(false);
            setAnimation(GameInvariants::NORMAL);
        }
        // walk: left or right
        else if (state->presses[GameInvariants::Key::LEFT] || state->presses[GameInvariants::Key::RIGHT] || state->presses[GameInvariants::Key::UP] || state->presses[GameInvariants::Key::DOWN]){
            if (state->presses[GameInvariants::Key::LEFT] || state->presses[GameInvariants::Key::RIGHT]){
                // see if keep waling or runing
                if (state->presses[GameInvariants::Key::LEFT] && isFacedLeft() || state->presses[GameInvariants::Key::RIGHT] && !isFacedLeft())
                    return;
                faceLeft(state->presses[GameInvariants::Key::LEFT]);
            }
            run(false);
            setAnimation(GameInvariants::WALK);
        // stoped: if not pressing any dir key at all, stop and return
        }else{
            run(false);
            setAnimation(GameInvariants::NORMAL);
            return;
        }
    }
    // if directional keys pressed, walk or run or roll
    testWalk();
}

// Jump movement
void CharEntity::jump(){
    UInt anim = getCurrentAnimIndex();
    if (   anim == GameInvariants::NORMAL
        || anim == GameInvariants::WAITING
        || anim == GameInvariants::WALK
        || anim == GameInvariants::RUN
    ){
        // solve the jump velocity
//        if (anim == GameInvariants::WALK)
//            state->airPlayerVelX = state->charObj->jumpVel;
//        else if (anim == GameInvariants::RUN)
//            state->airPlayerVelX = state->charObj->runJumpVel;
//        else state->airPlayerVelX = 0;
//        if (state->isFacedLeft()) state->airPlayerVelX*=-1;

        setAnimation(GameInvariants::PREPARE_JUMP);
    }
}




void CharEntity::attack(){
    UInt anim = getCurrentAnimIndex();
    // TODO: add a state to reduce comparisons
    if (   anim == GameInvariants::NORMAL
        || anim == GameInvariants::WAITING
        || anim == GameInvariants::WALK
    ){
        // if ready to run attack, do it and return
        if (state->setRun && state->runTime>0){ runAttack(); return; }
        // if time exceeded, reset attack combos
        if (state->attackCounter ==0) state->attackNum = 0;
        // try set the next attack animation
        if (!setAnimation(GameInvariants::ATTACK_1 + state->attackNum)){
            // if fail, means no more animations, reset it and do the first one
            state->attackNum = 0;
            setAnimation(GameInvariants::ATTACK_1);
        }
        state->attackWaitTolerance = 0;
    }else if (anim == GameInvariants::RUN) runAttack();
}


void CharEntity::runAttack(){
    state->setRun = false;
    run(false);
    setAnimation(GameInvariants::RUN_ATTACK_STAR_0); // TODO: Add stars
    state->attackWaitTolerance = 0;
}


void CharEntity::jumpAttack(){
    UInt anim = getCurrentAnimIndex();
    // TODO: add a state to reduce comparisons
//    if (anim == GameInvariants::PREPARE_JUMP)
//        setAnimation(GameInvariants::JUMP);
    if (   anim == GameInvariants::STATIC_JUMP
        || anim == GameInvariants::JUMP
        || anim == GameInvariants::RUN_JUMP
        || anim == GameInvariants::IN_AIR
    ){
        if (state->presses[GameInvariants::Key::DOWN]) setAnimation(GameInvariants::JUMP_DOWN_ATTACK);
        else if (isStaticJumping()){
            if (!setAnimation(GameInvariants::JUMP_STATIC_ATTACK))
                setAnimation(GameInvariants::JUMP_MOVE_ATTACK);

        }else if (!(isRunning() && setAnimation(GameInvariants::JUMP_RUN_ATTACK)))
            setAnimation(GameInvariants::JUMP_MOVE_ATTACK);
        state->attackWaitTolerance = 0;
    }
}




// walk, run, and roll up/down
void CharEntity::grabWalk(){
    UInt anim = getCurrentAnimIndex();
    // if on normal or waiting, put it walking
    if (anim == GameInvariants::GRABBING_FRONT || anim == GameInvariants::GRABBING_BACK){
        if (state->presses[GameInvariants::Key::LEFT] && !isFacedLeft() || state->presses[GameInvariants::Key::RIGHT] && isFacedLeft()){
            if (!setAnimation(GameInvariants::GRAB_BACK_WALK)) return;
        } else if (!setAnimation(GameInvariants::GRAB_WALK)) return;
    }
    anim = getCurrentAnimIndex();
    // if walking and press left or right
    if ( anim == GameInvariants::GRAB_WALK || anim == GameInvariants::GRAB_BACK_WALK){

        // pressing oposite directions, stop and don't run
        if (state->presses[GameInvariants::Key::LEFT] && state->presses[GameInvariants::Key::RIGHT] || state->presses[GameInvariants::Key::UP] && state->presses[GameInvariants::Key::DOWN]){
            state->setRun = false;
            run(false);
            return;
        }
        // flip anim if needed
        if (anim == GameInvariants::GRAB_BACK_WALK && (state->presses[GameInvariants::Key::LEFT] && isFacedLeft() || state->presses[GameInvariants::Key::RIGHT] && !isFacedLeft()))
            setAnimation(GameInvariants::GRAB_WALK);
        else if (anim == GameInvariants::GRAB_WALK && (state->presses[GameInvariants::Key::LEFT] && !isFacedLeft() || state->presses[GameInvariants::Key::RIGHT] && isFacedLeft()))
            setAnimation(GameInvariants::GRAB_BACK_WALK);
        // test run, only if faced to the same direction
        if (state->setRun && state->runTime>0 && isFacedLeft() == state->presses[GameInvariants::Key::LEFT]){
            state->setRun = false;
            // left or right, means to run
            if (!state->tryingRoll){
                setAnimation(GameInvariants::GRAB_RUN);
                run(true);
            }
        }
    }
}



// stops the movement if any move key is pressed/released
void CharEntity::grabStop(){
    UInt anim = getCurrentAnimIndex();
    // some animations ignores the stop
    if (anim == GameInvariants::PREPARE_JUMP || isInAir()) return;
    // walk or run, what to do
    if (anim == GameInvariants::GRAB_WALK || anim == GameInvariants::GRAB_BACK_WALK || anim == GameInvariants::GRAB_RUN){
        // do not keep runing if faced in wrong direction
        if (anim == GameInvariants::GRAB_RUN && ( isFacedLeft() && !state->presses[GameInvariants::Key::LEFT] || (!isFacedLeft() && !state->presses[GameInvariants::Key::RIGHT])) ){
            state->setRun = false;
            run(false);
            if (isGrabbingOnBack()) setAnimation(GameInvariants::GRABBING_BACK);
            else setAnimation(GameInvariants::GRABBING_FRONT);
        }
        // walk: left or right
        else if (state->presses[GameInvariants::Key::LEFT] || state->presses[GameInvariants::Key::RIGHT] || state->presses[GameInvariants::Key::UP] || state->presses[GameInvariants::Key::DOWN]){
            // see if keep running
            if (anim == GameInvariants::GRAB_RUN && (state->presses[GameInvariants::Key::LEFT] && isFacedLeft() || state->presses[GameInvariants::Key::RIGHT] && !isFacedLeft()))
                return;
            state->setRun = false;
            run(false);
            // flip anim if needed
            if (!state->presses[GameInvariants::Key::LEFT] && !state->presses[GameInvariants::Key::RIGHT] || (anim == GameInvariants::GRAB_BACK_WALK && (state->presses[GameInvariants::Key::LEFT] && isFacedLeft() || state->presses[GameInvariants::Key::RIGHT] && !isFacedLeft())))
                setAnimation(GameInvariants::GRAB_WALK);
            else if (anim == GameInvariants::GRAB_WALK && (state->presses[GameInvariants::Key::LEFT] && !isFacedLeft() || state->presses[GameInvariants::Key::RIGHT] && isFacedLeft()))
                setAnimation(GameInvariants::GRAB_BACK_WALK);
        // stoped: if not pressing any dir key at all, stop and return
        }else{
            run(false);
            if (isGrabbingOnBack()) setAnimation(GameInvariants::GRABBING_BACK);
            else setAnimation(GameInvariants::GRABBING_FRONT);
            return;
        }
    }
    // if directional keys pressed, walk or run or roll
    testWalk();
}



void CharEntity::grabJump(){
    UInt anim = getCurrentAnimIndex();
    if (    anim == GameInvariants::GRABBING_BACK
         || anim == GameInvariants::GRABBING_FRONT
         || anim == GameInvariants::GRAB_WALK
         || anim == GameInvariants::GRAB_BACK_WALK
         || anim == GameInvariants::GRAB_RUN
    ){
        if (!setAnimation(GameInvariants::GRAB_JUMP))
            // TODO: may fail because of obstacles
            setAnimation(GameInvariants::FLIP_OVER);
        else{
            if(isRunning() && state->isFacedLeft() != isMovingRight())
                state->airPlayerVelX = state->charObj->runJumpVel*GameInvariants::JUMP_X_IMPULSE_FACT;
            else if (isMovingLeft() || isMovingRight())
                state->airPlayerVelX = state->charObj->jumpVel*GameInvariants::JUMP_X_IMPULSE_FACT;
            if (isMovingLeft())
                state->airPlayerVelX*=-1;
        }
    }
}



//void CharEntity::ungrabAndRestore(){
//    setAnimation(GameInvariants::NORMAL);
//    unGrab();
//}

void CharEntity::grabAttack(){
    UInt anim = getCurrentAnimIndex();
    if ( !isGrabbingOnBack() && (
            anim == GameInvariants::GRABBING_FRONT
         || anim == GameInvariants::GRAB_WALK
         || anim == GameInvariants::GRAB_BACK_WALK
    )){
        if (state->presses[GameInvariants::Key::LEFT] || state->presses[GameInvariants::Key::RIGHT]){
            // if pressing forward
            if (isFacedLeft() && state->presses[GameInvariants::Key::LEFT] || !isFacedLeft() && state->presses[GameInvariants::Key::RIGHT]){
                // if ready to run attack, do it and return
                if (state->setRun && state->runTime>0){ grabRunAttack(); return; }
                // try set the next attack animation
                if (!setAnimation(GameInvariants::FRONT_GRAB_FRONT_ATTACK_1 + state->attackNum)){
                    // if fail, try static one:
                    if (state->attackNum != 0){
                            state->attackNum = 0;
                            if (!setAnimation(GameInvariants::FRONT_GRAB_FRONT_ATTACK_1)){
                                setAnimation(GameInvariants::NORMAL);
                                unGrab();
                            }
                    }else setAnimation(GameInvariants::FRONT_GRAB_STATIC_ATTACK);
                }
            // else, it's pressing backward
            }else if (!setAnimation(GameInvariants::FRONT_GRAB_BACK_ATTACK)){
                if (!setAnimation(GameInvariants::FRONT_GRAB_STATIC_ATTACK)){
                    ; //ungrabAndRestore();
                }
            }
            //no pressing at all
        }else{
            if (!setAnimation(GameInvariants::FRONT_GRAB_STATIC_ATTACK) && !setAnimation(GameInvariants::FRONT_GRAB_FRONT_ATTACK_1 + state->attackNum) && !setAnimation(GameInvariants::FRONT_GRAB_BACK_ATTACK)){
                ; //ungrabAndRestore();
            }

        }
        state->attackWaitTolerance = 0;
    }else if (anim == GameInvariants::GRAB_RUN) grabRunAttack();
    else if (anim == GameInvariants::GRABBING_BACK || anim == GameInvariants::GRAB_WALK || anim == GameInvariants::GRAB_BACK_WALK){
        if (state->presses[GameInvariants::Key::LEFT] || state->presses[GameInvariants::Key::RIGHT]){
            // if pressing forward
            if ((isFacedLeft() && state->presses[GameInvariants::Key::LEFT] || !isFacedLeft() && state->presses[GameInvariants::Key::RIGHT])
                && setAnimation(GameInvariants::BACK_GRAB_FRONT_ATTACK) ) ;
            // else if pressing backward
            else if (!setAnimation(GameInvariants::BACK_GRAB_BACK_ATTACK))
                setAnimation(GameInvariants::BACK_GRAB_STATIC_ATTACK);
        }else setAnimation(GameInvariants::BACK_GRAB_STATIC_ATTACK);
        state->attackWaitTolerance = 0;
    }
    else if (anim == GameInvariants::FLIP_OVER
            && getCurrentAnimFrame()>=getAnimTotalFrames()*GameInvariants::FLIP_ATTACK_MINIMUM
            && getCurrentAnimFrame()<=getAnimTotalFrames()*GameInvariants::FLIP_ATTACK_MAXIMUM
    ){
        setAnimation(GameInvariants::FLIP_OVER_ATTACK);
        state->attackWaitTolerance = 0;
    }
}

void CharEntity::grabRunAttack(){
    state->setRun = false;
    run(false);
    setAnimation(GameInvariants::GRAB_RUN_ATTACK);
    state->attackWaitTolerance = 0;
}



void CharEntity::grabJumpAttack(){
    UInt anim = getCurrentAnimIndex();
    if (anim == GameInvariants::GRAB_JUMP){
        if (isGrabbingOnBack())
            setAnimation(GameInvariants::BACK_GRAB_JUMP_ATTACK);
        else setAnimation(GameInvariants::FRONT_GRAB_JUMP_ATTACK);
        state->attackWaitTolerance = 0;
    }
}


void CharEntity::grabDefence(){
    CharEntity* theGrabber = getTheGrabber();
    // not grabbed on back or already defending, ignore
    if (!theGrabber->isGrabbingOnBack() || getCurrentAnimIndex() == GameInvariants::BEING_BACK_GRABBED_DEFENCE)
        return;
    UInt anim = theGrabber->getCurrentAnimIndex();
    if (anim == GameInvariants::GRABBING_BACK
        || anim == GameInvariants::GRAB_WALK        // TODO: keep this?
        || anim == GameInvariants::GRAB_BACK_WALK   // TODO: keep this?
        || anim == GameInvariants::GRABBING_UP      // TODO: keep this?
    ) setAnimation(GameInvariants::BEING_BACK_GRABBED_DEFENCE);

}


void CharEntity::grabDefenceThrow(){
    if (getCurrentAnimIndex() == GameInvariants::BEING_BACK_GRABBED_DEFENCE){
        state->grabbedToThrow = true;
    }
//    if (getCurrentAnimIndex() == GameInvariants::BEING_BACK_GRABBED_DEFENCE
//            && getCurrentAnimFrame()>=getAnimTotalFrames()*GameInvariants::FLIP_ATTACK_MINIMUM
//            && getCurrentAnimFrame()<=getAnimTotalFrames()*GameInvariants::FLIP_ATTACK_MAXIMUM
//    ){
//        grab(getTheGrabber());
//        getTheGrabber()->unGrab();
//        setAnimation(GameInvariants::THROWS_WHOS_GRABBING);
//    }
}



void CharEntity::special(){
    UInt anim = getCurrentAnimIndex();
    if (    !isInAir() &&(
           anim == GameInvariants::NORMAL
        || anim == GameInvariants::WAITING
        || anim == GameInvariants::WALK
        || anim == GameInvariants::RUN
        || anim == GameInvariants::BEING_HIT
        || anim == GameInvariants::BEING_GRABBED_FRONT
        || anim == GameInvariants::BEING_GRABBED_BACK
        || anim == GameInvariants::BEING_GRABBED_HIT_BACK
        || anim == GameInvariants::BEING_GRABBED_HIT_FRONT
        || anim == GameInvariants::GRABBING_FRONT
        || anim == GameInvariants::GRABBING_BACK
        || anim == GameInvariants::GRAB_WALK
        || anim == GameInvariants::GRAB_BACK_WALK
        || anim == GameInvariants::GRAB_RUN
    )){
        bool offencive = state->presses[GameInvariants::Key::LEFT] || state->presses[GameInvariants::Key::RIGHT];
        if (offencive && !hasAnimation(GameInvariants::OFENCIVE_SPECIAL) || !offencive && !hasAnimation(GameInvariants::DEFENCIVE_SPECIAL)){
            // no special
            return;
        }
        // if grabbing, ungrab
        if (getGrabbed()!=0) unGrab();
        // if being grabbed, ungrab
        if (getTheGrabber() != 0){
            CharEntity* grabber = getTheGrabber();
            UInt anim = grabber->getCurrentAnimIndex();
            if ( anim == GameInvariants::FLIP_OVER || anim == GameInvariants::FAILED_FLIP_OVER)
                return; // do not special while being fliped
            grabber->unGrab();
            grabber->breakAnim();
        }
        // defencive or offencive
        if (offencive)setAnimation(GameInvariants::OFENCIVE_SPECIAL);
        else setAnimation(GameInvariants::DEFENCIVE_SPECIAL);

    }
}


void CharEntity::jumpSpecial(){
    if ((getCurrentAnimIndex() == GameInvariants::JUMP || getCurrentAnimIndex() == GameInvariants::RUN_JUMP)
        && ::fabs(state->velocity.y) < GameInvariants::JUMP_SPECIAL_MAX_SPEED
    ) setAnimation(GameInvariants::JUMP_SPECIAL);
}



void CharEntity::backAttack(){
    UInt anim = getCurrentAnimIndex();
    // TODO: add a state to reduce comparisons
    if (   anim == GameInvariants::NORMAL
        || anim == GameInvariants::WAITING
        || anim == GameInvariants::WALK
        || anim == GameInvariants::PREPARE_JUMP
    ){
        setAnimation(GameInvariants::BACK_ATTACK);
        state->knockCounter = 0;
        state->attackWaitTolerance = 0;
    }
}

void CharEntity::knockAttack(){
    UInt anim = getCurrentAnimIndex();
    // TODO: add a state to reduce comparisons
    if (   anim == GameInvariants::NORMAL
        || anim == GameInvariants::WAITING
        || anim == GameInvariants::WALK
    ) setAnimation(GameInvariants::KNOCK_ATTACK);
    state->knockCounter =0;
    state->attackWaitTolerance = 0;
}

void CharEntity::super(){

}

void CharEntity::helpCall(){

}







UInt CharEntity::beingHit(const HitInfo& hitInfo){
    state->hitInfo = hitInfo;
    // grabing and being attacked from front, do not get hitten
    if (!attackedFromBack() && getGrabbed()!=0 || hitInfo.hitterState == 0) return 0;
    // TODO: invincible sprite, ignore
    // TODO: Use sf::vectors!
    // TODO: rotation! (when thrown rotation) --> TODO: just transform to local, should work
//    std::cout << "\n\n\n\n\n\n";
    std::vector<Point16>::const_iterator it;
    for(it = hitInfo.hits->actionPoints.begin() ; it!= hitInfo.hits->actionPoints.end() ; ++it){
        // get real (X,Y)
        float hitX = hitInfo.hitterState->pos.x + (hitInfo.hitterState->isFacedLeft() ? -it->x : it->x);
        float hitY = hitInfo.hitterState->pos.y - it->y;
        float hitZ = hitInfo.hitterState->pos.z;

        float realX = hitX;
        float realY = hitZ - hitY; //hitInfo.hitterState->pos.y + it->y;
//        std::cout << "(" << it->x << ", " << it->y << ") and original: (" << hitInfo.hitter->GetPosition().x << ", " << hitInfo.hitter->GetPosition().y << ")\n";
//        std::cout << "real: (" << realX << ", " << realY << ")\n";
        // TODO: rotation
        // TODO: transform to local

        // get local (X,Y)
        realX -= state->pos.x;
        realY -= state->pos.z - state->pos.y;

        realX += state->center.x;
        realY += state->center.y;

        UInt localX = (UInt) realX;
        UInt localY = (UInt) realY;
//        std::cout << "local: (" << localX << ", " << localY << ")\n";
//        std::cout << "sprite pos: (" << GetPosition().x << ", " << GetPosition().y << "), size: (" << GetSize().x << ", " << GetSize().y << ")\n";
//        std::cout << "sprite center: (" << GetCenter().x << ", " << GetCenter().y << ")\n";

        // TODO: why local > 0 ? not sure, but getpixel gives error when it's zero
        const sf::Image& img = getCurrentImage();

        if ( localX > 0 && localY > 0 && localX <img.GetWidth() && localY < img.GetHeight()
             && img.GetPixel(localX, localY).a==255
        ){
//            std::cout << "I'm hit\n\n";

            // cut some energy
            if (hitInfo.hits->actionType >= GameInvariants::AT_KNOCK)
                state->energy-=hitInfo.hits->actionType - GameInvariants::AT_KNOCK;
            else state->energy-=hitInfo.hits->actionType;
//            std::cout << "ENERGY: " << state->energy << " because of "<< hitInfo.hits->actionType <<"\n";

            state->gotKnocked = (isInAir() && getTheGrabber()==0 || hitInfo.hits->actionType >= GameInvariants::AT_KNOCK || state->energy <= 0);
            state->gotHit = true;
            if (getGrabbed() && getGrabbed()->getCurrentAnimIndex() == GameInvariants::BEING_BACK_GRABBED_DEFENCE){
                getGrabbed()->unGrab(); // ???
            }

            hitZ = std::max(hitZ, getZ())+1;
            // play hit sound
            if (attackedFromBack() || !isOnBlockingMove())
                AudioManager::playSound(hitInfo.hits->hitSound, hitX, hitY, hitZ);
            else
                // TODO: PREDEFINED BLOCKING SOUND!!
                AudioManager::playSound(11, hitX, hitY, hitZ);

            // Do animation:
//            EffectsManager::addEffectToCurrentManager(EffectsManager::hitEffect->createEffect(hitX, hitY, hitZ));

            testDying();


            // TODO: count energy and points
            return 1;   // TODO: return energy lost
        }
//        std::cout << "\n";
    }
    return 0;
}



void CharEntity::groundBounce(){
    // #changed
    float oldVelX = state->velocity.x*GameInvariants::ELASTICITY;
    float oldVelZ = state->velocity.z*GameInvariants::ELASTICITY;
    if (setAnimation(GameInvariants::GROUND_BOUNCING) || setAnimation(GameInvariants::LYING))
        state->velocity.y = GameInvariants::GROUND_BOUNCE_VEL;
    state->velocity.x = oldVelX;
    state->velocity.z = oldVelZ;

    if (state->waitingDamage > 0){
        state->energy -= state->waitingDamage;
        state->waitingDamage = 0;
        testDying();
    }

}

void CharEntity::groundSuffer(){
    resetSpeed();
    // TODO: do not stand up if dying
    // TODO: somewhere the suffering energy must be stored, and suffered here
//    setAnimation(GameInvariants::LYING);

    if (state->energy > 0)
        setAnimation(GameInvariants::STANDING_UP);
    else if (!setAnimation(GameInvariants::DYING)){
        setAnimation(GameInvariants::LYING);
        Scene::currentScene->moveObject(this,-1);
    }

}



void CharEntity::testDying(){
    if (state->energy <= 0){
        // ####### scene specific, lolling way to solve this
        // ####### SCENE SPECIFIC ########
        int sound = (int)(::round(state->charObj->runJumpVel*GameInvariants::VEL_DIVIDER));

//        if (sound == 9){
//            AudioManager::playSound(9 + sf::Randomizer::Random(0,1),getX(), getY(), getZ());
//        }else
        if (getY()<-10){
            AudioManager::playSound(sound ,getX(), -10, getZ());
        }
        else AudioManager::playSound(sound ,getX(), getY(), getZ());
    }
}


void CharEntity::reborn(int x, int y, int z){
    state->pos.x = x;
    state->pos.y = y;
    state->pos.z = z;
    state->energy = state->maxEnergy;
    state->invincible = true;
    state->recoverTime = GameInvariants::RECOVER_TIME*10;
    setAnimation(GameInvariants::IN_AIR);
    state->velocity.x = state->velocity.y = 0;
    state->airPlayerVelX = state->airPlayerVelZ = 0;
}



//void CharEntity::knockDown(){
//    setAnimation(GameInvariants::BEING_KNOCKED);
//    HitFrame f;
//    f.throwDamage = 0;
//    f.throwImpulse = new FloatVector3D(GameInvariants::KNOKED_X_VEL,0,GameInvariants::KNOKED_Z_VEL);
//    f.throwRot = 0;
//    beThrown(&f);
//}

//bool CharEntity::actionRequest(int k, void* param){
//    return takeKey(k%PRESS_STATE, k/PRESS_STATE);
//}


bool CharEntity::takeKey(int k, bool press){
    // TODO: regist if it has any effect. If yes, on end regist it (quickState)
    // else, just ignore the key
    if (k<0 || k>GameInvariants::NUM_KEYS || state->presses[k] == press) return false;

    // back key
    state->presses[k] = press;
    if (k == GameInvariants::Key::D){
        state->presses[GameInvariants::Key::B] = state->presses[GameInvariants::Key::C] = press;
        k = GameInvariants::Key::B;
    }


    bool grabbing = getGrabbed()!=0;
    switch(k){
        // Directional Keys, for walk, run and roll
        // TODO: when it's on a grabbing, and ofencive special, etc
        // If oposite key is pressed, just ignore it
        case GameInvariants::Key::UP:
            // if being grabbed, ignore move
            if (getTheGrabber() != 0) break;

            moveUp(press);

            if (press){
                state->tryingRoll = !state->presses[GameInvariants::Key::LEFT] && !state->presses[GameInvariants::Key::RIGHT];
                if (state->runTime == 0 || !state->tryingRoll) state->runTime = GameInvariants::RUN_TIME;
                else state->setRun = true;
                grabbing ? grabWalk() : walk();
            }else grabbing ? grabStop() : stop();

            break;
        case GameInvariants::Key::DOWN:
            // if being grabbed, ignore move
            if (getTheGrabber() != 0) break;

            moveDown(press);

            if (press){
                state->tryingRoll = !state->presses[GameInvariants::Key::LEFT] && !state->presses[GameInvariants::Key::RIGHT];
                if (state->runTime == 0 || !state->tryingRoll) state->runTime = GameInvariants::RUN_TIME;
                else state->setRun = true;
                grabbing ? grabWalk() : walk();
            }else grabbing ? grabStop() : stop();

            break;
        case GameInvariants::Key::LEFT:
            // if being grabbed, ignore move
            if (getTheGrabber() != 0) break;
            moveLeft(press);

           if (press){
                if (!isFacedLeft()) state->runTime = 0;
                if (state->runTime == 0 || state->tryingRoll) state->runTime = GameInvariants::RUN_TIME;
                else state->setRun = true;
                state->tryingRoll = false;
                grabbing ? grabWalk() : walk();
            }else grabbing ? grabStop() : stop();

            break;
        case GameInvariants::Key::RIGHT:
            // if being grabbed, ignore move
            if (getTheGrabber() != 0) break;

            moveRight(press);

            if (press){
                if (isFacedLeft()) state->runTime = 0;
                if (state->runTime == 0 || state->tryingRoll) state->runTime = GameInvariants::RUN_TIME;
                else state->setRun = true;
                state->tryingRoll = false;
                grabbing ? grabWalk() : walk();
            }else grabbing ? grabStop() : stop();

            break;


        case GameInvariants::Key::A:
            if (press)  // TODO: count to super
                if (grabbing && getGrabbed()->getCurrentAnimIndex() == GameInvariants::BEING_BACK_GRABBED_DEFENCE) break;
                else if (isInAir()) jumpSpecial();
                else special();
            break;

        case GameInvariants::Key::B:
            if (!press){
                if (state->knockCounter == 1)
                    knockAttack();
                break;
            }else
                performAttack();
            break;

        case GameInvariants::Key::C:
            if (press){
                if (grabbing){
                    if (getGrabbed()->getCurrentAnimIndex() == GameInvariants::BEING_BACK_GRABBED_DEFENCE) break;
                    grabJump();
                    break;
                }
                else if (getTheGrabber()!=0){ grabDefence(); break; }
                if (state->presses[GameInvariants::Key::B]) backAttack();
                else jump();
            }
            break;

//        case GameInvariants::Key::D:
//            if (grabbing && getGrabbed()->getCurrentAnimIndex() == GameInvariants::BEING_BACK_GRABBED_DEFENCE) break;
//            else if (getTheGrabber()!=0){
//                if (getCurrentAnimIndex() == GameInvariants::BEING_BACK_GRABBED_DEFENCE) grabDefenceThrow();
//                else grabDefence();
//                break;
//            }
//            if (press) backAttack();
//            break;

        case GameInvariants::Key::E:
            if (press) knockAttack();
            break;

        case GameInvariants::Key::F:
            break;

        case GameInvariants::Key::CALL:
//            Scene::currentScene->beforeSpecialState = Scene::currentScene->sceneState;
//            Scene::currentScene->sceneState = 20;
            break;

        default:
            break;
    }
//    if (press && (k == KEFT || k == RIGHT)){
//        if (doubleForward = last == k && (k == LEFT || k == RIGHT))
//            doubleForwardTime = GameInvariants::RUN_TIME;
//    }
    return true;   // TODO: return correctly
}





void CharEntity::performAttack(){
    state->attackWaitTolerance = GameInvariants::ATTACK_WAIT_TOLERANCE;
    state->knockCounter = GameInvariants::KNOCK_TIME+1;
    if (getTheGrabber() !=0){
        grabDefenceThrow();
        if (state->presses[GameInvariants::Key::C]) grabDefence();
        return;
    }
    else if (getGrabbed()!=0){
        if (getGrabbed()->getCurrentAnimIndex() == GameInvariants::BEING_BACK_GRABBED_DEFENCE) return;
        if (isInAir()) grabJumpAttack();
        else grabAttack();
        return;
    }

    if (isInAir()) jumpAttack();
    else if (state->presses[GameInvariants::Key::C]) backAttack();
//    else if (state->attackNum == 1 && state->presses[GameInvariants::Key::DOWN] && !state->theHittenOnes.empty()){
//        this->setAnimation(GameInvariants::GRABBING_FRONT);
//        this->grab(static_cast<CharEntity*>(*state->theHittenOnes.begin()));
//        bool oldLeft = state->presses[GameInvariants::Key::LEFT];
//        bool oldRight = state->presses[GameInvariants::Key::RIGHT];
//        state->presses[GameInvariants::Key::LEFT] = !state->facedLeft;
//        state->presses[GameInvariants::Key::RIGHT] = state->facedLeft;
//        grabAttack();
//        state->presses[GameInvariants::Key::LEFT] = oldLeft;
//        state->presses[GameInvariants::Key::RIGHT] = oldRight;
//        state->attackNum = 0;
//    }
    else attack();
}





// -------------------------
//  ---- grabbing test ----
// -------------------------
bool CharEntity::testGrab(AEntity* theOther){
    CharEntity* other;

    // do not grab if after a hit someone or if different y
    if (state->hitPause>0 || theOther->getY() != this->getY()) return false;

    // only grab characters (TODO: grab other stuff?)
    if (!(other = dynamic_cast<CharEntity*>(theOther))) return false;

    // if the other is in air or invincible, ignore TODO: do not grab when invincible!
    if (other->isInAir() || other->lastState->invincible
        || other->getTheGrabber() != 0 || other->getGrabbed()!=0
    ) return false;
    // if no move, no grab
    UInt anim = getCurrentAnimIndex();
    if (!(anim==GameInvariants::WALK || anim==GameInvariants::RUN)) return false;

    // get const pointers to their positions
    const sf::Vector3f& thisPos = lastState->pos;
    const sf::Vector3f& otherPos = other->lastState->pos;
    // save the old position of the grabbed one
    sf::Vector3f oldOtherPos(otherPos);
    // compute the distance to grab
    int difX = (int)(otherPos.x - thisPos.x);
    if (isFacedLeft()) difX*=-1;
    int difZ = ::abs((int)(otherPos.z - thisPos.z));

    // test if the distance is enough
    if (difX>-GameInvariants::GRAB_X_SPACE*GameInvariants::GRAB_X_BACK_FACTOR && difX<GameInvariants::GRAB_X_SPACE && difZ < GameInvariants::GRAB_Z_SPACE){
        bool backGrab = other->isFacedLeft() == isFacedLeft();

        if (backGrab && !hasAnimation(GameInvariants::GRABBING_BACK) || !backGrab && !hasAnimation(GameInvariants::GRABBING_FRONT))
            return false;

        grab(other,backGrab);
        // grab, animation acordingly to where they're facing.
        if (!setAnimation(GameInvariants::GRABBING_UP)){
            if (backGrab){
                setAnimation(GameInvariants::GRABBING_BACK);
            }else
                setAnimation(GameInvariants::GRABBING_FRONT);
            testWalk();
        }

        // arrange positions: the grabbed one stays in same position
//        other->move(oldOtherPos.x-otherPos.x, oldOtherPos.z-otherPos.z);
        move(oldOtherPos.x - other->state->pos.x, oldOtherPos.z - other->state->pos.z);
        state->attackNum = 0;
        state->noMoreFlip = false; // can flip twice

        return true;
    }
    return false;
}




void CharEntity::testHit(AEntity* otherSprite){
    // TODO: this test before
    if (!hasKeyFrame()) return;

    const AHittableState* otherState = 0;
    if (!(otherState = dynamic_cast<const AHittableState*>(otherSprite->getState()))) return;

    // if the other is invincible, ignore
    if (otherState->invincible) return;

//    if (state->currentAnim->fixedFrames[state->currentFrame]->duration == 1)
//        std::cout << "first: " << (state->hitPause>0 && state->hitPause!= GameInvariants::HIT_PAUSE) << ", or second: " << (state->theHittenOnes.find(otherSprite)!=state->theHittenOnes.end()) << "\n";

    if ( state->hitPause>GameInvariants::GRAB_PAUSE
         && state->hitPause!= GameInvariants::GRAB_PAUSE + GameInvariants::HIT_PAUSE
         && state->hitPause!= GameInvariants::GRAB_PAUSE + GameInvariants::KNOCK_PAUSE
         || state->theHittenOnes.find(otherSprite)!=state->theHittenOnes.end()
    ) return;


    HitInfo hf(getHits(), lastState);
    if (hf.hits->actionType == GameInvariants::AT_THROW) return; // throw, not hit
    // only if in close Z
    if (::abs((int)(lastState->pos.z-otherState->pos.z)) > GameInvariants::GRAB_Z_SPACE) return;


    if (GameInvariants::REALIST_FACE_HIT){
        hf.fromLeft = (
            lastState->velocity.x > 0 || lastState->airPlayerVelX > 0 && !isFacedLeft()
            || lastState->velocity.x == 0 && lastState->pos.x < otherState->pos.x
        );
    }else hf.fromLeft = (!lastState->isFacedLeft() && lastState->getCurrentAnimIndex() != GameInvariants::BACK_ATTACK) || (lastState->isFacedLeft() && lastState->getCurrentAnimIndex() == GameInvariants::BACK_ATTACK);

    if (hf.hits->actionType >= GameInvariants::AT_KNOCK){
        if (hf.hits->frontalKnock) hf.fromLeft = !isFacedLeft();
        else if (hf.hits->backKnock) hf.fromLeft = isFacedLeft();
    }
    if (otherSprite->beingHit(hf) >0 ){
        // ######### game dependant
        if (state->getCurrentAnimIndex() == GameInvariants::RUN_ATTACK_STAR_0){
            state->velocity.x = 0;
        }


        //otherattackedFromLeft = otherpos.x>pos.x;

//        if (hf.hits->actionType >= GameInvariants::AT_KNOCK)
//            state->hitPause = GameInvariants::KNOCK_PAUSE;
//        else{
//            state->hitPause = GameInvariants::HIT_PAUSE;
//            // only add characters that have been hit, not knocked
//            state->theHittenOnes.insert(otherSprite);
//        }

        //state->hitPause = GameInvariants::HIT_PAUSE;
        // make the pause
        if (state->hitPause <= GameInvariants::GRAB_PAUSE){
            state->hitPause = GameInvariants::GRAB_PAUSE;
            if (hf.hits->actionType >= GameInvariants::AT_KNOCK)
                state->hitPause += GameInvariants::KNOCK_PAUSE;
            else state->hitPause += GameInvariants::HIT_PAUSE;
        }

        // regist the hit
//        if (hf.hits->actionType < GameInvariants::AT_KNOCK){
        state->theHittenOnes.insert(otherSprite);
        state->hitSomeone = true;
//        }


        // TODO: maybe different when jumping?
        //if (otherisOnBlockingMove() && isInAir())
        //    this->animationBreak();
    }
    // TODO: return type, extention to add points
}


void CharEntity::testThrow(){
    CharEntity* grabbed = getGrabbed();
    if (grabbed==0) return;

    const HitFrame* hf = getHits();
    if (hf == 0) return;

    if (hf->actionType == GameInvariants::AT_THROW){
        grabbed->beThrown(hf);
        unGrab();
    }
}





const AEntityState* CharEntity::getState() const{
    return lastState;
}

void CharEntity::setActive(bool active){
    // TODO!!
}



float CharEntity::getX() const{ return lastState->getX(); }
float CharEntity::getY() const{ return lastState->getY(); }
float CharEntity::getZ() const{ return lastState->getZ(); }



void CharEntity::updateSprite(sf::Sprite& sprite){
    if (lastAnimation != lastState->getCurrentAnimIndex()){
        lastFrame = -1;
        lastAnimation = lastState->getCurrentAnimIndex();
//        std::cout << "new animation: " << lastAnimation << "\n";
    }
    if(lastFrame != lastState->getCurrentFrame()){
        // set image
        const sf::Image& img = lastState->getCurrentImage();
        sprite.SetImage(img);
        sprite.SetSubRect(sf::IntRect(0,0,img.GetWidth(),img.GetHeight()));


        // Sound
        int sound = lastState->getFrameSound();
        if (sound != GameInvariants::NO_SOUND_INDEX){
            if (sound == currentSound){
                if (!AudioManager::replay(soundKey))
                    soundKey = AudioManager::playSound(currentSound, lastState->getX(), lastState->getY(), lastState->getZ());
            }else{
                AudioManager::stopSound(soundKey);   // this prevents from playing multiple sounds from same character
                currentSound = sound;
                soundKey = AudioManager::playSound(currentSound, lastState->getX(), lastState->getY(), lastState->getZ());
            }
        }

        // Special Effects
        const KeyFrame* kf = getCurrentKeyFrame();
        if (kf!=0 && kf->effect!=0){
            EffectsManager::addEffectToCurrentManager(kf->effect->createEffect(lastState->getX(), lastState->getY(), lastState->getZ()));
        }
    }
    AudioManager::setPosition(soundKey,lastState->getX(), lastState->getY(), lastState->getZ());


    // set some properties
    sprite.FlipX( lastState->isFacedLeft());
    sprite.SetCenter(lastState->getCenterX(),lastState->getCenterY());
//    if (facedLeft)
//        sprite.SetCenter(img->GetWidth()-center.x,center.y);
    sprite.SetPosition(lastState->getX(), lastState->getZ() - lastState->getY());
    sprite.SetRotation(lastState->getRotation());

    lastFrame = lastState->getCurrentFrame();

    if (state->getCurrentAnimIndex() == GameInvariants::DYING){
        const FixedFrame* f = state->currentAnim->fixedFrames[state->currentFrame];
        int alpha = (int)(255*(1-(state->animTimer*1.f/f->duration)));
        sprite.SetColor(sf::Color(255,alpha,alpha,alpha));
    }else if (sprite.GetColor().a != 255){
        int alpha = std::max(0,(int)(200-state->getY()));
        alpha*=alpha;
        if (alpha>255) alpha = 255;
        sprite.SetColor(sf::Color(alpha,255,255,alpha));
    }
}
