#ifndef AI_FF_BONGO_H_INCLUDED
#define AI_FF_BONGO_H_INCLUDED


#include "AITrivialController.h"


/**
 * Control by keyboard input
 * it comes from system events (OSInput)
 *
 * @author Gil Costa
 */
class AIFFBongo: public AITrivialController{
    protected:
        int runCount;
    public:
        AIFFBongo();
        AIFFBongo(AControlledEntity* entity);

        void applyKeys();
};

#endif // AI_FF_BONGO_H_INCLUDED
