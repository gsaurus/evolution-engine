#include "View.h"

//#include <iostream>

// --------------------
//  -- CONSTRUCTORS --
// --------------------

View::View(AObject* obj): obj(obj){}

View::~View(){
    // does nothing
}



// ---------------
//  -- METHODS --
// ---------------


bool View::update(){
    obj->updateSprite(sprite);
    return updateZOrder();
}


bool View::updateZOrder(){
    int oldZ = zOrder;
    // update zOrder with z pos of the entity
    zOrder = (int)(obj->getZ());
    return oldZ != zOrder;
}


void View::display(sf::RenderTarget* target){
    target->Draw(sprite);
}

/** Comparison Operator */
bool operator<(const View& a, const View& b){
    return a.zOrder < b.zOrder;
}


int View::getIdKey(){
    return obj->getKey();
}
