#ifndef SCENE_STATE_H_INCLUDED
#define SCENE_STATE_H_INCLUDED

#include "AState.h"

/**
 * Represents the full state on a scene
 *
 * @author Gil Costa
 */
class SceneState: public AState{

};

#endif // GAME_STATE_H_INCLUDED
