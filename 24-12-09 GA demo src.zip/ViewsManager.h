#ifndef DISPLAYMANAGER_H_INCLUDED
#define DISPLAYMANAGER_H_INCLUDED

#include "AUpdateAndDisplay.h"
#include "View.h"
#include "HashMap.h"

/**
 * Keeps the active views and display them
 * It has the objects representations (views),
 * not the objects themselves
 *
 * @author Gil Costa
 */
class ViewsManager: public AUpdateAndDisplay{
    protected:
        /** Functor for views ordering */
        struct ViewsFunctor {
           bool operator( )(const View* v1, const View* v2) {
              return(*v1 < *v2);
           }
        };

        typedef std::multiset<View*, ViewsFunctor> ViewsMultiset;

         /**
         *  All views here
         * Characters, goodies, boxes, and all other entities
         */
        ViewsMultiset views;
        //HashMap<int,View*> viewsMap; // doesn't worth for a few sprites and few removals
    public:

        /** Add a new EntityView */
        void addView(View* view);

        /** delete the view(s) from the entity with the given key */
        void deleteView(int key);
        /** remove the first view with that key */
        View* removeView(int key);

        bool update();
        void display(sf::RenderTarget* target);
};


#endif // DISPLAYMANAGER_H_INCLUDED
