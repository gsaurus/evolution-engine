#include "ALayerData.h"

#include "GameInvariants.h"
#include "ControlsMapper.h"
#include "DataBase.h"
#include "MatrixLayerData.h"
#include "DiscretLayerData.h"




// default constructor
ALayerData::ALayerData():AFileResolver(GameInvariants::LAYERS_VERSION){
    // Does nothing
}


// Destructor
ALayerData::~ALayerData(){
    // delete animations
    if (!anims.empty()){
        std::vector<AnimatedScenary*>::iterator it1 = anims.begin();
        for(; it1!=anims.end(); ++it1){
            delete *it1;
        }
    }
}



void ALayerData::readData(DataInputStream& dis) throw(IOException){
    int size = dis.readByte();
    dataFilename.clear(); dataFilename.reserve(size);
    for(int j=0 ; j<size ; ++j)
         dataFilename.push_back((char)dis.readByte()); // v1.1

    type = dis.readByte();
    width = dis.readInt16();
    height = dis.readInt16();

    // -- read animations --
    // read number of animations
    int N = dis.readInt16();
    anims.reserve(N);
    // read all animations
    for(int i=0; i<N ; ++i){
        AnimatedScenary* a = new AnimatedScenary();
        a->readData(dis);
        anims.push_back(a);
    }

    readObjects(dis);
}



// update
bool ALayerData::update(){
    bool res = false;
    // update animations
    std::vector<AnimatedScenary*>::iterator it;
    for(it = anims.begin() ; it!=anims.end() ; ++it)
        res |= (*it)->update();
    return res;
}



//-----------------------------------------
// -- Getters, Setters, usefull methods --

int ALayerData::getWidth() const{ return width; }
int ALayerData::getHeight() const{ return height; }
int ALayerData::getType() const{ return type; }
