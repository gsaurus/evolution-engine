#ifndef AHEADER_H_INCLUDED
#define AHEADER_H_INCLUDED

/**
 * Represents the main info of an entity,
 * not about instantiations of the entity
 *
 * @author Gil Costa
 */
class AHeader{
    public:
        virtual ~AHeader(){}
        /** load the information from the dataBase */
        virtual void loadData()=0;
        /** say if the entity resources are full loaded */
        virtual bool ready() const throw() = 0;
};

#endif // AHEADER_H_INCLUDED
