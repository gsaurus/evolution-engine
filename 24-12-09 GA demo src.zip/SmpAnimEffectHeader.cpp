#include "SmpAnimEffectHeader.h"
#include "GameInvariants.h"
#include "SmpAnimEffect.h"

//#include <iostream>


SmpAnimEffectHeader::SmpAnimEffectHeader(DataInputStream& dis) throw(IOException){
    readData(dis);
}

SmpAnimEffectHeader::SmpAnimEffectHeader(const std::string& fileName) throw(IOException){
    std::string trueFileName(GameInvariants::ANIMATIONS_DIR);
    trueFileName.append(fileName);
    animation.setFileName(trueFileName);
    animation.load();
    animation.loadData();
}

void SmpAnimEffectHeader::readData(DataInputStream& dis) throw(IOException){
    std::string fileName(GameInvariants::ANIMATIONS_DIR);
    int size = dis.readByte();
    fileName.reserve(fileName.size() + size);
    for(int j=0; j<size; j++)
         fileName.push_back((char)dis.readByte());
    delta.x = dis.readInt16();
    delta.y = dis.readInt16();
    delta.z = dis.readInt16();

    animation.setFileName(fileName);
    animation.load();
    animation.loadData();
}




AEffect* SmpAnimEffectHeader::createEffect(float x, float y, float z){
    return new SmpAnimEffect(&animation, x+delta.x, y+delta.y, z+delta.z);
}
