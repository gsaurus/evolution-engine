#ifndef JOYSTICK_CONTROLLER_H_INCLUDED
#define JOYSTICK_CONTROLLER_H_INCLUDED


#include "AController.h"

/**
 * Control by joystick input
 * it comes from system events (OSInput)
 *
 * @author Gil Costa
 */
 //TODO


#endif // JOYSTICK_CONTROLLER_H_INCLUDED
