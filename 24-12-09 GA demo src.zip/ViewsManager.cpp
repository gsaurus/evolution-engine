#include "ViewsManager.h"

#include <list>

#include <iostream>


void ViewsManager::addView(View* view){
    //viewsMap[key] = view;
    views.insert(view);
}


void ViewsManager::deleteView(int key){
    // find the occorrences
    ViewsMultiset::iterator it = views.begin();
    std::list<ViewsMultiset::iterator> toRemove;
    for(;it!=views.end(); ++it){
        if ((*it)->getIdKey()==key)
            toRemove.push_back(it);
    }

    // delete them
    std::list<ViewsMultiset::iterator>::iterator removeIt = toRemove.begin();
    for(; removeIt!=toRemove.end(); ++removeIt){
        views.erase(*removeIt);
        delete **removeIt;
    }

}


View* ViewsManager::removeView(int key){
    // find the occorrences
    ViewsMultiset::iterator it = views.begin();
    for(;it!=views.end(); ++it){
        if ((*it)->getIdKey()==key){
            View* res = *it;
            views.erase(it);
            return res;
        }
    }
    return 0;
}





bool ViewsManager::update(){
    // update all views, and store the list of changed ones
    std::list<ViewsMultiset::iterator> changedOrder;
    ViewsMultiset::iterator it;
    for( it = views.begin(); it!=views.end(); ++it){
        if ((*it)->update()){
            changedOrder.push_back(it);
        }
    }
    // remove and insert the changed views to keep the set ordered
    std::list<ViewsMultiset::iterator>::iterator changeIt;
    for( changeIt = changedOrder.begin(); changeIt!=changedOrder.end(); ++changeIt){
        views.erase(*changeIt);
        views.insert(**changeIt);
    }
    return !changedOrder.empty();
}

void ViewsManager::display(sf::RenderTarget* target){
    // TODO: the offset depends on the layer!
    ViewsMultiset::iterator it;
    for( it = views.begin(); it!=views.end(); ++it)
        (*it)->display(target);
}
