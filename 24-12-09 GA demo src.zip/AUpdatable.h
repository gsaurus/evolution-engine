#ifndef AUPDATABLE_H_INCLUDED
#define AUPDATABLE_H_INCLUDED

/**
 * Interface for updatable objects
 *
 * @author Gil Costa
 */
class AUpdatable{
    public:
        virtual ~AUpdatable(){}
        /** return true if the update changes the object */
        virtual bool update() = 0;
};

#endif // AUPDATABLE_H_INCLUDED
