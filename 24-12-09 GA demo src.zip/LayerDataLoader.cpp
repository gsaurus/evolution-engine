#include "LayerDataLoader.h"

#include "GameInvariants.h"
#include "ControlsMapper.h"
#include "DataBase.h"
#include "MatrixLayerData.h"
#include "DiscretLayerData.h"




// default constructor
LayerDataLoader::LayerDataLoader():ALayerData(){
    // Does nothing
}




// loads accordingly to the type of LayerDataLoader
ALayerData* LayerDataLoader::loadLayerData(const std::string& fileName) throw(IOException){
    setFileName(fileName);
    load();
    // at this time, the layer object is loaded
    return layer;
}


//-----------------------------
// ------- LOAD / SAVE -------

void LayerDataLoader::readData(DataInputStream& dis) throw(IOException){
    int size = dis.readByte();
    dataFilename.clear(); dataFilename.reserve(size);
    for(int j=0 ; j<size ; ++j)
         dataFilename.push_back((char)dis.readByte()); // v1.1

    type = dis.readByte();

    // -- That's enough, now it's up to layer obj --
    if (type == GameInvariants::MATRIX_LAYER_TYPE){
        layer = new MatrixLayerData();
    }else{
        layer = new DiscretLayerData();
    }
    // copy whatever was already loaded
    layer->dataFilename = dataFilename;
    layer->type = type;

    // keep loading the rest:

    layer->width = dis.readInt16();
    layer->height = dis.readInt16();

    // -- read animations --
    // read number of animations
    int N = dis.readInt16();
    layer->anims.reserve(N);
    // read all animations
    for(int i=0; i<N ; ++i){
        AnimatedScenary* a = new AnimatedScenary();
        a->readData(dis);
        layer->anims.push_back(a);
    }

    // -- read layer objects --
    layer->readObjects(dis);
}





void LayerDataLoader::readObjects(DataInputStream& dis) throw(IOException){
    // Not used, does nothing
}
void LayerDataLoader::loadData(){
    // Not used, does nothing
}
bool LayerDataLoader::ready() const throw(){
    // Not used, does nothing
    return false;
}

bool LayerDataLoader::applyToSprite(sf::Sprite& sprite, int index) const{
    // Not used, does nothing
    return false;
}

UInt LayerDataLoader::getNumObjects() const{
    // Not used, does nothing
    return 0;
}
int LayerDataLoader::getFrameWidth(int index) const{
    // Not used, does nothing
    return 0;
}
int LayerDataLoader::getFrameHeight(int index) const{
    // Not used, does nothing
    return 0;
}
