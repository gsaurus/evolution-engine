#ifndef ANIMATED_SCENARY_H_INCLUDED
#define ANIMATED_SCENARY_H_INCLUDED

#include <vector>

#include "AAnimation.h"
#include "AUpdatable.h"
#include "TypeUtils.h"


/**
 * AnimatedScenary data
 * @see AReadable.h
 *
 * @author Gil Costa
 */
class AnimatedScenary: public AAnimation, AUpdatable{
  public:

    //--------------
    // -- FIELDS --
    //--------------

    UInt time;
    UInt currFrame;


    //--------------------
    // -- CONSTRUCTORS --
    //--------------------
    AnimatedScenary();
    // destructor
//    ~AnimatedScenary();


    //---------------
    // -- METHODS --
    //---------------
//    void computeTotalTime();

//    void readData(DataInputStream& dis) throw(IOException);
    //void writeData(DataOutputStream& dos) throw(IOException);

    bool update();
    UInt getCurrFrame();


};


#endif // ANIMATED_SCENARY_H_INCLUDED
