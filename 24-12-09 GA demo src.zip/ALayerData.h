#ifndef ALAYER_DATA_H_INCLUDED
#define ALAYER_DATA_H_INCLUDED

#include <vector>
#include <string>
#include <SFML/Graphics.hpp>

#include "AFileResolver.h"
#include "AnimatedScenary.h"
#include "AHeader.h"
#include "AUpdatable.h"
#include "TypeUtils.h"

/**
 * ALayerData files
 * @see AReadable.h
 *
 * @author Gil Costa
 */
class ALayerData: public AFileResolver, AHeader, AUpdatable{
    public:

        // TODO: fields are to be protected?

        // --------------
        //  -- Fields --
        // --------------

        /** A fixed set of animations */
        std::vector<AnimatedScenary*> anims;    // set of  defined animations
        // --> implementations have to have the layer objects somehow


        std::string dataFilename; // where to load data (images, etc)

        UByte type; // horizontal, vertical or matrix
        int width;
        int height;


        // ---------------
        //  -- Methods --
        // ---------------


        //-------------------------------
        // -- Initializations and etc --

        /** default constructor */
        ALayerData();
        /** destructor */
        virtual ~ALayerData();


        //-----------------------------------------
        // -- Getters, Setters, usefull methods --

        int getWidth() const;
        int getHeight() const;
        int getType() const;
        virtual UInt getNumObjects() const = 0;
        virtual int getFrameWidth(int index) const = 0;
        virtual int getFrameHeight(int index) const = 0;


        //-----------------------------
        // ------- LOAD / SAVE -------

        virtual void readData(DataInputStream& dis) throw(IOException);
        //void writeHeader(DataOutputStream& dos) throw(IOException);

        virtual void readObjects(DataInputStream& dis) throw(IOException) = 0;


        /** load the information from the dataBase @see AHeader */
        virtual void loadData() = 0;
        /** say if the entity resources are full loaded @see AHeader */
        virtual bool ready() const throw() = 0;

        /** update (animations) */
        virtual bool update();


        virtual bool applyToSprite(sf::Sprite& sprite, int index) const = 0;

};



#endif // ALAYER_DATA_H_INCLUDED
