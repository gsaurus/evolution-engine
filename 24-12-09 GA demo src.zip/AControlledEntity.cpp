#include "AControlledEntity.h"


//const int key::UP    = 0;
//const int key::DOWN  = 1;
//const int key::LEFT  = 2;
//const int key::RIGHT = 3;
//const int key::A     = 4;
//const int key::B     = 5;
//const int key::C     = 6;
//const int key::D     = 7;
//const int key::E     = 8;
//const int key::F     = 9;
//const int key::START = 10;
//const int key::CALL  = 11;



AControlledEntity::~AControlledEntity(){
    // do nothing
}

void AControlledEntity::testHit(AEntity* otherSprite){ /* does nothing */ }
void AControlledEntity::testThrow(){ /* does nothing */ }
