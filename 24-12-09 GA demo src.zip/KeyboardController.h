#ifndef KEYBOARD_CONTROLLER_H_INCLUDED
#define KEYBOARD_CONTROLLER_H_INCLUDED


#include "AController.h"

#include <vector>
#include <SFML/Graphics.hpp>

/**
 * Control by keyboard input
 * it comes from system events (OSInput)
 *
 * @author Gil Costa
 */
class KeyboardController: public AController{
    protected:
        /** key mapping */
        std::map<sf::Key::Code,UInt> keyMapper;
    public:
        KeyboardController();
        KeyboardController(AControlledEntity* entity);

        // Temporarly set. TODO: better
        void setKeys(const sf::Key::Code up, sf::Key::Code down, sf::Key::Code left, sf::Key::Code right,
                            sf::Key::Code a, sf::Key::Code b, sf::Key::Code c, sf::Key::Code d, sf::Key::Code e, sf::Key::Code f,
                            sf::Key::Code start, sf::Key::Code call);
        void setKey(sf::Key::Code key, UInt val);
        void applyKeys();
};

#endif // KEYBOARD_CONTROLLER_H_INCLUDED
