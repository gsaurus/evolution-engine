#include "CharState.h"

#include "GameInvariants.h"
//#include "AudioManager.h"

#include <iostream>

// --------------------
//  -- Constructors --
// --------------------

CharState::CharState():
    // put some pointers as null
    AHittableState(),
    charObj(0),
    charHeader(0),
    bodyObj(0),
    headObj(0),
    grabbedOne(0),
    theGrabber(0),
    grabbedToThrow(false),
    name(0),
    currentAnim(0),
    waitingDamage(0)
{
    // init presses to false
    // TODO: better?
    presses.resize(GameInvariants::NUM_KEYS, false);
//    presses[GameInvariants::Key::UP] = false;
//    presses[GameInvariants::Key::DOWN] = false;
//    presses[GameInvariants::Key::LEFT] = false;
//    presses[GameInvariants::Key::RIGHT] = false;
//    presses[GameInvariants::Key::A] = false;
//    presses[GameInvariants::Key::B] = false;
//    presses[GameInvariants::Key::C] = false;
//    presses[GameInvariants::Key::D] = false;
//    presses[GameInvariants::Key::E] = false;
//    presses[GameInvariants::Key::F] = false;
//    presses[GameInvariants::Key::START] = false;
//    presses[GameInvariants::Key::CALL] = false;
}


//CharState::CharState(const CharState* other):
//    AHittableState(other),
//    // -----------------
//        //  -- Pos & Vel --
//
//        sf::Vector3f velocity;
//        float rotation;
//        float rotationalVel;
//
//
//        // -----------------
//        //  -- Data info --
//
//        const Character* charObj;
//        CharacterHeader* charHeader;     // needed for complete state info
//        const FramesCollection* bodyObj;
//        const FramesCollection* headObj;
//
//
//        // ---------------------
//        //  -- Grabbing info --
//
//        /** grabbing someone? Who? */
//        CharEntity* grabbedOne;
//        /** grabbing someone from its back */
//        bool grabbingOnBack;
//
//
//        // --------------------------
//        //  -- Being grabbed info --
//
//        /** being grabbed by someone? Who? */
//        CharEntity* theGrabber;
//        /** being grabbed from back */
//        bool grabbedBack;
//
//        const std::string* name;
//        UInt nameIndex;
//
//
//        // ----------------------
//        //  -- Animation info --
//
//        /** the current animation */
//        UInt currAnimIndex;
//        const Animation* currentAnim;
//        /** the current frame # of the current animation */
//        int currentFrame;
//        /** timer to play the animation in it's correct time */
//        int animTimer;
//
//
//        // ----------------------------
//        //  -- Player extra control --
//
//        bool movingLeft;
//        bool movingRight;
//        bool movingUp;
//        bool movingDown;
//        bool running;   // running or runJump
//        bool facedLeft;
//
//        beingThrown;
//
//        // player controlled velocity in air
//        airPlayerVelX;
//        airPlayerVelZ;
//
//
//
//
//        // ===========================
//        //  ----- CONTROL STUFF -----
//        // ===========================
//        // what is the sprite doing atm?
//
//
//        theHittenOnes;  //
//
//        runTime;  // timer to run (count the double forward)
//
//        attackNum;        // number of the attack animation being done
//        attackCounter;    // if no attack, the previous counter is reseted
//
//        knockCounter;     // counter for the time B is pressed
//
//        hitPause;
//        recoverTime;
//        ungrabTime;       // time to ungrab by pressing inverse key
//        blockHitTime;     // time to move back when blocking a hit
//        noMoreFlip;        // can only flip twice
//
//        setRun;
//        tryingRoll;       // is trying a roll instead of run?
//        gotHit;
//        gotKnocked;
//        hitSomeone;
//{}


bool CharState::isFacedLeft() const{ return facedLeft; }
const sf::Vector2i& CharState::getCenter() const{ return center; }
int CharState::getCenterX() const{ return center.x; }
int CharState::getCenterY() const{ return center.y; }
float CharState::getRotation() const{ return rotation; }



const sf::Image& CharState::getCurrentImage() const{
    int index = currentAnim->fixedFrames[currentFrame]->frameIndex;
    return bodyObj->get(index).getImage();
}

int CharState::getFrameSound() const{
    if ((UInt)currentFrame == currentAnim->soundFrame)
        return currentAnim->sound;
    else return GameInvariants::NO_SOUND_INDEX;
}

int CharState::getCurrentFrame() const{
    return currentFrame;
}

int CharState::getCurrentAnimIndex() const{
    return currAnimIndex;
}



//void CharState::updateSprite(sf::Sprite& sprite, int delta) const{
//    // index calculation:
//    int frame;
//    if (delta>0) frame = std::min(currentFrame + delta,(int)(currentAnim->fixedFrames.size()-1));
//    else frame = std::max(currentFrame + delta,(int)0);
//    int index = currentAnim->fixedFrames[frame]->frameIndex;
//    // get image from the state:
//    const sf::Image* img;
//    if (index > bodyObj->size()) img = &bodyObj->get(0).getImage();
//    else img = &bodyObj->get(index).getImage();
//    // set image into sprite:
//    sprite.SetImage(*img);
//    sprite.SetSubRect(sf::IntRect(0,0,img->GetWidth(),img->GetHeight()));
//
//    // change center point:
////    const Point16& pt = bodyObj->get(index).getCM();
//
//    // if fliped, flip the center
//    sprite.FlipX(facedLeft);
////    if (facedLeft)
////        sprite.SetCenter(img->GetWidth()-center.x,center.y);
//    sprite.SetCenter(center.x,center.y);
//
//    // change position:
//    sprite.SetPosition(pos.x, pos.z-pos.y);
//    // change rotation:
//    sprite.SetRotation(rotation);
//
//
//    // Sound
//    if ((UInt)frame == currentAnim->soundFrame)
//        AudioManager::playSound(currentAnim->sound, pos.x, pos.y, pos.z);
//
//}



// -----------------------
//  -- Control Methods --
// -----------------------


//void CharState::(FixedFrame* frame){
//
//}
//
//
//
//void CharState::updatePlayerVelComponent(float& posComp, float& airVel, bool negative, bool vertical=false){
//
//}
//
//
//void CharState::updatePlayerVelocity(){
//
//}
//
//void CharState::updatePosition(){
//
//}
//
//
//void CharState::updateCenterPoint(){
//
//}
//
//
//void CharState::updateGrabbedPosition(){
//
//}
