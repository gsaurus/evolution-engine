#ifndef DISCRET_LAYER_DATA_H_INCLUDED
#define DISCRET_LAYER_DATA_H_INCLUDED

#include <vector>
#include <string>

#include "FramesCollection.h"
#include "AFileResolver.h"
#include "AnimatedScenary.h"
#include "AHeader.h"
#include "LayerObj.h"
#include "AUpdatable.h"

class LayerObj;
/**
 * DiscretLayerData files
 * @see AReadable.h
 *
 * @author Gil Costa
 */
class DiscretLayerData: public ALayerData{
    public:

        std::vector<LayerObj*> objects;         // ordered by Z

        const FramesCollection* collection;




        // ----------------------------------
        //  --- Constructors/Destructors ---

        /** default constructor */
        DiscretLayerData();
        /** destructor */
        ~DiscretLayerData();


        //-----------------------------
        // ------- LOAD / SAVE -------


        void readObjects(DataInputStream& dis) throw(IOException);


        /** load the information from the dataBase @see AHeader */
        void loadData();
        /** say if the entity resources are full loaded @see AHeader */
        bool ready() const throw();


        //-----------------------
        // --- Usefull stuff ---

        bool applyToSprite(sf::Sprite& sprite, int index) const;
        UInt getNumObjects() const;
        int getFrameWidth(int index) const;
        int getFrameHeight(int index) const;
        LayerObj* getLayerObj(int index) const;

};



#endif // DISCRET_LAYER_DATA_H_INCLUDED
