#ifndef CHARSTATE_H_INCLUDED
#define CHARSTATE_H_INCLUDED

#include "AEntity.h"
#include "AHittableState.h"

#include "Character.h"
#include "CharacterHeader.h"
#include "FramesCollection.h"
#include "Pallet.h"

#include <SFML/Graphics.hpp>

class CharacterHeader;
class CharEntity;
class AEntity;

/**
 * State of a character
 *  - one of the most important classes
 *  - has all information about the character, like:
 *       - position (from AEntityState), velocity
 *       - rotation, rotation velocity
 *       - frames collections references for body and head
 *       - ...
 *
 *
 * @author Gil Costa
 */
class CharState: public AHittableState{
    public:

        // -----------------
        //  -- Pos & Vel --

        sf::Vector3f velocity;
        float rotation;
        float rotationalVel;

        /** center of the current frame */
        sf::Vector2i center;


        // -----------------
        //  -- Data info --

        const Character* charObj;
        CharacterHeader* charHeader;     // needed for complete state info
        const FramesCollection* bodyObj;
        const FramesCollection* headObj;


        // ---------------------
        //  -- Grabbing info --

        /** grabbing someone? Who? */
        CharEntity* grabbedOne;
        /** grabbing someone from its back */
        bool grabbingOnBack;


        // --------------------------
        //  -- Being grabbed info --

        /** being grabbed by someone? Who? */
        CharEntity* theGrabber;
        /** being grabbed from back */
        bool grabbedBack;

        /** grabbing someone from its back, ready to throw! */
        bool grabbedToThrow;

        const std::string* name;
        UInt nameIndex;


        // ----------------------
        //  -- Animation info --

        /** the current animation */
        UInt currAnimIndex;
        const Animation* currentAnim;
        /** the current frame # of the current animation */
        int currentFrame;
        /** timer to play the animation in it's correct time */
        int animTimer;


        // ----------------------------
        //  -- Player extra control --

        bool movingLeft;
        bool movingRight;
        bool movingUp;
        bool movingDown;
        bool running;   // running or runJump
        bool facedLeft;

        bool beingThrown;

        // player controlled velocity in air
        float airPlayerVelX;
        float airPlayerVelZ;

        // damage to apply after hit the ground (for throws)
        int waitingDamage;




        // ===========================
        //  ----- CONTROL STUFF -----
        // ===========================
        // what is the sprite doing atm?

        /** state of the keys: pressed or released */
        std::vector<bool> presses;

        std::set<AEntity*> theHittenOnes;  //

        UByte runTime;  // timer to run (count the double forward)

        UByte attackNum;        // number of the attack animation being done
        UByte attackCounter;    // if no attack, the previous counter is reseted
        UByte attackWaitTolerance;       // waiting to perform attack

        UByte knockCounter;     // counter for the time B is pressed

        UByte hitPause;
        UByte afterAttackPause;
        UByte recoverTime;
        UByte ungrabTime;       // time to ungrab by pressing inverse key
        UByte blockHitTime;     // time to move back when blocking a hit
        bool noMoreFlip;        // can only flip twice

        bool setRun;
        bool tryingRoll;       // is trying a roll instead of run?
        bool gotHit;
        bool gotKnocked;
        bool hitSomeone;



    // --------------------
    //  -- Constructors --
    // --------------------

    public:
        /** default constructor */
        CharState();

        /**
         * copy constructor
         * pre: other != null
         */
//        CharState(const CharState* other);





    // --------------------
    //  -- Util Methods --
    // --------------------
    bool isFacedLeft() const;
    const sf::Vector2i& getCenter() const;
    int getCenterX() const;
    int getCenterY() const;
    float getRotation() const;
    const sf::Image& getCurrentImage() const;

    int getFrameSound() const;

    int getCurrentFrame() const;
    int getCurrentAnimIndex() const;

    /**
     * update the sprite with a frame that is distanciated from the current by delta
     * update a sprite with this character state
     * TODO: this shouldn't be done here!
     * NOTE: this method is "Just In Case" (TODO?)
     */
//    void updateSprite(sf::Sprite& sprite, int delta = 0) const;


    // -----------------------
    //  -- Control Methods --
    // -----------------------

//    protected:
//        /** changes the current frame */
//        void setFrame(FixedFrame* frame);
//
//
//        /** get a velocity componet based on the character state */
//        void updatePlayerVelComponent(float& posComp, float& airVel, bool negative, bool vertical=false);
//
//        /** Control walk, jump and other animations that allows horizontal and/or vertical user movement */
//        void updatePlayerVelocity();
//        /** update current position, accordingly to the velocity */
//        void updatePosition(); // TODO: may need something else for fast walk, easy to change though
//
//        /** update the center point */
//        void updateCenterPoint();
//
//        /** update the grabbed one position */
//        void updateGrabbedPosition();


};


#endif // CHARSTATE_H_INCLUDED
