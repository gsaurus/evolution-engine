#ifndef AENTITYSTATE_H_INCLUDED
#define AENTITYSTATE_H_INCLUDED

#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>

#include "AState.h"

/**
 * State of an entity
 * have at least:
 *   - position
 *   -(in)active state
 *
 * @author Gil Costa
 */
class AEntityState: public AState{
    public:

        // ----------------
        //  --- FIELDS ---
        // ----------------

//        /** Identification */
//        int id;

        /**
         * if the entity is active, or just being in some simulated way
         * being active means that it responds to colisions, events, etc
         */
        bool active;
        bool waitingRemoval;

        /** every entity has a position in World Coordinates (x,y,z) */
        sf::Vector3f pos;


        // --------------------
        //  -- Constructors --
        // --------------------

        /** default constructor */
        AEntityState();
        /**
         * copy constructor
         * pre: other != null
         */
        AEntityState(const AEntityState* other);
        /** virtual destructor */
        virtual ~AEntityState();




        // -----------------------
        //  --- Const Getters ---
        // -----------------------

        bool isActive() const;
        bool isWaitingRemoval() const;

        /** return true if the entity is faced left */
        virtual bool isFacedLeft() const;

        const sf::Vector3f& getPos() const;
        float getX() const;
        float getY() const;
        float getZ() const;


        // --------------------
        //  -- Util Methods --
        // --------------------

//        virtual void updateSprite(sf::Sprite& sprite) const = 0;
};

#endif // AENTITYSTATE_H_INCLUDED
