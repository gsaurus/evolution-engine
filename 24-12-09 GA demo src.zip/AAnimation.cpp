#include "AAnimation.h"



//--------------------
// -- CONSTRUCTORS --
//--------------------
AAnimation::AAnimation(){
    // does nothing
}

AAnimation::~AAnimation(){
    // remove animation frames
    std::vector<AnimFrame*>::iterator it1 = frames.begin();
    for(; it1!=frames.end(); ++it1){
        delete *it1;
    }
}


//---------------
// -- METHODS --
//---------------




//void AAnimation::computeTotalTime(){
//    totalTime = 0;
//    std::vector<AnimatedFrame*>::const_iterator it;
//    for(it = AnimatedFrames.begin(); it!=AnimatedFrames.end(); ++it)
//        totalTime+=(*it)->duration;
//}


UInt AAnimation::getFrameDuration(int frameIndex) const{
    return frames[frameIndex]->duration;
}

UInt AAnimation::size() const{
    return frames.size();
}


void AAnimation::readData(DataInputStream& dis) throw(IOException){

    // read frames
    int size = dis.readInt16();
    frames.reserve(size);
    for(int i=0; i<size; ++i){
        AnimFrame* f = new AnimFrame();
        f->readData(dis);
        frames.push_back(f);
    }
}


