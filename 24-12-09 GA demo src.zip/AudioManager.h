#ifndef AUDIO_MANAGER_H_INCLUDED
#define AUDIO_MANAGER_H_INCLUDED

#include <SFML/Audio.hpp>

#include "HashMap.h"
#include "IOException.h"
#include "GameInvariants.h"

/**
 * Controls everything about sound
 *   - play sounds
 *   - play musics
 *   - control sound effects
 *   - ...
 *
 * @author Gil Costa
 */
class AudioManager{
    // ----------------
    //  --- Sounds ---
    // ----------------
    private:
        static std::string folder;
        static std::vector<sf::SoundBuffer*> systemSounds;
        static HashMap<int,sf::SoundBuffer*> specificSounds;

        static HashMap<int, sf::Sound*> playingSounds;
        static int keyGen;  // generates sound keys

    public:

        static void setFolder(const std::string& folder);
        static const std::string& getFolder();

        /** Load system sounds */
        static void loadSystemSounds() throw(IOException);
        /** Load specific sounds */
        static void loadSpecificSound(int soundNumber) throw(IOException);
        static void clearSpecificSound(int soundNumber);
        static void clearAllSpecificSounds();
        static void clearAllSounds();
        static void clearPlayingSounds();


        /** play the specified sound, return the generated sound key , for future access */
        static int playSystemSound(int srcIndex, float x = 0, float y = 0, float z = 0 );
        /** play the specified sound, return the generated sound key , for future access */
        static int playSound(
                                int srcIndex, float x = 0, float y = 0, float z = 0,
                                float minDistance = GameInvariants::SOUND_MIN_DISTANCE,
                                float attenuation = GameInvariants::SOUND_ATTENUATION,
                                float pitch = 1
                            );

        static void stopSound(int key);

        /** replay a currently playing sound*/
        static bool replay(int key);


        /** change sound position */
        static bool setPosition(int key, float x, float y, float z);
        /** change sound volume */
        static bool setVolume(int key, float volume);
        /** change sound pitch */
        static bool setPitch(int key, float pitch);
        /** change sound attenuation */
        static bool setAttenuation(int key, float minDistance, float attenuation);

        static bool isPlaying(int key);



        /** find what sounds are inactive, and clear them */
        static void clearInactiveSounds();




        static void updateListener(float x, float y, float z);

        static void setGlobalVolume(float volume);




    // ----------------
    //  --- Musics ---
    // ----------------

//    private:
//        /** musics, the second value is the playback time */
//        static std::list<std::pair<sf::Music*, float> > playingMusics;
//    public:
//
//        /** Load music, return it's index on list */
//        static int loadMusic(const std::string& fileName) throw(IOException);
//        static void clearMusic(int musicIndex);
//        static void clearAllMusics();
//
//
//        /** play the specified sound, return the generated sound key , for future access */
//        static int playSystemSound(int srcIndex, int x = 0, int y = 0, int z = 0 );
//        /** play the specified sound, return the generated sound key , for future access */
//        static int playSpecificSound(int srcIndex, int x = 0, int y = 0, int z = 0 );
//
//
//        /** change sound position */
//        static bool setPosition(int key, int x, int y, int z);
//        /** change sound volume */
//        static bool setVolume(int key, float volume);
//        /** change sound pitch */
//        static bool setPitch(int key, float pitch);
//        /** change sound attenuation */
//        static bool setAttenuation(int key, float attenuation, float minDistance);
//
//
//
//        /** find what sounds are inactive, and clear them */
//        static void clearInactiveSounds();
};

#endif // AUDIO_MANAGER_H_INCLUDED
