#ifndef AVIEW_H_INCLUDED
#define AVIEW_H_INCLUDED

#include <SFML/Graphics.hpp>

#include "AUpdateAndDisplay.h"
#include "AObject.h"

/**
 * The way an entity is represented
 * (not necessarly graphically)
 * Note1: update method is to ask entity about it's current state
 * Note2: display is to show the entity on the render target
 *
 * @author Gil Costa
 */
class View: public AUpdateAndDisplay{
    protected:
        /** the object logics */
        AObject* obj;
        /** A sprite to show the object */
        sf::Sprite sprite;

        /** zOrder, it is obtained from the object */
        int zOrder;

        bool updateZOrder();
    public:

        // --------------------
        //  -- CONSTRUCTORS --
        // --------------------

        /** Default Constructor */
        View(AObject* obj);
        /** Destructor */
        ~View();


        // ---------------
        //  -- METHODS --
        // ---------------

        /**
         * change accordingly to object update(sf::Sprite)
         * @see AUpdatable
         */
        bool update();

        /**
         * show the object on the given RenderTarget
         * @see ADisplayable
         */
        void display(sf::RenderTarget* target);

        /** return the value of the object key */
        int getIdKey();

//        /** When an entity dies or something, the view must be so */
//        virtual bool waitingDestruction() const = 0;

        /** Comparison Operator */
        friend bool operator<(const View& a, const View& b);
};

#endif // AVIEW_H_INCLUDED
