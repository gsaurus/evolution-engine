#ifndef LEVEL_H_INCLUDED
#define LEVEL_H_INCLUDED

/**
 * Level definition: group of GameScenes and CutScenes
 *
 * @author Gil Costa
 */
class Level{

};

#endif // LEVEL_H_INCLUDED
