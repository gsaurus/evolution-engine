#include "SimpleAnimation.h"

#include "DataBase.h"



//--------------------
// -- CONSTRUCTORS --
//--------------------
SimpleAnimation::SimpleAnimation():AAnimation(),AFileResolver(1), collectionName(""), collection(0){
    // does nothing
}

//SimpleAnimation::~SimpleAnimation(){
//}


//---------------
// -- METHODS --
//---------------




//void SimpleAnimation::computeTotalTime(){
//    totalTime = 0;
//    std::vector<AnimatedFrame*>::const_iterator it;
//    for(it = AnimatedFrames.begin(); it!=AnimatedFrames.end(); ++it)
//        totalTime+=(*it)->duration;
//}


void SimpleAnimation::readData(DataInputStream& dis) throw(IOException){
    // read collection name
    int size = dis.readByte();
    collectionName.clear(); collectionName.reserve(size);
    for(int j=0 ; j<size ; ++j)
         collectionName.push_back((char)dis.readByte()); // v1.1
    // read frames
    AAnimation::readData(dis);
}


const Frame& SimpleAnimation::getFrame(int frameIndex) const{
    return collection->get(frames[frameIndex]->frameIndex);
}


bool SimpleAnimation::applyToSprite(sf::Sprite& sprite, int index) const{
    const Frame& f = collection->get(frames[index]->frameIndex);
    sprite.SetImage(f.getImage());
    sprite.SetCenter(f.getCM().x, f.getCM().y);
    return true;
}



void SimpleAnimation::loadData(){
    collection = DataBase::getICL(collectionName);
}

bool SimpleAnimation::ready() const throw(){
    return collection != 0;
}


