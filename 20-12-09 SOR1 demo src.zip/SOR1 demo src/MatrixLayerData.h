#ifndef LAYER_DATA_H_INCLUDED
#define LAYER_DATA_H_INCLUDED

#include <vector>
#include <string>

#include "MatrixImage.h"
#include "AFileResolver.h"
#include "AnimatedScenary.h"
#include "AHeader.h"
#include "LayerObj.h"
#include "AUpdatable.h"

class LayerObj;
/**
 * MatrixLayerData files
 * @see AReadable.h
 *
 * @author Gil Costa
 */
class MatrixLayerData: public ALayerData{  // TODO: inerits from more generic class for animated objects
    public:

        // TODO: protected fields?

        /** matrix containing the indexes for the images or animations */
        std::vector<int> mx;
        /** special objects (negative parameters referes to them) */
        std::vector<LayerObj*> objects;

        /** the full image */
        const MatrixImage* image;



        /** default constructor */
        MatrixLayerData();
        /** destructor */
        ~MatrixLayerData();


        //-----------------------------
        // ------- LOAD / SAVE -------


        void readObjects(DataInputStream& dis) throw(IOException);

        /** load the information from the dataBase @see AHeader */
        void loadData();
        /** say if the entity resources are full loaded @see AHeader */
        bool ready() const throw();


        //-----------------------
        // --- Usefull stuff ---

        UInt getNumObjects() const;
        int getFrameWidth(int index) const;
        int getFrameHeight(int index) const;


        /** converts from unidimensional array index to real X position */
        int getXFromIndex(int index) const;
        /** converts from unidimensional array index to real Y position */
        int getYFromIndex(int index) const;

        /** converts from unidimensional array index to real X position */
        int getXFromColumn(int col) const;
        /** converts from unidimensional array index to real Y position */
        int getYFromRow(int index) const;

        /** converts from unidimensional array index to matrix column */
        int getCollumnFromIndex(int index) const;
        /** converts from unidimensional array index to matrix row */
        int getRowFromIndex(int index) const;

        /** converts (column,row) into index */
        int getIndex(int column, int row, bool tiling = false) const;

        /** tells how much that column is out of bounds (how many "sizes")*/
        int getColumnBoundTimes(int column) const;
        /** tells how much that row is out of bounds (how many "sizes")*/
        int getRowBoundTimes(int row) const;

        /** Usefull getters to find delimiters */
        int getNearestLeftColumn(int x) const;
        int getNearestRightColumn(int x) const;
        int getNearestTopRow(int y) const;
        int getNearestBottomRow(int y) const;

        /** @return number of collumns that this matrix has */
        int getNumColumns() const;
        /** @return number of rows that this matrix has */
        int getNumRows() const;

        bool applyToSprite(sf::Sprite& sprite, int index) const;

        /** display the correct cells */
        void display(sf::RenderTarget* target, int left, int top, int right, int bottom, bool tileWidth, bool tileHeight) const;

};



#endif // LAYER_DATA_H_INCLUDED
