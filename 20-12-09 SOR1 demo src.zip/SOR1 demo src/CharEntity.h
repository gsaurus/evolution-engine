#ifndef CHARENTITY_H_INCLUDED
#define CHARENTITY_H_INCLUDED

#include "GameInvariants.h"
#include "AEntity.h"
#include "AControlledEntity.h"
#include "CharState.h"
#include "Character.h"
#include "CharacterHeader.h"
#include "FramesCollection.h"
#include "Pallet.h"

#include "FixedFrame.h"
#include <algorithm>

#include <iostream> //TODO: remove this

class CharState;
class CharacterHeader;



/**
 * Representation of a character
 *  - one of the most important classes
 *  - has state and can be controlled by any AController
 *
 * @author Gil Costa
 */
class CharEntity: public AControlledEntity{
//    public:
        // TODO: put this into special effects class!
//        struct{
//            int sound;
//            sf::Vector3f source
//        } WaitingHitSound;

    // -----------------------
    //  -- Protected stuff --
    // -----------------------


    public:
        CharState* state;   // TODO ########
    protected:
        CharState* lastState;


        // presenting stuff (for view)
        int currentSound;
        int soundKey;
        int lastFrame;
        int lastAnimation;

//        WaitingHitSound hitSound;



        /** changes the current frame */
        void setFrame(FixedFrame* frame);


        /** get a velocity componet based on the character state */
        void updatePlayerVelComponent(float& posComp, float& airVel, bool negative, bool vertical=false);

        /** Control walk, jump and other animations that allows horizontal and/or vertical user movement */
        void updatePlayerVelocity();
        /** update current position, accordingly to the velocity */
        void updatePosition(); // TODO: may need something else for fast walk, easy to change though

        /** update the center point */
        void updateCenterPoint();

        /** update the grabbed one position */
        void updateGrabbedPosition();
//        void updatePositionFromTheGrabber();

        /** set the center on the current frame */
        void setCenter(int x, int y);

        /** set the rotation on the current state */
        void setRotation(float rotation);

//        /** when grab move fails, ungrab and restore animation */
//        void ungrabAndRestore();

//        /** set airVelX correctly, accordingly to walk/run */
//        void setAirVelX(float airvel);
//        /** set airVelZ correctly, accordingly to walk/run */
//        void setAirVelZ(float airvel);

        void performAttack();

    public:

        /** default constructor */
        CharEntity();

        void initialize(const Character* charObj, CharacterHeader* charHeader, const FramesCollection* bodyObj, const FramesCollection* headObj,
                            UInt name, UInt energy, IntVector3D startPos, UInt anim=0);


//        const WaitingHitSound& getHitSound() const;

        /** threath a key event */
        bool takeKey(int k, bool press);

        /**
         * makes the animation move, accordingly to it's internal clock
         * return true if the frame had changed
         */
        bool updateState();

        void resetSpeed();

        /** get the end position (if exists) after doing the current animation */
        const IntVector3D* getEndPosition() const;

        /** return true if current frame has a keyframe */
        bool hasKeyFrame() const;

        /** return true if the given animation is defined */
        bool hasAnimation(int animIndex) const;

        /** return a hit info for the current hitframe */
        const HitFrame* getHits() const;

        /** return the current KeyFrame */
        const KeyFrame* getCurrentKeyFrame() const;

        //void move(int x, int y, int z);

        /**
         * changes the current animation
         * @return true if the animation exists and was set
         */
        bool setAnimation(UInt anim);
        void reloadCurrentFrame();

        void grab(CharEntity* other, bool fromBack = false);
        void unGrab();
        void knockDown();
        void breakAnim();

        void beThrown(const HitFrame* throwInfo);
        void setBeingThrown(bool thrown);

        bool isBeingThrown() const;
        //bool isBeingKnocked() const;

        /** get the animation index */
        UInt getCurrentAnimIndex() const;
        UInt getCurrentAnimFrame() const;
        UInt getAnimTotalFrames() const;
        UInt getRotation() const;

        const sf::Image& getCurrentImage() const;

        bool animationEnded() const;

        /** moves the sprite */
        void move(float dx, float dz);

        /**
         * set the character faced left (true) or right (false)
         * @return true if it flipped
         */
        bool faceLeft(bool faceLeft);
        // Player movement control
        void moveLeft(bool move);
        void moveRight(bool move);
        void moveUp(bool move);
        void moveDown(bool move);
        void run(bool runMove);
        bool isRunning() const;
        bool isFacedLeft() const;
        bool isInAir() const;
        bool isStaticJumping() const;

        bool isMovingLeft() const;
        bool isMovingRight() const;
        bool isMovingUp() const;
        bool isMovingDown() const;

        bool isOnBlockingMove() const;

        bool isInvincibleAnimPlaying() const;
        bool attackedFromBack() const;
        void faceToHitter();

        /** stop all player movement */
        void stopAll();

        CharEntity* getGrabbed() const;
        CharEntity* getTheGrabber() const;
        bool isBeingBackGrabbed() const;
        bool isGrabbingOnBack() const;





        /** @return the last valid state * @see AEntity */
        const AEntityState* getState() const;
        /** activate/deactivate the entity * @see AEntity */
        void setActive(bool active);


        // TODDO: void wallsCollision(SomethingAboutLevelObstacles* walls);


        // void simulate(float percentageDone);

        // /** reload */
        //void reload();

        // /** copy the main information to other sprite */
        // void copyTo(CharEntity& other);















        // ---------------------------
        // ===========================
        //    ----- CONTROL -----
        // ===========================
        // ---------------------------






        bool testGrab(AEntity* other);
        void testHit(AEntity* otherSprite);
        void testThrow();

        /** return true if the animation changes */
        bool animationBreak();
        bool grabAnimationBreak();

        /** Some controls needs time to get in action */
        bool update();

        /** if one directonal key is pressed, walk or run */
        void testWalk();
        void walk();
        void stop();

        void jump();
        void attack();
        void runAttack();
        void jumpAttack();
        void backAttack();
        void knockAttack();

        void grabWalk();
        void grabStop();

        void grabJump();
        void grabAttack();
        void grabRunAttack();
        void grabJumpAttack();

        void grabDefence();
        void grabDefenceThrow();

        void special();
        void jumpSpecial();
        void super();
        void helpCall();

        void groundBounce();
        void groundSuffer();

        void testDying();

        //void knockDown();

        virtual UInt beingHit(const HitInfo& hitInfo);


//        virtual bool actionRequest(int actionType, void* param = 0);




        // --- From AObject ---

        float getX() const;
        float getY() const;
        float getZ() const;

        void updateSprite(sf::Sprite& sprite);

        void reborn(int x, int y, int z);

};

#endif // CHARENTITY_H_INCLUDED
