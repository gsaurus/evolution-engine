#ifndef AEFFECT_HEADER_H_INCLUDED
#define AEFFECT_HEADER_H_INCLUDED

#include "AReadable.h"
#include "AEffect.h"

class AEffectHeader: public AReadable{

    public:
        virtual AEffect* createEffect(float x, float y, float z) = 0;
};

#endif // AEFFECT_HEADER_H_INCLUDED
