#ifndef HITFRAME_H_INCLUDED
#define HITFRAME_H_INCLUDED

#include "TypeUtils.h"
#include "Point.h"
#include "Vector3D.h"

/**
 * Class that stores hit spots on a frame
 * Note: works more as a structure
 *
 * @author Gil Costa
 */
class HitFrame{
    public:

        static const int NO_ACTION;

        //--------------
        // -- FIELDS --
        //--------------
        std::vector<Point16> actionPoints;
        FloatVector3D* throwImpulse;  // byte[3]

        int actionType;
        UInt throwDamage;   // byte
        float throwRot;
        bool frontalKnock;
        bool backKnock;
        bool sparseKnock;
        int hitSound;

        //------------------------------
        // constructors and destructors

        HitFrame();
        virtual ~HitFrame();
};

#endif // HITFRAME_H_INCLUDED
