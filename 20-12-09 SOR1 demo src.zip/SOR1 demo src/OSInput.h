#ifndef OS_INPUT_H_INCLUDED
#define OS_INPUT_H_INCLUDED

#include "TypeUtils.h"

#include <list>
#include <SFML/Graphics.hpp>

/**
 * A static class that handles the OS events:
 *   - keyboard
 *   - Joystick
 *   - windowed app events (close, resize, etc)
 *   - ...
 *
 * Main function: listeningEvents()
 *
 * @author Gil Costa
 */

namespace OSInput{
    struct KeyBut{
        sf::Key::Code code;
        bool pressed;
    };
    struct JoyBut{
        UInt joyId;
        UInt button;
        bool pressed;
    };

    // private data
    namespace{
        /** events source */
        sf::Window* app; // TODO: on SFML2 it won't be necessary?

        bool hasKeyboard;
        bool hasJoystick;

        std::list<KeyBut> keyButsWaiting;
        std::list<JoyBut> joyButsWaiting;
    }



    // -- setting configuration --
    void setWindow(sf::Window* app);
    void setKeyboardListening(bool listen);
    void setJoystickListening(bool listen);
    void clearEvents();

    // -- getting events --
    std::list<KeyBut>::iterator keyButsBegin();
    std::list<JoyBut>::iterator joyButsBegin();
    std::list<KeyBut>::iterator keyButsEnd();
    std::list<JoyBut>::iterator joyButsEnd();
    void removeKeyBut(std::list<KeyBut>::iterator it);
    void removeJoyBut(std::list<JoyBut>::iterator it);

    // -- listening events --
    bool listeningEvents();
}

#endif // OS_INPUT_H_INCLUDED
