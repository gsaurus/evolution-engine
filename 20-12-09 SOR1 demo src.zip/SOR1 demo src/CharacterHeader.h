#ifndef CHARACTERHEADER_H_INCLUDED
#define CHARACTERHEADER_H_INCLUDED

#include "AHeader.h"

#include <string>
#include "CharEntity.h"
#include "TypeUtils.h"
#include "Character.h"
#include "FramesCollection.h"
#include "Pallet.h"

class CharEntity;

/**
 * Represents the main info of a character,
 * not about instantiations of the character
 *
 * @author Gil Costa
 */
class CharacterHeader: public AHeader{
    public:
        std::string characterName;
        UInt body;  // UByte
        UInt head;  // UByte
        UInt pallet;// UByte

        const Character* charObj;
        const FramesCollection* bodyObj;
        const FramesCollection* headObj;
        const Pallet* palletObj;


        /** default constructor (use wisely, make sure to initialise params later) */
        CharacterHeader();
        /** constructor by fields, pointers are set to null */
        CharacterHeader(const std::string& characterName, UInt body, UInt head, UInt pallet);

        /**
         * create a sprite from this header,
         * the sprite info is put into the given sprite
         */
        void createSprite(CharEntity& sprite, UInt name, UInt energy, IntVector3D startPos, UInt startAnimation = 0);

        /** load the information from the dataBase @see AHeader */
        void loadData();
        /** say if the entity resources are full loaded @see AHeader */
        bool ready() const throw();

};

#endif // CHARACTERHEADER_H_INCLUDED
