#ifndef ANIM_FRAME_H_INCLUDED
#define ANIM_FRAME_H_INCLUDED

#include "AReadable.h"

/**
 * AnimFrame data
 * @see AReadable.h
 *
 * @author Gil Costa
 */
class AnimFrame: public AReadable{
    public:
        //--------------
        // -- FIELDS --
        //--------------

        int frameIndex; // int16
        UInt duration;  // UByte


        //--------------------
        // -- CONSTRUCTORS --
        //--------------------
        /** default constructor */
        AnimFrame();
        /** destructor: delete points */
        ~AnimFrame();


        //---------------
        // -- METHODS --
        //---------------

        void readData(DataInputStream& dis) throw(IOException);
        //void writeData(DataOutputStream& dos);

};

#endif // ANIM_FRAME_H_INCLUDED
