#include "ControllersManager.h"

#include "Scene.h"


ControllersManager::ControllersManager(){

}

ControllersManager::~ControllersManager(){
    clearPlayers();
    clearEnemies();
}

//void ControllersManager::reservePlayers(int size){
//    players.reserve(size);
//}

void ControllersManager::addPlayer(AController* player){
//    players.push_back(player);
    players[player->getIdKey()] = player;
//    player->getEntity().getState().id = players.size()-1;
}

//void ControllersManager::setPlayer(UInt pos, AController* player){
////    if (players.size()>pos) players[pos]=player;
//    players[player->getIdKey()] = player;
//}

void ControllersManager::addEnemy(AController* enemy){
    enemies.push_back(enemy);
//    enemy->getEntity().getState().id = enemies.size()-1;
}


void ControllersManager::deletePlayer(int key){
    if (players.find(key)!=players.end()){
        delete players[key];
        players.erase(key);
    }
//    for(UInt i=0 ; i < players.size() ; ++i){
//        if (players[i] != 0 && players[i]->getIdKey() == key){
//            delete players[i];
//            players[i] = 0;
//            if (i == players.size()-1){
//                while (players[i] == 0) --i;
//                players.resize(i+1);
//            }
//            break;
//        }
//    }
}

void ControllersManager::deleteEnemy(int key){
    std::list<AController*>::iterator it;
    for(it = enemies.begin(); it!=enemies.end(); ++it){
        if ((*it)->getIdKey() == key){
            delete *it;
            enemies.erase(it);
            break;
        }
    }
}

AController* ControllersManager::removePlayer(int key){
    AController* res;
    if (players.find(key)!=players.end()){
        res = players[key];
        players.erase(key);
        return res;
    }
//    for(UInt i=0 ; i < players.size() ; ++i){
//        if (players[i] != 0 && players[i]->getIdKey() == key){
//            res = players[i];
//            players[i] = 0;
//            if (i == players.size()-1){
//                while (players[i] == 0) --i;
//                players.resize(i+1);
//            }
//            return res;
//        }
//    }
    return 0;
}

AController* ControllersManager::removeEnemy(int key){
    AController* res;
    std::list<AController*>::iterator it;
    for(it = enemies.begin(); it!=enemies.end(); ++it){
        if ((*it)->getIdKey() == key){
            res = *it;
            //delete *it;
            enemies.erase(it);
            return res;
        }
    }
    return 0;
}


void ControllersManager::clearPlayers(){
    std::map<UInt,AController*>::iterator it;
    for(it = players.begin(); it!=players.end(); ++it){
        if (it->second!=0)
            delete it->second;
    }
    players.clear();
}
void ControllersManager::clearEnemies(){
    std::list<AController*>::iterator it;
    for(it = enemies.begin(); it!=enemies.end(); ++it)
        delete *it;
    enemies.clear();
}




void ControllersManager::testThrows(){
    // Test throw on all players
    std::map<UInt,AController*>::iterator it;
    for(it = players.begin(); it!=players.end(); ++it){
        if (it->second!=0){
            AControlledEntity* entity = it->second->getEntity();
            entity->testThrow();
        }
    }

    // Test throw on all enemies
    // and enemies waitingRemoval
    std::list<AController*>::iterator lit;
//    std::list<std::list<AController*>::iterator> toRemove;
    for(lit = enemies.begin(); lit!=enemies.end(); ++lit){
        AControlledEntity* entity = it->second->getEntity();
//        if (entity->getState()->isWaitingRemoval())
//            toRemove.push_back(lit);
//        else
        entity->testThrow();
    }
//    // remove inactive enemies
//    std::list<std::list<AController*>::iterator>::iterator remIt;
//    for(remIt = toRemove.begin(); remIt!=toRemove.end(); ++remIt)
//        enemies.erase(*remIt);
}



void ControllersManager::testHits(){
    std::list<AController*>::iterator lit;
    AControlledEntity *e1, *e2;
    // test hit between players and enemies
    std::map<UInt,AController*>::iterator it1;
    for(it1 = players.begin() ; it1!=players.end(); ++it1){
        if (it1->second!=0){
            // get an entity from players
            e1 = it1->second->getEntity();
            // test against other players
            if (true){  // TODO: flag about test hit between players
                std::map<UInt,AController*>::iterator it2 = it1;
                for(++it2 ; it2!=players.end(); ++it2){
                    // ########### TODO: stupid way of avoid enemy hits
//                    if (players[j]!=0 && (i == 0 && j>0 || i>0 && j == 0) ){
                    if (it2->second!=0){
                        e2 = it2->second->getEntity();
                        e1->testHit(e2);
                        e2->testHit(e1);
                        e1->testGrab(e2);
                        e2->testGrab(e1);
                    }
                }
            }
            // test against enemies
            for(lit = enemies.begin(); lit!=enemies.end(); ++lit){
                AControlledEntity* e2 = (*lit)->getEntity();
                e1->testHit(e2);
                e2->testHit(e1);
                e1->testGrab(e2);
                e2->testGrab(e1);
            }
        }
    }

    // test hit between enemies
    if (true){  // TODO: flag about test hit between enemies
        // test against enemies
        std::list<AController*>::iterator lit2;
        for(lit = enemies.begin(); lit!=enemies.end(); ++lit){
            e1 = (*lit)->getEntity();
            lit2 = lit;
            for(++lit2; lit2!=enemies.end(); ++lit2){
                e2 = (*lit2)->getEntity();
                e1->testHit(e2);
                e2->testHit(e1);
                e1->testGrab(e2);
                e2->testGrab(e1);
            }
        }
    }
}

//void ControllersManager::testGrabs(){
//    std::list<AController*>::iterator lit1;
//    AControlledEntity* e1;
//    CharEntity* e2, e1_2;
//    bool isE1Char;
//    // test grab between players and enemies
//    for(int i=0 ; i<players.size(); ++i){
//        e1 = players[i]->getEntity()
//        isE1Char = e1_2 = dynamic_cast<CharEntity*>(e1);
//        // test against other players
//        if (true){  // TODO: flag about test hit between players
//            for(int j=i+1; j<players.size(); ++j){
////                if(e2 = dynamic_cast<CharEntity*>(players[j]->getEntity()))
//                    e1.testGrab(e2);
////                if(isE1Char)
//                    e2.testGrab(e1_2);
//            }
//        }
//        // test against enemies
//        for(lit1 = enemies.begin(); lit1!=enemies.end(); ++lit1){
//            if(e2 = dynamic_cast<CharEntity*>(lit1->getEntity()))
//                e1.testGrab(e2);
//            if(isE1Char)
//                e2.testGrab(e1_2);
//        }
//    }
//
//    // test hit between enemies
//    if (true){  // TODO: flag about test hit between enemies
//        // test against enemies
//        std::list<AController*>::iterator lit2;
//        for(lit1 = enemies.begin(); lit1!=enemies.end(); ++lit1){
//            e1 = lit1->getEntity();
//            isE1Char = e1_2 = dynamic_cast<CharEntity*>(e1);
//            for(lit2 = lit1+1; lit2!=enemies.end(); ++lit2){
//                if(e2 = dynamic_cast<CharEntity*>(lit->getEntity()))
//                    e1.testHit(e2);
//                if(isE1Char)
//                    e2.testHit(e1);
//            }
//        }
//    }
//}

void ControllersManager::updateSprites(){
    // update players
    std::map<UInt,AController*>::iterator it;
    for(it = players.begin(); it!=players.end(); ++it){
        if (it->second!=0){
            if (it->first == 0 && Scene::currentScene->sceneState >=20)
                continue;
            (it->second )->getEntity()->update();
        }
    }

    // update enemies
    std::list<AController*>::iterator lit;
    for(lit = enemies.begin(); lit!=enemies.end(); ++lit)
        (*lit)->getEntity()->update();
}



void ControllersManager::updateControllers(){
    // update players
    std::map<UInt,AController*>::iterator it;
    for(it = players.begin(); it!=players.end(); ++it){
        if (it->second!=0)
            it->second->applyKeys();
    }

    // update enemies
    std::list<AController*>::iterator lit;
    for(lit = enemies.begin(); lit!=enemies.end(); ++lit)
        (*lit)->applyKeys();
}


bool ControllersManager::update(){

    updateControllers();

    /* TODO: more efficiently:
        find nearby sprites, test hits and grabs only with them
    */

    testThrows();

    testHits();

//    testGrabs();

    updateSprites();
    return true;
}
