#ifndef SMP_ANIM_EFFECT_HEADER_H_INCLUDED
#define SMP_ANIM_EFFECT_HEADER_H_INCLUDED

#include "AEffectHeader.h"
#include "SimpleAnimation.h"

#include <SFML/System.hpp>

class SmpAnimEffectHeader: public AEffectHeader{
 protected:
    SimpleAnimation animation;
    sf::Vector3i delta;
    // TODO: other litle things like scale, rotation, flip, etc?

 public:
    SmpAnimEffectHeader(DataInputStream& dis) throw(IOException);
    SmpAnimEffectHeader(const std::string& fileName) throw(IOException);
    virtual void readData(DataInputStream& dis) throw(IOException);

    virtual AEffect* createEffect(float x, float y, float z);
};

#endif // SMP_ANIM_EFFECT_HEADER_H_INCLUDED
