#include "AController.h"

//#include <iostream>

AController::AController(): entity(0){}
AController::AController(AControlledEntity* entity): entity(entity)
{}

AController::~AController(){
    // does nothing
}



void AController::setEntity(AControlledEntity* entity){
    this->entity = entity;
}

int AController::getIdKey(){
    return entity->getKey();
}

AControlledEntity* AController::getEntity(){
    return entity;
}

void AController::applyKeys(){
    // iterate over the waiting keys and apply them on the entity
    if (entity == 0) return;
    std::list<KeyEntry>::iterator it;
    for(it = waitingKeys.begin() ; it != waitingKeys.end(); ++it){
//        std::cout << "take key!\n";
        entity->takeKey(it->key, it->pressed);
    }
    waitingKeys.clear();
}
