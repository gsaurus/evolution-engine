#include "MatrixScroller.h"

#include "GameInvariants.h"
#include "TypeUtils.h"
#include <iostream>
#include "MatrixLayerData.h"



MatrixScroller::MatrixScroller(Layer* layer):
    AScroller(layer)
{
    // does nothing
}

MatrixScroller::~MatrixScroller(){
    // does nothing
}




void MatrixScroller::display(sf::RenderTarget* target){
    MatrixLayerData* mxData = static_cast<MatrixLayerData*> (layer->data);
    mxData->display(target, layer->screenXStart(), layer->screenYStart(),
                            layer->screenXEnd(), layer->screenYEnd(),
                            layer->tilingWidth(), layer->tilingHeight()
                    );
}


