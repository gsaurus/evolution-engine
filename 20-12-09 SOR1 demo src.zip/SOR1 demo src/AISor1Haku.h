#ifndef AI_SOR1_HAKU_H_INCLUDED
#define AI_SOR1_HAKU_H_INCLUDED


#include "AITrivialController.h"


/**
 * Control by keyboard input
 * it comes from system events (OSInput)
 *
 * @author Gil Costa
 */
class AISor1Haku: public AITrivialController{
    protected:

    public:
        AISor1Haku();
        AISor1Haku(AControlledEntity* entity);

        void applyKeys();

};

#endif // AI_SOR1_HAKU_H_INCLUDED

