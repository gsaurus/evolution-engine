#include "MatrixImage.h"
#include "GameInvariants.h"

/** Constructor: an empty MatrixImage */
MatrixImage::MatrixImage():AFileResolver(GameInvariants::MATRIX_IMG_VERSION){
    // does nothing, for now
}
MatrixImage::MatrixImage(const std::string& fileName):AFileResolver(GameInvariants::MATRIX_IMG_VERSION){
    setFileName(fileName);
}


//---------------------------------
// ------- GETTERS/SETTERS -------

const Point16& MatrixImage::getCellSize() const{
    return cellSize;
}

int MatrixImage::getCellWidth() const{
    return cellSize.x;
}
int MatrixImage::getCellHeight() const{
    return cellSize.y;
}
const sf::Image& MatrixImage::getImage() const{
    return img;
}
// -- exceptional setters --
void MatrixImage::setImg(sf::Image& img){
    this->img = img;
}
void MatrixImage::setCellSize(int width, int height){
    cellSize.x = width;
    cellSize.y = height;
}



//-----------------------------
// ------- LOAD / SAVE -------

void MatrixImage::readData(DataInputStream& dis) throw(IOException){
    // cell size
    cellSize.readData(dis);

    //  --- read the image data ---
    Data imgData = dis.read(dis.readInt32());
    img.LoadFromMemory(imgData.getData(),imgData.size());
    imgData.clean();
}




//-------------------------------
// ------- ACCESS IMAGES -------

sf::IntRect MatrixImage::getSubRect(int collumn, int row) const{
    int left = collumn*cellSize.x;
    int top = row*cellSize.y;
    return sf::IntRect(left, top, left+cellSize.x, top+cellSize.y);
}


sf::IntRect MatrixImage::getSubRect(int index) const{
    return this->getSubRect(getCollumnFromIndex(index), getRowFromIndex(index));
}

int MatrixImage::getCollumnFromIndex(int index) const{
    return index%getNumColumns();
}
int MatrixImage::getRowFromIndex(int index) const{
    return index/getNumColumns();
}

int MatrixImage::getNumColumns() const{
    return img.GetWidth()/cellSize.x;
}
int MatrixImage::getNumRows() const{
    return img.GetHeight()/cellSize.y;
}
int MatrixImage::getWidth() const{
    return img.GetWidth();
}
int MatrixImage::getHeight() const{
    return img.GetHeight();
}
