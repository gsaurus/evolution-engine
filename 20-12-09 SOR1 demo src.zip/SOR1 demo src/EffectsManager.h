#ifndef EFFECTS_MANAGER_H_INCLUDED
#define EFFECTS_MANAGER_H_INCLUDED

#include <list>
#include "IOException.h"
#include "AUpdateAndDisplay.h"
#include "AEffect.h"
#include "AEffectHeader.h"

/**
 * Controls everything about effects
 * It's layer dependent
 *
 * @author Gil Costa
 */

class EffectsManager: public AUpdateAndDisplay{
    private:
        std::list<AEffect*> effects;
    public:

        static AEffectHeader* hitEffect;  // TODO: this is not to be HERE!!

        EffectsManager();
        ~EffectsManager();

        /** Load effects data, like animations and audio */
        static void loadEffectsData() throw(IOException);
        // TODO: free effects data?

        static void addEffectToCurrentManager(AEffect* effect);

        static AEffectHeader* readHeader(DataInputStream& dis, int type) throw(IOException);

        void deleteAllEffects();


        /** add the given effect to the active list */
        void addEffect(AEffect* effect);


        bool update();
        void display(sf::RenderTarget* target);

};

#endif // EFFECTS_MANAGER_H_INCLUDED
