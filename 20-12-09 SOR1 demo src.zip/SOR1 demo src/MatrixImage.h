#ifndef MATRIX_IMAGE_H_INCLUDED
#define MATRIX_IMAGE_H_INCLUDED

#include "ACollection.h"
#include "Frame.h"
#include "Pallet.h"


/**
 * Collections of frames
 * @see ACollection.h
 *
 * @author Gil Costa
 */
class MatrixImage: public AFileResolver {
    protected:
        /** the wole image */
        sf::Image img;
        /** size of each cell */
        Point16 cellSize;

    public:
        /** Constructor: an empty MatrixImage */
        MatrixImage();
        MatrixImage(const std::string& fileName);


        //---------------------------------
        // ------- GETTERS/SETTERS -------

        const Point16& getCellSize() const;
        int getCellWidth() const;
        int getCellHeight() const;
        const sf::Image& getImage() const;
        // -- exceptional setters --
        void setImg(sf::Image& img);
        void setCellSize(int width, int height);

        //-----------------------------
        // ------- LOAD / SAVE -------
        virtual void readData(DataInputStream& dis) throw(IOException);



        //-------------------------------
        // ------- ACCESS IMAGES -------

        /** get a IntRect to apply on a sprite */
        sf::IntRect getSubRect(int collumn, int row) const;
        sf::IntRect getSubRect(int index) const;

        /** converts from unidimensional array index to matrix column */
        int getCollumnFromIndex(int index) const;
        /** converts from unidimensional array index to matrix row */
        int getRowFromIndex(int index) const;

        /** @return number of collumns that this matrix has */
        int getNumColumns() const;
        /** @return number of rows that this matrix has */
        int getNumRows() const;

        /** @return full image width */
        int getWidth() const;
        /** @return full image height */
        int getHeight() const;


};

#endif // MATRIX_IMAGE_H_INCLUDED
