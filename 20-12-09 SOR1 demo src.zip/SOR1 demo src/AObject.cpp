#include "AObject.h"

//#include <iostream>

UInt AObject::keyGen = 0;

AObject::AObject(){
    key = AObject::keyGen++;
//    std::cout << "generated key: " << key << "\n";
}

UInt AObject::getKey() const{ return key; }
