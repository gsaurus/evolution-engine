#include "Layer.h"

#include "GameInvariants.h"
#include "ControlsMapper.h"
#include "View.h"
#include "DataBase.h"
#include "HScroller.h"
#include "MatrixScroller.h"

//#include <iostream>


//    std::vector<AnimatedScenary> anims;
//    std::vector<LayerObj> objects;  // ordered accordingly to x or y (TODO: free one)
//
//    String collection;
//
//    UByte type;
//    int width;
//    int height;



Layer* Layer::currentLayer = 0;



// default constructor
Layer::Layer(const Scene* scene):
    data(0),
    scene(scene),
    scroller(0),
    relativeVel(),
    autoVel(),
    offset(),
    tileWidth(false),
    tileHeight(false)
{
    // Does nothing
}


// Destructor
Layer::~Layer(){

}




// -----------------
//  --- Methods ---
// -----------------



void Layer::createScroller(){
    if (data->getType() == GameInvariants::H_SCROLL_LAYER_TYPE)
        scroller = new HScroller(this);
    else if (data->getType() == GameInvariants::MATRIX_LAYER_TYPE)
        scroller = new MatrixScroller(this);
    // TODO: other scrollers
}




/* -- Read data -- */
void Layer::readData(DataInputStream& dis) throw(IOException){
    int size = dis.readByte();
    layerName.clear(); layerName.reserve(size);
    for(int j=0 ; j<size ; ++j)
         layerName.push_back((char)dis.readByte());

    relativeVel.readData(dis);
    autoVel.readData(dis);
    tileWidth = dis.readBool();
    tileHeight = dis.readBool();

    // request layer from database
    data = DataBase::getLayer(layerName);

    // TODO: test data == null
    createScroller();
}






void Layer::addCharacter(CharEntity* entity, int controlKey){
//    entities[entity->getKey()] = entity;
    // TODO: player or what?
//    if (controlKey<0)
        controllers.addPlayer(ControlsMapper::getController(entity, controlKey));
//    else controllers.addEnemy(ControlsMapper::getController(entity, controlKey));
    views.addView(new View(entity));
}

void Layer::deleteObject(AObject* obj){
    int key = obj->getKey();
//    entities.remove(key);
    // TODO: see if it's a controlled entity
    // TODO: find if it's a player or what
    controllers.deletePlayer(key);
//    controllers.deleteEnemy(entity.key);
    views.deleteView(key);
}

void Layer::addView(View* view){
    views.addView(view);
}

void Layer::addController(AController* controller){
    // TODO: player or what?
    controllers.addPlayer(controller);
}

View* Layer::removeView(int key){
    return views.removeView(key);
}

AController* Layer::removeController(int key){
    return controllers.removePlayer(key);
}


void Layer::updateControls(){

    // update layer autospeed
    offset.x+=autoVel.x;
    offset.y+=autoVel.y;
    data->update();         // update layer animations

    Layer::setCurrentLayer(this); // TODO: ?!
    controllers.update();   // update controls
}

void Layer::updateViews(){
    // set current layer on audio manager
    Layer::setCurrentLayer(this); // TODO: ?!
    // set current effects manager

    views.update();
    // effects aren't crutial, update them here too
    effects.update();
}


void Layer::display(sf::RenderTarget* target){
    // set the appropriate view
    sf::View view;
    float topX = world2layerX(scene->scrollerCenter.x-scene->screenAlfSize.x);
    float topY = world2layerY(scene->scrollerCenter.y-scene->screenAlfSize.y);
    view.SetCenter(topX+scene->screenAlfSize.x, topY+scene->screenAlfSize.y);
    view.SetHalfSize(scene->screenAlfSize.x, scene->screenAlfSize.y);
    target->SetView(view);
    scroller->display(target);   // background

    views.display(target);      // views

    effects.display(target);          // effects
}



float Layer::world2layerX(float x) const{
    return x * relativeVel.x + offset.x;
}
float Layer::world2layerY(float y) const{
    return y * relativeVel.y + offset.y;
}

void Layer::world2layer(float* x, float* y) const{
    *x *= relativeVel.x + offset.x;
    *y *= relativeVel.y + offset.y;
}

float Layer::layer2worldX(float x) const{
    return x/relativeVel.x - offset.x;
}

float Layer::layer2worldY(float y) const{
    return y/relativeVel.y - offset.y;
}

void Layer::layer2world(float* x, float* y) const{
    *x /= relativeVel.x - offset.x;
    *y /= relativeVel.y - offset.y;
}



int Layer::screenXStart() const{
    return (int)(world2layerX(scene->scrollerCenter.x - scene->screenAlfSize.x) - GameInvariants::SCROLL_PIXELS);
}
int Layer::screenXEnd() const{
    return (int)(world2layerX(scene->scrollerCenter.x - scene->screenAlfSize.x) + 2*scene->screenAlfSize.x + GameInvariants::SCROLL_PIXELS);
}

int Layer::screenYStart() const{
    return (int)(world2layerY(scene->scrollerCenter.y - scene->screenAlfSize.y) - GameInvariants::SCROLL_PIXELS);
}
int Layer::screenYEnd() const{
    return (int)(world2layerY(scene->scrollerCenter.y - scene->screenAlfSize.y) + 2*scene->screenAlfSize.y + GameInvariants::SCROLL_PIXELS);
}

bool Layer::tilingWidth() const{ return tileWidth; }
bool Layer::tilingHeight() const{ return tileHeight; }



void Layer::addEffect(AEffect* effect){
    effects.addEffect(effect);
}

void Layer::setCurrentLayer(Layer* layer){
    currentLayer = layer;
}
Layer* Layer::getCurrentLayer(){
    return currentLayer;
}
