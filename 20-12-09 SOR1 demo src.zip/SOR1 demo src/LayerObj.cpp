#include "LayerObj.h"

#include "GameInvariants.h"

//    Point16 position;
//    int frameIndex;     // int16
//    std::vector<UByte> alternativeAnims;
//    int parameters;



//--------------------
// -- CONSTRUCTORS --
//--------------------

LayerObj::LayerObj(const ALayerData* data):
    frameIndex(8),parameters(0), data(data)
{}

LayerObj::~LayerObj(){

}

//---------------
// -- METHODS --
//---------------



void LayerObj::readData(DataInputStream& dis) throw(IOException){
    alternativeAnims.clear();
    Point16 position;
    position.readData(dis);
    frameIndex = dis.readInt16();
    if (frameIndex < 0){
        if (frameIndex<=-GameInvariants::MAX_ANIMATIONS)
            parameters = dis.readInt32();
        else{
            int size = dis.readSignedByte();
            alternativeAnims.reserve(size);
            for (int i=0; i<size; ++i){
                alternativeAnims.push_back(dis.readByte());
            }
        }
    }
    sprite.SetPosition(position.x,position.y);
}

//void writeData(DataOutputStream& dos){ //throws IOException {
// TODO?..
//}

int LayerObj::getX() const{
    return (int)sprite.GetPosition().x;
}
int LayerObj::getY() const{
    return (int)sprite.GetPosition().y;
}

void LayerObj::setPosition(int x, int y){
    sprite.SetPosition(x,y);
}


void LayerObj::display(sf::RenderTarget* target){
    if (data->applyToSprite(sprite,frameIndex)){
        target->Draw(sprite);
    }
}

void LayerObj::display(sf::RenderTarget* target, const sf::Vector2i& offset){
    sf::Vector2f oldPos = sprite.GetPosition();
    sprite.SetPosition(offset.x,offset.y);
    display(target);
    sprite.SetPosition(oldPos);
}
