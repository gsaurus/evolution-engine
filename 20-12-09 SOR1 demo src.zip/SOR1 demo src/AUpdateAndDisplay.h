#ifndef AUPDATEANDDISPLAY_H_INCLUDED
#define AUPDATEANDDISPLAY_H_INCLUDED


#include "AUpdatable.h"
#include "ADisplayable.h"

/**
 * Interface of objects that can be updated and also displaid
 * because many objects are animated and can be drawn
 *
 * @author Gil Costa
 */
class AUpdateAndDisplay:public AUpdatable, public ADisplayable{

};

#endif // AUPDATEANDDISPLAY_H_INCLUDED
