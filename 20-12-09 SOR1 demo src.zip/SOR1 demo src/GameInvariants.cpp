#include "GameInvariants.h"



//--------------------------------
// --- Scene and layers stuff ---
//--------------------------------

const int GameInvariants::MAX_ANIMATIONS = 1000;
const int GameInvariants::SCROLL_PIXELS = 30;
const UByte GameInvariants::H_SCROLL_LAYER_TYPE = 0;
const UByte GameInvariants::V_SCROLL_LAYER_TYPE = 1;
const UByte GameInvariants::MATRIX_LAYER_TYPE = 2;
const int GameInvariants::NULL_MATRIX_CELL = 31999;





//---------------------
// --- Audio stuff ---
//---------------------


const int GameInvariants::NO_SOUND_INDEX = -1;
const float GameInvariants::SOUND_MIN_DISTANCE = 75.f;
const float GameInvariants::SOUND_ATTENUATION = 0.5f;
const float GameInvariants::SOUND_LISTENER_DISTANCE = 64.f;








//----------------------
// ---- Extensions ----
//----------------------



const char* GameInvariants::MATRIX_IMG_EXTENSION = "mi";
const char* GameInvariants::FRAMES_EXTENSION = "icl";
const char* GameInvariants::GOODIES_EXTENSION = "gst";
const char* GameInvariants::WEAPONS_EXTENSION = "wpn";
const char* GameInvariants::SOUND_EXTENSION = "se";
const char* GameInvariants::MUSIC_EXTENSION = "mu";
const char* GameInvariants::CHARACTER_EXTENSION = "ch";
const char* GameInvariants::PALLET_EXTENSION = "pll";
const char* GameInvariants::LANGUAGE_EXTENSION = "lang";
const char* GameInvariants::LAYERS_EXTENSION = "lay";
const char* GameInvariants::SCENES_EXTENSION = "scn";




//-------------------------
// ---- File Versions ----
//-------------------------

const UByte GameInvariants::MATRIX_IMG_VERSION  = 1;
const UByte GameInvariants::FRAMES_VERSION      = 1;
const UByte GameInvariants::GOODIES_VERSION     = 1;
const UByte GameInvariants::WEAPONS_VERSION     = 2;
const UByte GameInvariants::SOUND_VERSION       = 1;
const UByte GameInvariants::MUSIC_VERSION       = 1;
const UByte GameInvariants::CHARACTER_VERSION   = 4;
const UByte GameInvariants::PALLET_VERSION      = 1;
const UByte GameInvariants::LANGUAGE_VERSION    = 1;
const UByte GameInvariants::LAYERS_VERSION      = 1;
const UByte GameInvariants::SCENES_VERSION    = 1;




//-----------------------
// ---- Directories ----
//-----------------------

const char* GameInvariants::ANIMATIONS_DIR = "animations\\";
const char* GameInvariants::GOODIES_DIR = "goodies\\";
const char* GameInvariants::WEAPONS_DIR = "weapons\\";
const char* GameInvariants::AUDIO_DIR = "audio\\";
const char* GameInvariants::CHARACTERS_DIR = "characters\\";
const char* GameInvariants::PALLETS_DIR = "pallets\\";
const char* GameInvariants::LANGUAGE_DIR = "language\\";
const char* GameInvariants::LEVELS_DIR = "levels\\";


const char* GameInvariants::UNDEFINED = "undefined";



//----------------------
// ---- Game Flags ----
//----------------------

bool GameInvariants::FACE_WHEN_HIT = false;
bool GameInvariants::REALIST_FACE_HIT = false;


//---------------------------
// ---- Game properties ----
//---------------------------
UInt GameInvariants::RANDOM_TB_SIZE = 512;
UByte GameInvariants::RANDOM_MAX_VAL = 255;
UByte GameInvariants::LIFE_BAR = 50;
float GameInvariants::VEL_DIVIDER = 10.f;
float GameInvariants::ROT_VEL_DIVIDER = 4.f;
float GameInvariants::VERTICAL_VEL_FACTOR = 0.75f;
float GameInvariants::AIR_CONTROL = 0; //0.5;
float GameInvariants::JUMP_X_IMPULSE_FACT = 1.;

float  GameInvariants::ELASTICITY = 0.5;

UByte GameInvariants::RUN_TIME    = 20;
UByte GameInvariants::ATTACK_TIME = 25;
UByte GameInvariants::KNOCK_TIME  = 40;

UByte GameInvariants::GRAB_X_SPACE = 24;
float GameInvariants::GRAB_X_BACK_FACTOR = 1.0;
UByte GameInvariants::GRAB_Z_SPACE = 15;

float GameInvariants::GRAVITY = -0.48f;
float GameInvariants::FALLING_LIMIAR = 1.5f;
float GameInvariants::FLIP_ATTACK_MINIMUM = 0.25;
float GameInvariants::FLIP_ATTACK_MAXIMUM = 0.75;
float GameInvariants::JUMP_SPECIAL_MAX_SPEED = 3.;
//const float GameInvariants::LOW_GRAVITY = -0.1f;



UByte GameInvariants::HIT_PAUSE = 4;
UByte GameInvariants::KNOCK_PAUSE = 5;
UByte GameInvariants::GRAB_PAUSE = 15;
UByte GameInvariants::AFTER_ATTACK_PAUSE = 0;
UByte GameInvariants::ATTACK_WAIT_TOLERANCE = 5;

UByte GameInvariants::RECOVER_TIME = 50;
UByte GameInvariants::UNGRAB_TIME = 25;

float GameInvariants::GROUND_BOUNCE_VEL = 2;
float GameInvariants::KNOKED_X_VEL = 3.5;
float GameInvariants::KNOKED_Y_VEL = 8;

float GameInvariants::BLOCK_HIT_VEL = -2.5;
UByte GameInvariants::BLOCK_HIT_TIME = 5;




//-------------------------------------------
// ---- Default object and action types ----
//-------------------------------------------

/** Action Types (hit, fire, etc) */
const int GameInvariants::AT_KNOCK = 128;
const int GameInvariants::AT_ELECTROCUTION = 50;
const int GameInvariants::AT_BOMB = 51;
const int GameInvariants::AT_PEPPER = 52;
const int GameInvariants::AT_FIRE = 53;
const int GameInvariants::AT_BULLET = 54;
const int GameInvariants::AT_THROW = 60;
const int GameInvariants::AT_EFFECTS = 255;



//--------------------------
// ---- SpecialEffects ----
//--------------------------

const int GameInvariants::FX_SOUND = 255;
const int GameInvariants::FX_SMP_ANIM = 256;







//----------------------------------------
// ---- Default Character Animations ----
//----------------------------------------

//______________________________
// --- involuntary stances ----

const UByte GameInvariants::INTRODUCING     = 0;
const UByte GameInvariants::INTRODUCING_END = 1;
const UByte GameInvariants::NORMAL          = 2;
const UByte GameInvariants::WAITING         = 3;
const UByte GameInvariants::CROUCHING_DOWN  = 4;
const UByte GameInvariants::LYING           = 5;
const UByte GameInvariants::STANDING_UP     = 6;

const UByte GameInvariants::IN_AIR          = 8;
const UByte GameInvariants::LAND            = 9;

const UByte GameInvariants::BEING_GRABBED_FRONT = 11;
const UByte GameInvariants::BEING_GRABBED_BACK  = 12;
const UByte GameInvariants::ATOMIC_FALLING      = 13;
const UByte GameInvariants::BEING_HIT           = 14;
const UByte GameInvariants::BEING_GRABBED_HIT_FRONT  = 15;
const UByte GameInvariants::BEING_GRABBED_HIT_BACK   = 16;
const UByte GameInvariants::BEING_KNOCKED       = 17;
const UByte GameInvariants::BEING_THROWN        = 18;
const UByte GameInvariants::SHOCK_IN_WALL_FRONT = 19;
const UByte GameInvariants::SHOCK_IN_WALL_BACK  = 20;
const UByte GameInvariants::BEING_ELECTROCUTTED = 21;
const UByte GameInvariants::BEING_BURNED        = 22;


const UByte GameInvariants::GRABBING_FRONT      = 23;
const UByte GameInvariants::GRABBING_BACK       = 24;



//_______________________
// --- Action Moves ----

// normal moves:

const UByte GameInvariants::WALK                = 27;
const UByte GameInvariants::RUN                 = 28;
const UByte GameInvariants::PREPARE_JUMP        = 29;
const UByte GameInvariants::STATIC_JUMP         = 30;
const UByte GameInvariants::JUMP                = 31;
const UByte GameInvariants::RUN_JUMP            = 32;
const UByte GameInvariants::ROLL_UP             = 33;
const UByte GameInvariants::ROLL_DOWN           = 34;

// if some not defined, the first one is used
const UByte GameInvariants::ATTACK_1            = 36;
const UByte GameInvariants::ATTACK_2            = 37;
const UByte GameInvariants::ATTACK_3            = 38;
const UByte GameInvariants::ATTACK_4            = 39;
const UByte GameInvariants::ATTACK_5            = 40;

const UByte GameInvariants::RUN_ATTACK_STAR_0   = 42;
const UByte GameInvariants::RUN_ATTACK_STAR_1   = 43;
const UByte GameInvariants::RUN_ATTACK_STAR_2   = 44;
const UByte GameInvariants::RUN_ATTACK_STAR_3   = 45;

const UByte GameInvariants::JUMP_STATIC_ATTACK  = 47;
const UByte GameInvariants::JUMP_MOVE_ATTACK    = 48;
const UByte GameInvariants::JUMP_RUN_ATTACK     = 49;
const UByte GameInvariants::JUMP_DOWN_ATTACK    = 50;

const UByte GameInvariants::DEFENCIVE_SPECIAL   = 52;
const UByte GameInvariants::OFENCIVE_SPECIAL    = 53;
const UByte GameInvariants::JUMP_SPECIAL        = 54;
const UByte GameInvariants::BLOCK               = 55;

const UByte GameInvariants::BACK_ATTACK         = 56;
const UByte GameInvariants::KNOCK_ATTACK        = 57;

const UByte GameInvariants::SUPPER              = 59;
const UByte GameInvariants::HELP_CALL           = 60;

const UByte GameInvariants::WEAPON_ATTACK       = 62;
const UByte GameInvariants::WEAPON_THROW        = 63;


// grabbing moves:

// if some not defined, the first one is used
const UByte GameInvariants::FRONT_GRAB_FRONT_ATTACK_1 = 66;
const UByte GameInvariants::FRONT_GRAB_FRONT_ATTACK_2 = 67;
const UByte GameInvariants::FRONT_GRAB_FRONT_ATTACK_3 = 68;
const UByte GameInvariants::FRONT_GRAB_FRONT_ATTACK_4 = 69;
const UByte GameInvariants::FRONT_GRAB_FRONT_ATTACK_5 = 70;

const UByte GameInvariants::FRONT_GRAB_STATIC_ATTACK  = 72;
const UByte GameInvariants::FRONT_GRAB_BACK_ATTACK    = 73;

const UByte GameInvariants::BACK_GRAB_FRONT_ATTACK  = 75;
const UByte GameInvariants::BACK_GRAB_STATIC_ATTACK = 76;
const UByte GameInvariants::BACK_GRAB_BACK_ATTACK   = 77;
const UByte GameInvariants::GRAB_WALK               = 78;
const UByte GameInvariants::GRAB_BACK_WALK          = 79;
const UByte GameInvariants::GRAB_RUN                = 80;
const UByte GameInvariants::GRAB_JUMP               = 81;

const UByte GameInvariants::GRAB_RUN_ATTACK         = 83;
const UByte GameInvariants::FRONT_GRAB_JUMP_ATTACK  = 84;
const UByte GameInvariants::BACK_GRAB_JUMP_ATTACK   = 85;

const UByte GameInvariants::FLIP_OVER               = 87;
const UByte GameInvariants::FAILED_FLIP_OVER        = 88;
const UByte GameInvariants::FLIP_OVER_ATTACK        = 89;

const UByte GameInvariants::BEING_BACK_GRABBED_DEFENCE = 91;
const UByte GameInvariants::THROWS_WHOS_GRABBING       = 92;


// team moves:

const UByte GameInvariants::TEAM_FLIP_OVER_ATTACK   = 95;
const UByte GameInvariants::TEAM_FRONT_GRAB_STATIC_ATTACK  = 96;
const UByte GameInvariants::TEAM_BACK_GRAB_STATIC_ATTACK   = 97;

// mixelaneous
const UByte GameInvariants::DYING = 99;
const UByte GameInvariants::GRABBING_UP = 100;
const UByte GameInvariants::FRONT_GRAB_JUMP_ATTACK_LAND = 101;
const UByte GameInvariants::BACK_GRAB_JUMP_ATTACK_LAND = 102;

const UByte GameInvariants::GROUND_BOUNCING = 104;
const UByte GameInvariants::SAFE_LANDING = 105;


const UByte GameInvariants::NUM_KEYS = 12;




//const int key::UP    = 0;
//const int key::DOWN  = 1;
//const int key::LEFT  = 2;
//const int key::RIGHT = 3;
//const int key::A     = 4;
//const int key::B     = 5;
//const int key::C     = 6;
//const int key::D     = 7;
//const int key::E     = 8;
//const int key::F     = 9;
//const int key::START = 10;
//const int key::CALL  = 11;
