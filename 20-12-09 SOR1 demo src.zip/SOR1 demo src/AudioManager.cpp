#include "AudioManager.h"
#include "TypeUtils.h"
#include "GameInvariants.h"
#include "Sound.h"
#include "Layer.h"

#include "Scene.h"

#include <list>
#include <iostream>

// ----------------
//  --- Sounds ---
// ----------------

std::string AudioManager::folder;
std::vector<sf::SoundBuffer*> AudioManager::systemSounds;
HashMap<int,sf::SoundBuffer*> AudioManager::specificSounds;

HashMap<int, sf::Sound*> AudioManager::playingSounds;
int AudioManager::keyGen(0);  // generates sound keys




void AudioManager::setFolder(const std::string& folder){
    AudioManager::folder = folder;
    // TODO: ####### Scene Specific
    loadSpecificSound(14);  // TODO:!!!! these fixed sounds to be loaded in other way
//    loadSpecificSound(22);
    loadSpecificSound(23);
    loadSpecificSound(54);
    // fire
    loadSpecificSound(21);
    loadSpecificSound(24);
}

const std::string& AudioManager::getFolder(){
    return folder;
}

/* Load system sounds */
void AudioManager::loadSystemSounds() throw(IOException){
    // TODO: later

}

/* Load specific sounds */
void AudioManager::loadSpecificSound(int soundNumber) throw(IOException){
    if (soundNumber == 0 || specificSounds.containsKey(soundNumber)) return;
    std::string fileName(GameInvariants::AUDIO_DIR);
    std::string tmp;
    ::toString(soundNumber,tmp);
    fileName += folder;
    fileName += tmp;
    fileName += ".";
    fileName += GameInvariants::SOUND_EXTENSION;

    std::cout << fileName << "\n";

    Sound se;
    se.setFileName(fileName);
    se.load();
    specificSounds[soundNumber] = se.getBufferedSound();
}

void AudioManager::clearSpecificSound(int soundNumber){
    if (specificSounds.containsKey(soundNumber)){
        clearPlayingSounds();
        if (specificSounds.containsKey(soundNumber)){
            delete specificSounds[soundNumber];
            specificSounds.remove(soundNumber);
        }
    }
}


void AudioManager::clearAllSpecificSounds(){
    clearPlayingSounds();
    HashMap<int,sf::SoundBuffer*>::iterator it;
    for(it = specificSounds.begin(); it!=specificSounds.end(); ++it)
        delete it->second;
    specificSounds.clear();
}

void AudioManager::clearAllSounds(){
    clearAllSpecificSounds();
    std::vector<sf::SoundBuffer*>::iterator it;
    for(it = systemSounds.begin(); it!=systemSounds.end(); ++it)
        delete *it;
    systemSounds.clear();
}

void AudioManager::clearPlayingSounds(){
    HashMap<int,sf::Sound*>::iterator it;
    for( it = playingSounds.begin(); it!= playingSounds.end() ; ++it){
        it->second->Stop();
        delete it->second;
    }
    playingSounds.clear();
}


/* play the specified sound, return the generated sound key , for future access */
int AudioManager::playSystemSound(int srcIndex, float x, float y, float z){
    return -1;
}

/* play the specified sound, return the generated sound key , for future access */
int AudioManager::playSound(int srcIndex, float x, float y, float z, float minDistance, float attenuation, float pitch){
    if (specificSounds.containsKey(srcIndex)){
        sf::Sound* snd = new sf::Sound();
        snd->SetBuffer(*specificSounds[srcIndex]);
        if (++keyGen == GameInvariants::NO_SOUND_INDEX) ++keyGen;
        playingSounds[keyGen] = snd;

        Layer* currentLayer = Layer::getCurrentLayer();
        if (currentLayer==0)
            snd->SetPosition(x,y,z);
        else{
            snd->SetPosition(
                    currentLayer->layer2worldX(x),
                    currentLayer->layer2worldY(y),
                    currentLayer->layer2worldY(z)
            );
        }

        snd->SetMinDistance(minDistance);
        snd->SetAttenuation(attenuation);
        snd->SetPitch(pitch);


//        if (Scene::getCurrLayerId() == 2){
//            snd->SetVolume(50);
//        }

//        snd->SetRelativeToListener(true);
//        std::cout << snd->GetAttenuation() << " attenuation\n";
//
//        std::cout << snd->GetPosition().x << " x position\n";
//        std::cout << sf::Listener::GetPosition().x << " listener x position\n";

        snd->Play();
        return keyGen;
    }else return GameInvariants::NO_SOUND_INDEX;
}


void AudioManager::stopSound(int key){
    if (playingSounds.containsKey(key)){
        playingSounds[key]->Stop();
        delete playingSounds[key];
        playingSounds.remove(key);
    }
}


bool AudioManager::replay(int key){
    if (playingSounds.containsKey(key)){
        playingSounds[key]->Stop();
        playingSounds[key]->Play();
        return true;
    }
    return false;
}


/* change sound position */
bool AudioManager::setPosition(int key, float x, float y, float z){
    if (playingSounds.containsKey(key)){
        playingSounds[key]->SetPosition(x,y,z);
        return true;
    }
    return false;
}

/* change sound volume */
bool AudioManager::setVolume(int key, float volume){
    if (playingSounds.containsKey(key)){
        playingSounds[key]->SetVolume(volume);
        return true;
    }
    return false;
}

/* change sound pitch */
bool AudioManager::setPitch(int key, float pitch){
    if (playingSounds.containsKey(key)){
        playingSounds[key]->SetPitch(pitch);
        return true;
    }
    return false;
}

/** change sound attenuation */
bool AudioManager::setAttenuation(int key, float minDistance, float attenuation){
    if (playingSounds.containsKey(key)){
        playingSounds[key]->SetMinDistance(minDistance);
        playingSounds[key]->SetAttenuation(attenuation);
        return true;
    }
    return false;
}

bool AudioManager::isPlaying(int key){
    if (playingSounds.containsKey(key)){
        return playingSounds[key]->GetStatus() == sf::Sound::Playing;
    }
    return false;
}



/** find what sounds are inactive, and clear them */
void AudioManager::clearInactiveSounds(){
    std::list<HashMap<int,sf::Sound*>::iterator> toRemove;
    HashMap<int,sf::Sound*>::iterator it;
    for( it = playingSounds.begin(); it!= playingSounds.end() ; ++it){
        if (it->second->GetStatus() == sf::Sound::Stopped){
            delete it->second;
            toRemove.push_back(it);
        }
    }
    std::list<HashMap<int,sf::Sound*>::iterator>::iterator removeIt;
    for (removeIt = toRemove.begin(); removeIt!= toRemove.end() ; ++removeIt)
        playingSounds.remove(*removeIt);

}


void AudioManager::updateListener(float x, float y, float z){
//    sf::Listener::SetPosition(x,y,z+GameInvariants::SOUND_LISTENER_DISTANCE);
//    sf::Listener::SetTarget(x,y,z);
    sf::Listener::SetPosition(x,y,z+GameInvariants::SOUND_LISTENER_DISTANCE);
    sf::Listener::SetTarget(x,y,-200);
}

void AudioManager::setGlobalVolume(float volume){
    sf::Listener::SetGlobalVolume(volume);
}
