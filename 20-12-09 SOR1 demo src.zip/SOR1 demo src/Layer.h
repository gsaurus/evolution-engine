#ifndef LAYER_H_INCLUDED
#define LAYER_H_INCLUDED

#include <vector>
#include <string>

#include "ALayerData.h"
#include "CharEntity.h"

#include "ControllersManager.h"
#include "ViewsManager.h"
#include "HashMap.h"
#include "Scene.h"
#include "AScroller.h"
#include "EffectsManager.h"
#include "AObject.h"

class AScroller;
class Scene;
class EffectsManager;

/**
 * Layer files
 * @see AReadable.h
 *
 * @author Gil Costa
 */
class Layer: public AReadable, ADisplayable{
    // TODO: ##### Other layer types (for layers without characters and etc)
    public:
        ALayerData* data;
        const Scene* scene;
    protected:
        AScroller* scroller;

        static Layer* currentLayer;

        //------------
        // -- INFO --
        //------------

        std::string layerName;

    public: // TODO: public??!!

        Pointf relativeVel;
        Pointf autoVel;
        /** offset for moving layers */
        Pointf offset;  // not being loaded (yet?)
        bool tileWidth;
        bool tileHeight;

    protected:


        // ----------------
        //  -- Entities --
        // ----------------

//        /** All the entities */
//        HashMap<int, AEntity*> entities;

        // TODO: ######### blablabla
    public:

        /** controllers of entities */
        ControllersManager controllers;

    protected:
        /** views of entities */
        ViewsManager views;

        /** effects playing on this layer */
        EffectsManager effects;

        // TODO: what about pickables, crackables and other trigerables management?

        void createScroller();

    public:

        /** default constructor */
        Layer(const Scene* scene);
        /** destructor */
        ~Layer();

        /** read data from file */
        void readData(DataInputStream& dis) throw(IOException);


        void addCharacter(CharEntity* entity, int controlKey);
        //void addEntity(AEntity* entity);
        // TODO: add other type of entities

        void deleteObject(AObject* obj);

        void addView(View* view);
        void addController(AController* controller);

        View* removeView(int key);
        AController* removeController(int key);

        void updateControls();
        void updateViews();

        float world2layerX(float x) const;
        float world2layerY(float y) const;
        void world2layer(float* x, float* y) const;
        float layer2worldX(float x) const;
        float layer2worldY(float y) const;
        void layer2world(float* x, float* y) const;

        int screenXStart() const;
        int screenXEnd() const;
        int screenYStart() const;
        int screenYEnd() const;

        /** display the layer and the views of the existing entities */
        void display(sf::RenderTarget* target);

        bool tilingWidth() const;
        bool tilingHeight() const;

        void addEffect(AEffect* effect);


        static void setCurrentLayer(Layer* layer);
        static Layer* getCurrentLayer();

};



#endif // LAYER_H_INCLUDED
