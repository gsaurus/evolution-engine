#ifndef AREADABLE_H_INCLUDED
#define AREADABLE_H_INCLUDED

#include "DataInputStream.h"
#include "DataOutputStream.h"
#include "IOException.h"

/**
 * Abstract class for readable objects
 *
 * @author Gil Costa
 */
class AReadable{
    public:
        virtual ~AReadable(){}
        virtual void readData(DataInputStream& dis) throw(IOException) = 0;
        //virtual void writeData(DataOutputStream& dos) throw(IOException) = 0;
};

#endif // AREADABLE_H_INCLUDED
