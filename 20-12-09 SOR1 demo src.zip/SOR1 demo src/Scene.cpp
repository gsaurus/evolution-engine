#include "Scene.h"

#include "AudioManager.h"

#include "DataBase.h"

#include "SmpAnimEffectHeader.h"
#include <math.h>
#include <iostream>



long Scene::clock = 0;
Scene* Scene::currentScene = 0;

int Scene::currLayerId = 0;


long Scene::getTimeSeconds() { return clock/60; }
long Scene::getClocks() { return clock; }
int Scene::getCurrLayerId(){ return currLayerId; }


//--------------------
// -- CONSTRUCTORS --
//--------------------
Scene::Scene():AFileResolver(GameInvariants::SCENES_VERSION){
    currentScene = this;
    sceneState = 0;
}

Scene::Scene(const std::string& fileName):AFileResolver(GameInvariants::SCENES_VERSION){
    setFileName(fileName);
    currentScene = this;
    sceneState = 0;
}

void Scene::setFileName(const std::string& fileName) throw(){
    std::string tmp(GameInvariants::LEVELS_DIR); tmp += fileName;
    AFileResolver::setFileName(tmp);
}

Scene::~Scene(){
    currentScene = 0;
//    std::vector<Layer*>::iterator it1 = layers.begin();
//    for(; it1!=layers.end(); ++it1){
//        delete *it1;
//    }
}


//---------------
// -- METHODS --
//---------------


void Scene::readData(DataInputStream& dis) throw(IOException){

    // layers
    int size = dis.readInt16();
    layers.reserve(size);
    for(int i=0; i<size; ++i){
        Layer* layer = new Layer(this);
        layer->readData(dis);
        layers.push_back(layer);
    }
}



//void Scene::writeData(DataOutputStream& dos){ //throws IOException
//}


sf::Vector2i* Scene::getTarget(){
    sf::Vector2i* target = new sf::Vector2i(0,0);
    if (sceneState ==21){
        target->x = (int)car->getX();
    }else{
        std::map<AEntity*,int>::iterator it;
        for(it = scrollingEntities.begin(); it != scrollingEntities.end(); ++it) {
            // TODO: add the % component of the layer!!
            AEntity* entity = it->first;;
            target->x += (int)layers[it->second]->layer2worldX(entity->getX());
            target->y += (int)layers[it->second]->layer2worldY(entity->getZ() - entity->getY()-25);
        }
        target->x /= scrollingEntities.size();
        target->y /= scrollingEntities.size();

        if (target->x > scrollerCenter.x - 200 && target->x < scrollerCenter.x)
            target->x = (int)(scrollerCenter.x);
    }
    return target;
}


void Scene::updateScrollPosition(){
    sf::Vector2i* target = getTarget();
    if (scrollerCenter.x + toleratedBox.x < target->x && scrollerCenter.x < window.Right - screenAlfSize.x)
        scrollerCenter.x += std::min(scrollerSpeed.x,target->x-(scrollerCenter.x + toleratedBox.x));
    else if (scrollerCenter.x - toleratedBox.x > target->x && scrollerCenter.x > window.Left + screenAlfSize.x)
        scrollerCenter.x -= std::min(scrollerSpeed.x,(scrollerCenter.x - toleratedBox.x)-target->x);
    else if (sceneState == 23)
        sceneState = 24;

    if (scrollerCenter.y + toleratedBox.y < target->y && scrollerCenter.y < window.Bottom - screenAlfSize.y){
        scrollerCenter.y += std::min(scrollerSpeed.y,target->y-(scrollerCenter.y + toleratedBox.y));
    }else if (scrollerCenter.y - toleratedBox.y > target->y && scrollerCenter.y > window.Top + screenAlfSize.y){
        scrollerCenter.y -= std::min(scrollerSpeed.y,(scrollerCenter.y - toleratedBox.y)-target->y);
    }

    scrollerCenter.y = (window.GetHeight()/2)-16 + 14*::pow(::cos(clock/52.f),2);
    if (scrollerCenter.x < screenAlfSize.x) scrollerCenter.x = screenAlfSize.x;
    //std::cout << target->x << ", " << target->y << "\t---> (" << scrollerCenter.x << ", " << scrollerCenter.y << ")\n";
    delete target;
}




void Scene::updateControls(){
    clock++;


//    // TODO: ######## ...SCENE SPECIFIC CODE...
    AEntity* ent = scrollingEntities.begin()->first;
    if (sceneState == 0){
        if (ent->getX() >=250){
            std::cout << "STATE 0!!!\n";

            CharacterHeader ch;
            ch.characterName = "Garcia1.ch";
            ch.body = ch.head = 0;
            ch.pallet = 0;
            ch.loadData();

            CharEntity* entity = new CharEntity();
            ch.createSprite(*entity,0,16, IntVector3D(-30,0,200),GameInvariants::NORMAL);
            addCharacter(entity, 1, 5);

            entity = new CharEntity();
            ch.createSprite(*entity,0,16, IntVector3D(600,0,200),GameInvariants::NORMAL);
            addCharacter(entity, 1, 5);

            sceneState++;
        }
    }


    else if (sceneState == 1){
        if (ent->getX() >=350){
            std::cout << "STATE 1!!!\n";
            CharacterHeader ch;
            ch.characterName = "Garcia1.ch";
            ch.body = ch.head = 0;
            ch.pallet = 0;
            ch.loadData();

            CharEntity* entity = new CharEntity();
            ch.createSprite(*entity,0,16, IntVector3D(-5,0,160),GameInvariants::NORMAL);
            addCharacter(entity, 1, 5);
            entity = new CharEntity();
            ch.createSprite(*entity,0,16, IntVector3D(-70,0,225),GameInvariants::NORMAL);
            addCharacter(entity, 1, 5);
            entity = new CharEntity();
            ch.createSprite(*entity,0,16, IntVector3D(-170,0,225),GameInvariants::NORMAL);
            addCharacter(entity, 1, 5);
            entity = new CharEntity();
            ch.createSprite(*entity,0,16, IntVector3D(-200,0,170),GameInvariants::NORMAL);
            addCharacter(entity, 1, 5);
            entity = new CharEntity();

            ch.createSprite(*entity,0,16, IntVector3D(560,0,160),GameInvariants::NORMAL);
            addCharacter(entity, 1, 5);
            entity = new CharEntity();
            ch.createSprite(*entity,0,16, IntVector3D(640,0,225),GameInvariants::NORMAL);
            addCharacter(entity, 1, 5);
            entity = new CharEntity();
            ch.createSprite(*entity,0,16, IntVector3D(680,0,165),GameInvariants::NORMAL);
            addCharacter(entity, 1, 5);
            entity = new CharEntity();
            ch.createSprite(*entity,0,16, IntVector3D(720,0,200),GameInvariants::NORMAL);
            addCharacter(entity, 1, 5);

            sceneState++;
        }
    }



    else if (sceneState == 2){
        if (ent->getX() >=600){
            std::cout << "STATE 2!!!\n";
            CharacterHeader ch;
            ch.characterName = "Y-Signal1.ch";
            ch.body = ch.head = 0;
            ch.pallet = 0;
            ch.loadData();

            CharEntity* entity = new CharEntity();
            ch.createSprite(*entity,0,24, IntVector3D(200,0,160),GameInvariants::NORMAL);
            addCharacter(entity, 5, 5);

            ch.characterName = "Electra1.ch";
            ch.loadData();

            entity = new CharEntity();
            ch.createSprite(*entity,0,26, IntVector3D(200,0,170),GameInvariants::NORMAL);
            addCharacter(entity, 3, 5);

            sceneState++;
        }
    }


    else if (sceneState == 3){
        if (ent->getX() >=750){
            std::cout << "STATE 3!!!\n";
            CharacterHeader ch;
            ch.characterName = "Y-Signal1.ch";
            ch.body = ch.head = 0;
            ch.pallet = 0;
            ch.loadData();

            CharEntity* entity = new CharEntity();
            ch.createSprite(*entity,0,24, IntVector3D(300,0,160),GameInvariants::NORMAL);
            addCharacter(entity, 5, 5);
            entity = new CharEntity();
            ch.createSprite(*entity,0,24, IntVector3D(270,0,225),GameInvariants::NORMAL);
            addCharacter(entity, 5, 5);
            entity = new CharEntity();
            ch.createSprite(*entity,0,24, IntVector3D(960,0,160),GameInvariants::NORMAL);
            addCharacter(entity, 5, 5);
//            entity = new CharEntity();
//            ch.createSprite(*entity,0,24, IntVector3D(920,0,200),GameInvariants::NORMAL);
//            addCharacter(entity, 5, 5);
//            entity = new CharEntity();
//            ch.createSprite(*entity,0,26, IntVector3D(170,0,225),GameInvariants::NORMAL);
//            addCharacter(entity, 3, 5);

            ch.characterName = "Electra1.ch";
            ch.loadData();

            entity = new CharEntity();
            ch.createSprite(*entity,0,26, IntVector3D(300,0,170),GameInvariants::NORMAL);
            addCharacter(entity, 3, 5);
            entity = new CharEntity();
            ch.createSprite(*entity,0,26, IntVector3D(940,0,225),GameInvariants::NORMAL);
            addCharacter(entity, 3, 5);
            entity = new CharEntity();
            ch.createSprite(*entity,0,26, IntVector3D(980,0,200),GameInvariants::NORMAL);
            addCharacter(entity, 3, 5);

            sceneState++;
        }
    }


    else if (sceneState >= 4 && sceneState < 20){
        CharacterHeader ch;
        ch.characterName = "Haku-oh1.ch";
        ch.body = ch.head = 0;
        ch.pallet = 0;
        ch.loadData();
        CharEntity* entity;

        if (sceneState == 4 && ent->getX() >=880){
            entity = new CharEntity();
            ch.createSprite(*entity,0,24, IntVector3D(900,0,160),GameInvariants::IN_AIR);
            entity->state->velocity.y = 7.2;
            addCharacter(entity, 4, 4);
            sceneState++;
        }else if (sceneState == 5 && ent->getX() >=900){
            entity = new CharEntity();
            ch.createSprite(*entity,0,24, IntVector3D(970,0,225),GameInvariants::IN_AIR);
            entity->state->velocity.y = 6.8;
            addCharacter(entity, 4, 4);
            sceneState++;
        }else if (sceneState == 6 && ent->getX() >=915){
            entity = new CharEntity();
            ch.createSprite(*entity,0,24, IntVector3D(1060,0,180),GameInvariants::IN_AIR);
            entity->state->velocity.y = 7.1;
            addCharacter(entity, 4, 4);
            sceneState++;
        }else if (sceneState == 7 && ent->getX() >=930){
            entity = new CharEntity();
            ch.createSprite(*entity,0,24, IntVector3D(1020,0,200),GameInvariants::IN_AIR);
            entity->state->velocity.y = 6.3;
            addCharacter(entity, 4, 4);
            sceneState++;
        }else if (sceneState == 8 && ent->getX() >=940){
            entity = new CharEntity();
            ch.createSprite(*entity,0,26, IntVector3D(1100,0,225),GameInvariants::IN_AIR);
            entity->state->velocity.y = 7.2;
            addCharacter(entity, 4, 4);
            sceneState++;
        }else if (sceneState == 9 && ent->getX() >=950){
            entity = new CharEntity();
            ch.createSprite(*entity,0,26, IntVector3D(930,0,170),GameInvariants::IN_AIR);
            entity->state->velocity.y = 6.7;
            addCharacter(entity, 4, 4);
            sceneState++;
        }else if (sceneState == 10 && ent->getX() >=960){
            entity = new CharEntity();
            ch.createSprite(*entity,0,26, IntVector3D(1120,0,225),GameInvariants::IN_AIR);
            entity->state->velocity.y = 7;
            addCharacter(entity, 4, 4);
            sceneState++;
        }else if (sceneState == 11 && ent->getX() >=970){
            entity = new CharEntity();
            ch.createSprite(*entity,0,26, IntVector3D(890,0,200),GameInvariants::IN_AIR);
            entity->state->velocity.y = 6.5;
            addCharacter(entity, 4, 4);
            sceneState++;
        }
    }

    if (carTimer>=0) carTimer++;

    if (sceneState >= 20){
        if (sceneState ==20){
            CharacterHeader ch;
            ch.characterName = "Cop-car1.ch";
            ch.body = ch.head = 0;
            ch.pallet = 0;
            ch.loadData();

            car = new CharEntity();
            ch.createSprite(*car,0,16, IntVector3D(-100,0,190),GameInvariants::NORMAL);
            addCharacter(car, 0, 5);
            sceneState =21;
            carTimer = -1;
            setScrollerSpeed(8.f, 8.f);
        }
        else if (sceneState ==21){
            if (this->scrollerCenter.x < 200 && car->getX()<0){
                carTimer = 0;
                car->setAnimation(111);
            }
            if (car->getX() >= 120 && car->state->getCurrentAnimIndex() != GameInvariants::ATTACK_1){
                car->setAnimation(GameInvariants::ATTACK_1);
            }

            if (carTimer >= 130) sceneState = 22;
        }
        else if (sceneState == 22){
            if (carTimer == 150){
                CharacterHeader ch;
                ch.characterName = "fireball.ch";
                ch.body = ch.head = 0;
                ch.pallet = 0;
                ch.loadData();

                fireball = new CharEntity();
                ch.createSprite(*fireball,0,16, IntVector3D(300,230,190),GameInvariants::NORMAL);
                addCharacter(fireball, 0, 5);

            }
            else if (carTimer == 200){
                this->moveObject(car,-1);
                car = 0;
                sceneState =23;
            }
        }
        else if (sceneState == 23){
            fireball->state->pos.x = scrollerCenter.x-250;
            fireball->state->pos.y = 350;
            fireball->setAnimation(GameInvariants::IN_AIR);
        }
        else if (sceneState == 24){
            carTimer = 0;
            sceneState = 25;
            fireball->state->pos.x = scrollerCenter.x-64;
            fireball->state->pos.y = 230;
            fireball->state->velocity.y = 2;
            fire = new SmpAnimEffectHeader("ground fire.smp");
        }
        else if (sceneState == 25){
            if (fireball->state->pos.y == 0){
                fireball->setAnimation(111);
                sceneState = 26;
                carTimer = 0;

                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS + 156, 0 , 205));
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS + 174, 0 , 205));
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS + 190, 0 , 205));

                ((CharEntity*)(scrollingEntities.begin()->first))->state->energy = 90000;
            }
        }
        else if (sceneState == 26){
            if (car != 0){
                this->moveObject(car,-1);
                car = 0;
            }
            if (carTimer == 5 && fireball!=0){
                this->moveObject(fireball,-1);
                fireball = 0;
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                140, 0 , 205));
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                208, 0 , 205));
            }
            if (carTimer == 10){
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                122, 0 , 205));
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                224, 0 , 205));
            }

            if (carTimer == 15){
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                105, 0 , 205));
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                241, 0 , 205));
            }
            if (carTimer == 20){
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                88, 0 , 205));
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                258, 0 , 205));
            }
            if (carTimer == 25){
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                71, 0 , 201));
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                275, 0 , 201));
            }
            if (carTimer == 30){
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                60, 0 , 193));
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                288, 0 , 193));
            }

            if (carTimer == 35){
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                53, 0 , 185));
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                293, 0 , 185));
            }
            if (carTimer == 40){
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                281, 0 , 177));
            }

            if (carTimer == 50){
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                69, 0 , 177));
            }

            if (carTimer == 60){
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                83, 0 , 173));
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                265, 0 , 173));
            }
            if (carTimer == 65){
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                99, 0 , 173));
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                247, 0 , 173));
            }
            if (carTimer == 70){
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                116, 0 , 173));
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                230, 0 , 173));
            }
            if (carTimer == 75){
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                133, 0 , 173));
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                213, 0 , 173));
            }
            if (carTimer == 80){
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                150, 0 , 173));
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                196, 0 , 173));
            }
            if (carTimer == 85){
                EffectsManager::addEffectToCurrentManager(fire->createEffect(Layer::getCurrentLayer()->screenXStart()+GameInvariants::SCROLL_PIXELS +
                180, 0 , 173));
            }

            if (carTimer == 175){
//                sceneState = beforeSpecialState;
                sceneState = -1;
//                ((CharEntity*)(scrollingEntities.begin()->first))->state->energy = GameInvariants::LIFE_BAR;
            }
        }
    }


    if (clock%600 == 0){
        AudioManager::playSound(54,scrollerCenter.x + 200, 50, 100);
    }


//    long elapsedTime = getTimeSeconds();
//
//    if (clock%60 == 0){
////        std::cout << elapsedTime << "\n";
//        // start train move
//        if (elapsedTime == 15){
//            trainSound = AudioManager::playSound(22);
//            AudioManager::setAttenuation(trainSound,3000, 8);
//            AudioManager::setPosition(trainSound, 7000,0,10);
//        }else if (elapsedTime == 21){
//
//            layers[4]->autoVel.x = 6.8;
//            layers[5]->autoVel.x = 6.8;
//        }
//        else if (elapsedTime == 30){
//            AudioManager::stopSound(trainSound);
//            trainSound = AudioManager::playSound(23);
//            AudioManager::setAttenuation(trainSound,1, 0);
//        }
//    }
//
//    // control train audio
//    if (elapsedTime >=15 && elapsedTime <=30){
//        if (!AudioManager::isPlaying(trainSound))
//            AudioManager::replay(trainSound);
//        int tmp = getClocks() - 15*60;
////        std::cout << 7000-tmp*5 << "\n";
//        AudioManager::setPosition(trainSound, 7000-tmp*6 ,0,10);
//    }
//
//    // train deaceleration
//    if (elapsedTime >=30 && elapsedTime < 41 && layers[4]->autoVel.x > 0){
//
//        layers[4]->autoVel.x -= 0.02;
//        if (layers[4]->autoVel.x <= 0){
//            layers[4]->autoVel.x = 0;
//            std::cout << "STOP = " << elapsedTime << "\n";
//        }
//        layers[5]->autoVel.x = layers[4]->autoVel.x;
//    }
//    else if (elapsedTime == 37){
//        trainStopped = true;
//    }
//    else if (elapsedTime == 38){
//        trainStopped = false;
//    }
//    // Train acceleration
//    else if (elapsedTime >=48 && layers[4]->autoVel.x < 7){
//        layers[4]->autoVel.x += 0.02;
//        layers[5]->autoVel.x = layers[4]->autoVel.x;
//    }




    std::vector<Layer*>::iterator it;
    currLayerId = 0;
    for(it = layers.begin(); it!=layers.end(); ++it){
        (*it)->updateControls();
        ++currLayerId;
    }
}


void Scene::updateViews(){

    // TODO: ##### ...
    // if someone to move, do it
    while (!toMove.empty()){
//        std::cout << "move object\n";
        moveObjectNow();
//        std::cout << "DONE\n";
    }

//    std::cout << "update SCROLL\n";
    // Update ScrollPosition
    updateScrollPosition();
    AudioManager::clearInactiveSounds();
    AudioManager::updateListener(scrollerCenter.x, 0, scrollerCenter.y+screenAlfSize.y);
//    std::cout << "DONE\n";

//    std::cout << "update views\n";
    // Update Views
    currLayerId = 0;
    std::vector<Layer*>::iterator it;
    for(it = layers.begin(); it!=layers.end(); ++it){
        (*it)->updateViews();
        ++currLayerId;
    }

//    std::cout << "DONE\n";

}


void Scene::display(sf::RenderTarget* target){
    std::vector<Layer*>::iterator it;
    currLayerId = 0;
    for(it = layers.begin(); it!=layers.end(); ++it){
//        int oldAlfX = screenAlfSize.x;
//        int oldAlfY = screenAlfSize.y;
//        if (currLayerId == 2){
//            screenAlfSize.x = (int)(screenAlfSize.x*2);
//            screenAlfSize.y = (int)(screenAlfSize.y*2);
//        }
        (*it)->display(target);
//        screenAlfSize.x = oldAlfX;
//        screenAlfSize.y = oldAlfY;
        ++currLayerId;
    }
}


void Scene::addCharacter(CharEntity* entity, int controlKey, int layer){
    layers[layer]->addCharacter(entity,controlKey);
}

void Scene::addScrollingCharacter(CharEntity* entity, int controlKey, int layer){
    layers[layer]->addCharacter(entity,controlKey);
    scrollingEntities[entity] = layer;
}

void Scene::removeScrollingEntity(AEntity* entity){
    scrollingEntities.erase(entity);
}




// -------------------------
//  -- Window Operations --

void Scene::setScreenAlfSize(int alfWidth, int alfHeight){
    screenAlfSize.x = alfWidth;
    screenAlfSize.y = alfHeight;
}

void Scene::setToleratedBox(int alfWidth, int alfHeight){
    toleratedBox.x = alfWidth;
    toleratedBox.y = alfHeight;
}

void Scene::setWindow(int left, int top, int right, int bottom){
    window.Top = top;
    window.Bottom = bottom;
    window.Left = left;
    window.Right = right;
}

void Scene::setScrollerCenter(int x, int y){
    scrollerCenter.x = x;
    scrollerCenter.y = y;
}

void Scene::setScrollerSpeed(float xSpeed, float ySpeed){
    scrollerSpeed.x = xSpeed;
    scrollerSpeed.y = ySpeed;
}

const sf::Vector2f& Scene::getScrollerPosition(){
    return scrollerCenter;
}

const sf::Vector2i& Scene::getSreenAlfSize(){
    return screenAlfSize;
}





sf::Vector2f Scene::moveObject(AObject* obj, int targLayer){
    toMove.push_back(obj->getKey());
    this->srcLayer = Layer::getCurrentLayer();
    if (targLayer > 0 && targLayer <(int)layers.size()){
        this->trgLayer = layers[targLayer];
        float wx = srcLayer->layer2worldX(obj->getX());
        float wy = srcLayer->layer2worldY(obj->getY());
        return sf::Vector2f(
            this->trgLayer->world2layerX(wx),
            this->trgLayer->world2layerY(wy)
        );
    }else{
        trgLayer = 0;
        return sf::Vector2f(-1,-1);
    }
}


void Scene::moveObjectNow(){
    if (srcLayer->controllers.players.find(toMove.back()) == srcLayer->controllers.players.end()){
         toMove.pop_back();
         return;
    }
    AController* controller = srcLayer->controllers.players[toMove.back()];
    if (trgLayer == 0){
        if (scrollingEntities.find(controller->getEntity())!=scrollingEntities.end()){
            CharEntity* ent = static_cast<CharEntity*>(controller->getEntity());
            ent->setAnimation(GameInvariants::IN_AIR);
            ent->reborn((int)(getScrollerPosition().x-120), 200, 200);

            std::map<UInt,AController*>::iterator it;
            for(it = srcLayer->controllers.players.begin(); it!=srcLayer->controllers.players.end(); ++it){
                if (it->second != 0){
                    CharEntity* ent2 = static_cast<CharEntity*>(it->second->getEntity());
                    if (ent2 != ent){
    //                    if (ent2->getTheGrabber() != 0){
    //                        ent2->getTheGrabber()->knockDown();
    //                    }
    //                    if (ent2->getGrabbed() != 0){
    //                        ent2->knockDown();
    //                    }
    //                    ent2->state->gotHit = ent2->state->gotKnocked = true;
//                        std::cout << "knock Down\n";
                        ent2->state->hitInfo.hits = 0;
                        ent2->state->hitInfo.hitterState = 0;
                        ent2->knockDown();
//                        std::cout << "DONE\n";
                    }
                }
            }

        }else{
            controller = srcLayer->removeController(toMove.back());
            View* view = srcLayer->removeView(toMove.back());
            delete controller;
            delete view;
        }
    }else{
        controller = srcLayer->removeController(toMove.back());
        View* view = srcLayer->removeView(toMove.back());
        if (controller != 0){
            trgLayer->addController(controller);
        }

        if (view != 0){
            trgLayer->addView(view);
        }
    }

    toMove.pop_back();
}
