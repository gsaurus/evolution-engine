#ifndef ACONTROLLER_H_INCLUDED
#define ACONTROLLER_H_INCLUDED

#include <list>

#include "TypeUtils.h"
#include "AControlledEntity.h"
#include <SFML/Graphics.hpp>


class AControlledEntity;


/**
 * abstract representation of a controller
 * A controller specifies the input commands to send to an entity
 *
 * @author Gil Costa
 */
class AController{

    public: // TODO: protected?
        struct KeyEntry{
            UInt key;
            bool pressed;
            // TODO: timestamp?
        };

    protected:

        /** controlled entity */
        AControlledEntity* entity;
        /** keys waiting to be applied */
        std::list<KeyEntry> waitingKeys;    // TODO: this better
    public:
        AController();
        AController(AControlledEntity* entity);
        virtual ~AController();

        void setEntity(AControlledEntity* entity);
        int getIdKey();
        AControlledEntity* getEntity();
        virtual void applyKeys();

};

#endif // ACONTROLLER_H_INCLUDED
