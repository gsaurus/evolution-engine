#ifndef SOUND_EFFECT_H_INCLUDED
#define SOUND_EFFECT_H_INCLUDED

#include "AEffect.h"
#include "SoundEffectHeader.h"

class SoundEffect: public AEffect{
 public:
    struct SoundData{
        int soundIndex;
        sf::Vector3f position; // TODO: all effects has it?
        float minDistance;
        float attenuation;
        float pitch;
    };

 private:
    SoundData data;
    int playingSound;

    void start();
 public:
    SoundEffect(int soundIndex, float x, float y, float z, float minDistance, float attenuation, float pitch);
    SoundEffect(int soundIndex);
//    SoundEffect(int soundIndex);
    ~SoundEffect();

    void setPosition(float x, float y, float z);
    void setAttenuation(float minDistance, float attenuation);
    void setPitch(float pitch);


    bool update();

    int getPlayingSoundKey() const;
};

#endif // SOUND_EFFECT_H_INCLUDED
