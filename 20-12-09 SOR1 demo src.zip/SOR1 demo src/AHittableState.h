#ifndef AHITTABLESTATE_H_INCLUDED
#define AHITTABLESTATE_H_INCLUDED

#include "AEntityState.h"
#include "HitInfo.h"
#include "TypeUtils.h"

/**
 * State for entities that can be hit by something
 * Energy and information about an hit are part of the state
 *
 * @author Gil Costa
 */
class AHittableState: public AEntityState{
    public:
        int maxEnergy;
        int energy;
        bool invincible;

        HitInfo hitInfo;

    public:


        // --------------------
        //  -- Constructors --
        // --------------------

        /** default constructor */
        AHittableState();

        /**
         * copy constructor
         * pre: other != null
         */
        AHittableState(const AHittableState* other);


        // -----------------------
        //  --- Const Getters ---
        // -----------------------
        int getEnergy() const;
        int getMaxEnergy() const;

        /** return true if the hittable is faced left */
        virtual bool isFacedLeft() const;
        bool isInvincible() const;


};

#endif // AHITTABLESTATE_H_INCLUDED
