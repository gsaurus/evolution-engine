#ifndef LAYER_DATA_LOADER_H_INCLUDED
#define LAYER_DATA_LOADER_H_INCLUDED

#include <vector>
#include <string>

#include "ALayerData.h"

/**
 * This class is a workaround, we want to load a kind of class accordingly
 * to what kind of layer we are loading, withouth making layers harder to load
 * so we load the first part, then fill a new instance accordingly to the kind of layer being loaded
 *
 * @author Gil Costa
 */
class LayerDataLoader: protected ALayerData{
    protected:
        // ---------------
        //  -- Fields --
        // ---------------

        /** The loaded layer */
        ALayerData* layer;

    public:

        //-------------------------------
        // -- Initializations and etc --

        /** default constructor */
        LayerDataLoader();

        /** loads accordingly to the type of ALayerData */
        ALayerData* loadLayerData(const std::string& fileName) throw(IOException);


    protected:
        //-----------------------------
        // ------- LOAD / SAVE -------

        void readData(DataInputStream& dis) throw(IOException);
        //void writeHeader(DataOutputStream& dos) throw(IOException);

        void readObjects(DataInputStream& dis) throw(IOException);


        /** load the information from the dataBase @see AHeader */
        void loadData();
        /** say if the entity resources are full loaded @see AHeader */
        bool ready() const throw();

        bool applyToSprite(sf::Sprite& sprite, int index) const;

        UInt getNumObjects() const;
        int getFrameWidth(int index) const;
        int getFrameHeight(int index) const;

};



#endif // LAYER_DATA_LOADER_H_INCLUDED
