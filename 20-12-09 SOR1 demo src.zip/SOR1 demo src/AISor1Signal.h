#ifndef AI_SOR1_SIGNAL_H_INCLUDED
#define AI_SOR1_SIGNAL_H_INCLUDED


#include "AITrivialController.h"


/**
 * Control by keyboard input
 * it comes from system events (OSInput)
 *
 * @author Gil Costa
 */
class AISor1Signal: public AITrivialController{
    protected:

    public:
        AISor1Signal();
        AISor1Signal(AControlledEntity* entity);

        void applyKeys();

};

#endif // AI_SOR1_SIGNAL_H_INCLUDED

