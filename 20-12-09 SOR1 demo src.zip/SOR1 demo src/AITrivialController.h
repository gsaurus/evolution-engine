#ifndef AI_TRIVIAL_CONTROLLER_H_INCLUDED
#define AI_TRIVIAL_CONTROLLER_H_INCLUDED


#include "AController.h"


/**
 * Control by keyboard input
 * it comes from system events (OSInput)
 *
 * @author Gil Costa
 */
class AITrivialController: public AController{
    protected:
        int TX, TZ;
        bool flag;

        void stop();
        void copSuffer();
    public:
        AITrivialController();
        AITrivialController(AControlledEntity* entity);

        void applyKeys();

};

#endif // AI_TRIVIAL_CONTROLLER_H_INCLUDED
