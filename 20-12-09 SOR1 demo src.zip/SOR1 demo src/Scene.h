#ifndef SCENE_H_INCLUDED
#define SCENE_H_INCLUDED

#include <vector>
#include <list>
#include <map>
#include <SFML/Graphics.hpp>

#include "ADisplayable.h"
#include "AFileResolver.h"
#include "Layer.h"

class Layer;

/**
 * Scene (set of layers)
 * @see AReadable.h
 *
 * @author Gil Costa
 */
class Scene: public AFileResolver, ADisplayable{
  protected:
    sf::Vector2i* getTarget();
    void updateScrollPosition();
    static long clock;   // TODO: ######## this is temporary

    static int currLayerId;

//    int trainSound;  // TODO: ####### Scene specific


    // moving a sprite between layers
    std::list<int> toMove;
    Layer* srcLayer;
    Layer* trgLayer;
    void moveObjectNow();

  public:

    static long getTimeSeconds(); // TODO: ######## this is temporary
    static long getClocks();    // TODO: ######## this is temporary

    static int getCurrLayerId();

    static Scene* currentScene; // TODO: ######## this is temporary

    int sceneState;
    int beforeSpecialState;

    CharEntity* car;
    CharEntity* fireball;
    AEffectHeader* fire;
    int carTimer;

//    static bool trainStopped;

    //--------------
    // -- FIELDS --
    //--------------
    std::vector<Layer*> layers;

    sf::IntRect window;
    sf::Vector2i screenAlfSize;
    sf::Vector2i toleratedBox;
    sf::Vector2f scrollerCenter;
    sf::Vector2f scrollerSpeed;

    std::map<AEntity*,int> scrollingEntities;


    //--------------------
    // -- CONSTRUCTORS --
    //--------------------
    Scene();
    /** create a scene associated to the given fileName */
    Scene(const std::string& fileName);
    // destructor
    ~Scene();


    //---------------
    // -- METHODS --
    //---------------

    void setFileName(const std::string& fileName) throw();


    void readData(DataInputStream& dis) throw(IOException);
    //void writeData(DataOutputStream& dos) throw(IOException);

    void updateControls();
    void updateViews();

    /** display all layers and views */
    void display(sf::RenderTarget* target);


    void addCharacter(CharEntity* entity, int controlKey, int layer);
    void addScrollingCharacter(CharEntity* entity, int controlKey, int layer);
    // TODO: add other kind of entities

    void removeScrollingEntity(AEntity* entity);

    /** changes obj from currentLayer to trgLayer */
    sf::Vector2f moveObject(AObject* obj, int targLayer);


    // -------------------------
    //  -- Window Operations --

    void setScreenAlfSize(int alfWidth, int alfHeight);
    void setToleratedBox(int alfWidth, int alfHeight);
    void setWindow(int left, int top, int right, int bottom);
    void setScrollerCenter(int x, int y);
    void setScrollerSpeed(float xSpeed, float ySpeed);
    const sf::Vector2f& getScrollerPosition();
    const sf::Vector2i& getSreenAlfSize();

};


#endif // SCENE_H_INCLUDED
