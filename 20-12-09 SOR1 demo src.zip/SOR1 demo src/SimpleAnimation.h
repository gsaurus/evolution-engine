#ifndef SIMPLE_ANIMATION_H_INCLUDED
#define SIMPLE_ANIMATION_H_INCLUDED

#include <vector>

#include "AAnimation.h"
#include "FramesCollection.h"
#include "AHeader.h"


/**
 * SimpleAnimation data
 * @see AReadable.h
 *
 * @author Gil Costa
 */
class SimpleAnimation: public AAnimation, public AFileResolver, public AHeader{
  public:

    //--------------
    // -- FIELDS --
    //--------------
    std::string collectionName;
    const FramesCollection* collection;


    //--------------------
    // -- CONSTRUCTORS --
    //--------------------
    SimpleAnimation();
    // destructor
//    ~SimpleAnimation();


    //---------------
    // -- METHODS --
    //---------------
//    void computeTotalTime();

    void readData(DataInputStream& dis) throw(IOException);
    //void writeData(DataOutputStream& dos) throw(IOException);

    const Frame& getFrame(int frameIndex) const;
    bool applyToSprite(sf::Sprite& sprite, int index) const;

    void loadData();
    bool ready() const throw();

};


#endif // SIMPLE_ANIMATION_H_INCLUDED
