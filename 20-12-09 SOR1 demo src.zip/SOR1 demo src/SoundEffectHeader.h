#ifndef SOUND_EFFECT_HEADER_H_INCLUDED
#define SOUND_EFFECT_HEADER_H_INCLUDED

#include "AEffectHeader.h"
#include <SFML/System.hpp>

class SoundEffectHeader: public AEffectHeader{
 protected:
    int soundIndex;
    float minDistance;
    float attenuation;
    float pitch;
    float volume;

 public:
    SoundEffectHeader(DataInputStream& dis) throw(IOException);
    virtual void readData(DataInputStream& dis) throw(IOException);

    virtual AEffect* createEffect(float x, float y, float z);
};

#endif // SOUND_EFFECT_HEADER_H_INCLUDED
