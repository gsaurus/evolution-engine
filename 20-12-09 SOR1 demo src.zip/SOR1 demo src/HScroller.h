#ifndef H_SCROLLER_H_INCLUDED
#define H_SCROLLER_H_INCLUDED

#include "AScroller.h"
#include "Layer.h"
#include "TypeUtils.h"
#include "LayerObj.h"
#include <set>

/**
 * Horizontal Scroller
 * @see ADisplayable.h
 *
 * @author Gil Costa
 */
class HScroller: public AScroller{
    protected:
        // comparator functors:
        struct cmpStarts : public std::binary_function<int, int, bool>{
            HScroller* scroller;
            cmpStarts(HScroller* scroller): scroller(scroller) {}
            bool operator()(int ia, int ib) const{
                return scroller->getStart(ia) < scroller->getStart(ib);
            };
        };

        struct cmpEnds : public std::binary_function<int, int, bool>{
            HScroller* scroller;
            cmpEnds(HScroller* scroller): scroller(scroller) {}
            bool operator()(int ia, int ib) const{
                return scroller->getEnd(ia) < scroller->getEnd(ib);
            };
        };


//        struct cmpStarts: std::binary_function<int, int, bool>{
//            cmpStarts(HScroller* scroller): _parser(p) {}
//            bool operator() (const op_info& o1, const op_info& o2) {
//                return _parser->op_comp(o1, o2);
//            }
//            parser * _parser;
//        };


        /**
         * All objects ordered by X
         * value: index at vector
         */
        std::vector<int> starts;
        std::vector<int> ends;

        /** iterator over objsByX */
        UInt start, end;

        /** buffer of objects to render */
        std::set<int> objBuffer;

        /** last x position, to know what direction is it moving */
        int lastXPos;

        void restartScroll();
        void organizeScroll();
        LayerObj* getObj(int index) const;
        int getStart(int index) const;
        int getEnd(int index) const;

    public:

        /** default constructor */
        HScroller(Layer* layer);
        /** destructor */
        ~HScroller();


        /** display the layer and the views of the existing entities */
        void display(sf::RenderTarget* target);

};



#endif // H_SCROLLER_H_INCLUDED
