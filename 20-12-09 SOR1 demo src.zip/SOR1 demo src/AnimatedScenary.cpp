#include "AnimatedScenary.h"



//--------------------
// -- CONSTRUCTORS --
//--------------------
AnimatedScenary::AnimatedScenary():AAnimation(), time(0), currFrame(0){
    // does nothing
}


//---------------
// -- METHODS --
//---------------



bool AnimatedScenary::update(){
    if (++time >= frames[currFrame]->duration){
        currFrame = (currFrame+1)%frames.size();
        time = 0;
        return true;
    }
    return false;
}

UInt AnimatedScenary::getCurrFrame(){
    return frames[currFrame]->frameIndex;
}
