#ifndef UTILS_H_INCLUDED
#define UTILS_H_INCLUDED


typedef unsigned char UByte;
typedef unsigned int UInt;

#endif // UTILS_H_INCLUDED
