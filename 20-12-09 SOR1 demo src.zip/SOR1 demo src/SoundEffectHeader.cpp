#include "SoundEffectHeader.h"
#include "SoundEffect.h"
#include "GameInvariants.h"
#include "AudioManager.h"

#include "Scene.h"

#include <iostream>


SoundEffectHeader::SoundEffectHeader(DataInputStream& dis) throw(IOException){
    readData(dis);
}

void SoundEffectHeader::readData(DataInputStream& dis) throw(IOException){
    soundIndex = dis.readInt16();
    minDistance = dis.readFloat();
    attenuation = dis.readFloat();
    pitch = dis.readFloat();

    if (minDistance == 0){
        minDistance = GameInvariants::SOUND_MIN_DISTANCE;
        attenuation = GameInvariants::SOUND_ATTENUATION;
        pitch = 1.f;
    }
    AudioManager::loadSpecificSound(soundIndex);
}




AEffect* SoundEffectHeader::createEffect(float x, float y, float z){
//    std::cout << "GGGGGGGRRRR: " << Scene::getCurrLayerId() << "\n";
//    if (Scene::getCurrLayerId() == 2)
//        return new SoundEffect(soundIndex, x, y, z, minDistance, attenuation, pitch, 0);
//    else
        return new SoundEffect(soundIndex, x, y, z, minDistance, attenuation, pitch);
}
