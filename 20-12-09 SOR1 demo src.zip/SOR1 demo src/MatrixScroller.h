#ifndef MATRIX_SCROLLER_H_INCLUDED
#define MATRIX_SCROLLER_H_INCLUDED

#include "AScroller.h"
#include "Layer.h"
#include "TypeUtils.h"

/**
 * Horizontal Scroller
 * @see ADisplayable.h
 *
 * @author Gil Costa
 */
class MatrixScroller: public AScroller{
    public:

        /** default constructor */
        MatrixScroller(Layer* layer);
        /** destructor */
        ~MatrixScroller();


        /** display the layer and the views of the existing entities */
        void display(sf::RenderTarget* target);

};



#endif // MATRIX_SCROLLER_H_INCLUDED
