#ifndef DATABASE_H_INCLUDED
#define DATABASE_H_INCLUDED

#include <vector>

#include "GameInvariants.h"
#include "HashMap.h"
#include "Character.h"
#include "FramesCollection.h"
#include "Pallet.h"
#include "ALayerData.h"
#include "MatrixImage.h"


/**
 * A static class that handles the loaded objects in memory
 *
 * @author Gil Costa
 */
class DataBase{
    protected:
        // TODO: concorrential loads, deletes, manage data being used
        static HashMap<std::string,Character*> chars;
        static HashMap<std::string,std::vector<FramesCollection*> > icls;
        static HashMap<std::string,Pallet*> palls;
        static HashMap<std::string,ALayerData*> layers;
        static HashMap<std::string,MatrixImage*> matrixImages;

        static std::vector<UByte> randomTable;  // TODO: not being used yet
        static UInt randIndex;

    public:
        static std::string getPalletNameFromICLName(const std::string& fileName, UInt pall) throw();

        /** Get the objects referent to the given fileNames */
        static const Character* getCharacter(const std::string& fileName) throw(IOException);
        static const FramesCollection* getICL(const std::string& fileName) throw(IOException);
        static const FramesCollection* getICL(const std::string& fileName, UInt pall) throw();
        static const Pallet* getPallet(const std::string& fileName) throw(IOException);
        static ALayerData* getLayer(const std::string& fileName) throw(IOException);
        static const MatrixImage* getMatrixImage(const std::string& fileName) throw(IOException);

        //static const Pallet* getPalletFromICLName(const char* fileName, UInt pall) throw(IOException);

//        static void removeCharacter(int id);
//        static void removeICL(int id);
//        static void removePallet(int id);
//        /** remove only one pallet version (perhaps the original!) */
//        static void removeICL(int id, UInt pall);

        static void clearEverything();

        static void initRandomTable();
        static const std::vector<UByte>& getRandomTable();

        static UInt getRandomNum();
        static int getRand(int val);
        static float getRand(float val);
        static void setRandIndex(UInt index);
        static UInt getRandIndex();

};

#endif // DATABASE_H_INCLUDED
