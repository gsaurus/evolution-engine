#ifndef CONTROLLERS_MANAGER_H_INCLUDED
#define CONTROLLERS_MANAGER_H_INCLUDED


#include "AUpdatable.h"
#include "TypeUtils.h"
#include "AController.h"

#include <map>

/**
 * Controls the gameplay
 *    - controllers of entities
 *    - ...
 *
 * @author Gil Costa
 */
class ControllersManager: public AUpdatable{
    protected:
        // allows multiple players { maybe for online combat mode :) }
    // TODO: #########...
    public:
        std::map<UInt,AController*> players;
        std::list<AController*> enemies;

    protected:

        // all other active stuff
        //std::list<A> stuff;
        // pickables (goodies, weapons...)
        //std::list<A> stuff;

        // helping functions
        void testThrows();
        void testHits();
//        void testGrabs();
        void updateSprites();
        void updateControllers();

    public:
        ControllersManager();
        ~ControllersManager();
//        void reservePlayers(int size);
//        void setPlayer(UInt pos, AController* player);
        void addPlayer(AController* player);
        void addEnemy(AController* enemy);
        void deletePlayer(int key);
        void deleteEnemy(int key);
        AController* removePlayer(int key);
        AController* removeEnemy(int key);
        void clearPlayers();
        void clearEnemies();

        bool update();
};

#endif // CONTROLLERS_MANAGER_H_INCLUDED
