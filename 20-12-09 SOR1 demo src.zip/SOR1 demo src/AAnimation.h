#ifndef AANIMATION_H_INCLUDED
#define AANIMATION_H_INCLUDED

#include <vector>

#include "AReadable.h"
#include "AnimFrame.h"


/**
 * AAnimation data
 * @see AReadable.h
 *
 * @author Gil Costa
 */
class AAnimation: public AReadable{
  protected:
    //--------------
    // -- FIELDS --
    //--------------
    std::vector<AnimFrame*> frames;

  public:


    //--------------------
    // -- CONSTRUCTORS --
    //--------------------
    AAnimation();
    // destructor
    virtual ~AAnimation();


    //---------------
    // -- METHODS --
    //---------------
//    void computeTotalTime();
    UInt getFrameDuration(int frameIndex) const;
    UInt size() const;

    virtual void readData(DataInputStream& dis) throw(IOException);
    //void writeData(DataOutputStream& dos) throw(IOException);


};


#endif // AANIMATION_H_INCLUDED
