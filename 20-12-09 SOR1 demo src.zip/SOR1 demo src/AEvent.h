#ifndef AEVENT_H_INCLUDED
#define AEVENT_H_INCLUDED

/**
 * Interface for generic events
 * can be anything sent from one object to another
 *     - example: sprites sending events to the layer system
 *
 * @author Gil Costa
 */
class AEvent{

};

#endif // AEVENT_H_INCLUDED
