#ifndef AENTITY_H_INCLUDED
#define AENTITY_H_INCLUDED

#include "TypeUtils.h"

#include "AUpdatable.h"
#include "AObject.h"
#include "AEntityState.h"
#include "HitInfo.h"

/**
 * Abstract entities,
 * instances of EntityHeaders
 *  - must have an EntityState associated
 *
 * @author Gil Costa
 */
class AEntity: public AObject, public AUpdatable{
    protected:
//        /** the state that is being constructed */
//        AEntityState* state;
//        /** the last acepted state */
//        AEntityState* lastState;

    public:
        virtual ~AEntity();

        /** @return the last valid state */
        virtual const AEntityState* getState() const = 0;


        /** activate/deactivate the entity */
        virtual void setActive(bool active) = 0;

//        /**
//         * request to perform an action
//         * @return true if the action is accepted
//         */
//        virtual bool actionRequest(int actionType, void* param = 0) = 0;

        virtual UInt beingHit(const HitInfo& hitInfo);

        // --------------------------------------------------
        // usual tests related to sprites
        virtual bool testGrab(AEntity* other);

};

#endif // AENTITY_H_INCLUDED
