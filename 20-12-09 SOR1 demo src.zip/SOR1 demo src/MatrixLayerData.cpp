#include "MatrixLayerData.h"

#include "GameInvariants.h"
#include "DataBase.h"
#include <list>
#include <iostream>


// default constructor
MatrixLayerData::MatrixLayerData():ALayerData(){
    // Does nothing
}


// Destructor
MatrixLayerData::~MatrixLayerData(){
    // delete objects
    if (!objects.empty()){
        // delete objects
        std::vector<LayerObj*>::iterator it1 = objects.begin();
        for(; it1!=objects.end(); ++it1){
            delete *it1;
        }
    }
}



//-----------------------------
// ------- LOAD / SAVE -------




void MatrixLayerData::readObjects(DataInputStream& dis) throw(IOException){
    // -- read layer objects --
    int mxWidth = dis.readInt16();
    int mxHeight = dis.readInt16();
    int N = (width/mxWidth) * (height/mxHeight);

    mx.resize(N);
    // a temporary list to store objects, because we don't know how many to store on the vector
    std::list<LayerObj*> theObjects;
    // read all objects
    for(int i=0; i<N ; ++i){
        mx[i] = dis.readInt16();
        if (mx[i] < 0){
            if (mx[i]<=-GameInvariants::MAX_ANIMATIONS){
                LayerObj* obj = new LayerObj(this);
                obj->frameIndex = mx[i];

                obj->parameters = dis.readInt32();
                theObjects.push_back(obj);
                mx[i] = -GameInvariants::MAX_ANIMATIONS-theObjects.size()+1;
            }else{
                int size = dis.readSignedByte();
                if (size > 0){
                    LayerObj* obj = new LayerObj(this);
                    obj->frameIndex = mx[i];

                    obj->alternativeAnims.reserve(size);
                    for (int k=0; k<size; ++k){
                        obj->alternativeAnims.push_back(dis.readByte());
                    }
                    theObjects.push_back(obj);
                    mx[i] = -GameInvariants::MAX_ANIMATIONS-theObjects.size()+1;
                }
            }
        }
    }
    // pass the objects on the list to the vector
    objects.reserve(theObjects.size());
    std::list<LayerObj*>::const_iterator it;
    for(it = theObjects.begin(); it!=theObjects.end(); ++it){
        objects.push_back(*it);
    }
}



void MatrixLayerData::loadData(){
    image = DataBase::getMatrixImage(dataFilename);
}


bool MatrixLayerData::ready() const throw(){
    return image!=0;
//    if (image == 0) return false;
//    return image->isLoaded();
}




UInt MatrixLayerData::getNumObjects() const{
    return mx.size();
}
int MatrixLayerData::getFrameWidth(int index) const{
    return image->getCellWidth();   // they are all same sized
}
int MatrixLayerData::getFrameHeight(int index) const{
    return image->getCellHeight();  // they are all same sized
}


int MatrixLayerData::getXFromColumn(int col) const{
    return col*image->getCellWidth();
}

int MatrixLayerData::getYFromRow(int row) const{
    return row*image->getCellHeight();
}


int MatrixLayerData::getXFromIndex(int index) const{
    return getCollumnFromIndex(index) * image->getCellWidth();
}
int MatrixLayerData::getYFromIndex(int index) const{
    return getRowFromIndex(index) * image->getCellHeight();
}
int MatrixLayerData::getCollumnFromIndex(int index) const{
    return index%getNumColumns();
}
int MatrixLayerData::getRowFromIndex(int index) const{
    return index/getNumColumns();
}


// converts (column,row) into index
int MatrixLayerData::getIndex(int column, int row, bool tiling) const{
    if (tiling){
        int numCols = getNumColumns();
        int numRows = getNumRows();
        if (column >= numCols || column < 0) column %= numCols;
        if (row >= numRows || row < 0)       row %= numRows;
        if (column<0) column+=numCols;
        if (row<0) row+=numRows;
        return row*numCols + column;
    }else return row*getNumColumns() + column;
}

// tells how much that column is out of bounds (how many "sizes")
int MatrixLayerData::getColumnBoundTimes(int column) const{
    int numCols = getNumColumns();
    int res = column / numCols;
    if (column<0 && column%numCols!=0) --res;
    return res;
}
// tells how much that row is out of bounds (how many "sizes")
int MatrixLayerData::getRowBoundTimes(int row) const{
    int numRows = getNumRows();
    int res = row / numRows;
    if (row<0 && row%numRows!=0) --res;
    return res;
}


// Usefull getters to find delimiters
int MatrixLayerData::getNearestLeftColumn(int x) const{
    return x/image->getCellWidth() - (x<0?1:0);
}
int MatrixLayerData::getNearestRightColumn(int x) const{
    return x/image->getCellWidth() + (x>0?1:0);
}
int MatrixLayerData::getNearestTopRow(int y) const{
    return y/image->getCellHeight() - (y<0?1:0);
}
int MatrixLayerData::getNearestBottomRow(int y) const{
    return y/image->getCellHeight() + (y>0?1:0);
}


int MatrixLayerData::getNumColumns() const{
    return width/image->getCellWidth();
}
int MatrixLayerData::getNumRows() const{
    return height/image->getCellHeight();
}



bool MatrixLayerData::applyToSprite(sf::Sprite& sprite, int index) const{
    int mxIndex = mx[index];
    if (image!=0 && mxIndex != GameInvariants::NULL_MATRIX_CELL){
        if (mxIndex < 0){
//            std::cout << mxIndex << "....\n";
            if (mxIndex <= -GameInvariants::MAX_ANIMATIONS){
                LayerObj* obj = objects[-mxIndex-GameInvariants::MAX_ANIMATIONS];
                if (obj->frameIndex <= -GameInvariants::MAX_ANIMATIONS){
                    // TODO: special effects
                }else{ // else it's an animation
                    // TODO: ask something about alternative animations
                    int frameIndex = anims[-obj->frameIndex-1]->getCurrFrame();
                    sprite.SetImage(image->getImage());
                    sprite.SetSubRect( image->getSubRect(frameIndex) );
//                    sprite.SetPosition(getXFromIndex(frameIndex),getYFromIndex(frameIndex));
                    sprite.SetCenter(0, 0);
                }
            }else{ // simple animation, no parameters
                int frameIndex = anims[-mxIndex-1]->getCurrFrame();
//                std::cout << frameIndex << " <- put this one, cose " << image->getNumColumns()*image->getNumRows() <<"\n";
                sprite.SetImage(image->getImage());
                sprite.SetSubRect( image->getSubRect(frameIndex) );
//                sprite.SetPosition(getXFromIndex(index),getYFromIndex(index));
                sprite.SetCenter(0, 0);
            }
        }else{
            sprite.SetImage(image->getImage());
            sprite.SetSubRect(image->getSubRect(mxIndex));
//            sprite.SetPosition(getXFromIndex(index),getYFromIndex(index));
            sprite.SetCenter(0, 0);
        }
        return true;
    }
    return false;
}



void MatrixLayerData::display(sf::RenderTarget* target, int left, int top, int right, int bottom, bool tileWidth, bool tileHeight) const{
    int xi = getNearestLeftColumn(left);
    int xf = getNearestRightColumn(right);
    int yi = getNearestTopRow(top);
    int yf = getNearestBottomRow(bottom);

    // arrange bounds
    if (!tileWidth){
        xi = std::max(xi,0);
        xf = std::min(xf,getNumColumns());
    }
    if (!tileHeight){
        yi = std::max(yi,0);
        yf = std::min(yf,getNumRows());
    }
    bool someTile = tileWidth || tileHeight;

    sf::Sprite sprite;
    int index;
    int x;
    for(int y = yi; y<yf; ++y){
        for(x = xi; x<xf; ++x){
            index = getIndex(x,y,someTile);
            if (applyToSprite(sprite,index)){
                sprite.SetPosition(getXFromColumn(x),getYFromRow(y));
                target->Draw(sprite);
            }
        }
    }
}
