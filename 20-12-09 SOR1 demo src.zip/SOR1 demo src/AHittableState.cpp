#include "AHittableState.h"

AHittableState::AHittableState():
    AEntityState(),
    maxEnergy(0),
    energy(0)
{
    // Do nothing
}

AHittableState::AHittableState(const AHittableState* other):
    AEntityState(other),
    maxEnergy(other->getMaxEnergy()),
    energy(other->getEnergy())
{
    // Do nothing
}



// -----------------------
//  --- Const Getters ---
// -----------------------
int AHittableState::getEnergy() const{ return energy; }
int AHittableState::getMaxEnergy() const{ return maxEnergy; }

// By default it has no left notion, so it's always faced right
bool AHittableState::isFacedLeft() const{ return false; }
bool AHittableState::isInvincible() const{ return invincible; }
