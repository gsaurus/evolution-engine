#ifndef AI_CONTROLLER_H_INCLUDED
#define AI_CONTROLLER_H_INCLUDED


#include "AController.h"

/**
 * Uses AI do determine the controls sequences to apply
 * Abstract, for future implementations
 *
 * @author ?
 */



#endif // AI_CONTROLLER_H_INCLUDED
