#ifndef SOUND_H_INCLUDED
#define SOUND_H_INCLUDED

/**
 * Referes to audio resources
 *
 * @author Gil Costa
 */

#include "AFileResolver.h"
#include "GameInvariants.h"
#include <SFML/audio.hpp>

// TODO: what is this class for?!
class Sound: public AFileResolver{
protected:
    sf::SoundBuffer* sound;

public:
    Sound():AFileResolver(GameInvariants::SOUND_VERSION){
        sound = new sf::SoundBuffer();
    }
    ~Sound(){
        // does nothing because of being a temporary class...
    }


    sf::SoundBuffer* getBufferedSound() const{
        return sound;
    }

    void readData(DataInputStream& dis) throw(IOException){
        Data soundData = dis.read(dis.readInt32());
        sound->LoadFromMemory(soundData.getData(),soundData.size());
        soundData.clean();
    }

};




#endif // SOUND_H_INCLUDED
