#ifndef GAMEINVARIANTS_H_INCLUDED
#define GAMEINVARIANTS_H_INCLUDED


#include "TypeUtils.h"


/**
 * All the fixed data for a specific game is here
 * This data may vary from game to game
 * TODO: read options from XML or something
 *       replace switch cases with if statemens if necessary
 *
 * @author Gil Costa
 */



namespace GameInvariants{

extern const char* MATRIX_IMG_EXTENSION;
extern const char* FRAMES_EXTENSION;
extern const char* GOODIES_EXTENSION;
extern const char* WEAPONS_EXTENSION;
extern const char* SOUND_EXTENSION;
extern const char* MUSIC_EXTENSION;
extern const char* CHARACTER_EXTENSION;
extern const char* PALLET_EXTENSION;
extern const char* LANGUAGE_EXTENSION;
extern const char* LAYERS_EXTENSION;
extern const char* SCENES_EXTENSION;



//-------------------------
// ---- File Versions ----
//-------------------------

extern const UByte MATRIX_IMG_VERSION;
extern const UByte FRAMES_VERSION;
extern const UByte GOODIES_VERSION;
extern const UByte WEAPONS_VERSION;
extern const UByte SOUND_VERSION;
extern const UByte MUSIC_VERSION;
extern const UByte CHARACTER_VERSION;
extern const UByte PALLET_VERSION;
extern const UByte LANGUAGE_VERSION;
extern const UByte LAYERS_VERSION;
extern const UByte SCENES_VERSION;


//-----------------------
// ---- Directories ----
//-----------------------

extern const char* ANIMATIONS_DIR;
extern const char* GOODIES_DIR;
extern const char* WEAPONS_DIR;
extern const char* AUDIO_DIR;
extern const char* CHARACTERS_DIR;
extern const char* PALLETS_DIR;
extern const char* LANGUAGE_DIR;
extern const char* LEVELS_DIR;


extern const char* UNDEFINED;



//----------------------
// ---- Game Flags ----
//----------------------

extern bool FACE_WHEN_HIT;
extern bool REALIST_FACE_HIT;


//---------------------------
// ---- Game properties ----
//---------------------------

extern UInt RANDOM_TB_SIZE;
extern UByte RANDOM_MAX_VAL;
extern UByte LIFE_BAR;
extern float VEL_DIVIDER;
extern float ROT_VEL_DIVIDER;
extern float VERTICAL_VEL_FACTOR;
extern float AIR_CONTROL;
extern float JUMP_X_IMPULSE_FACT;
extern float  ELASTICITY;

extern UByte RUN_TIME;
extern UByte ATTACK_TIME;
extern UByte KNOCK_TIME;

extern UByte GRAB_X_SPACE;
extern float GRAB_X_BACK_FACTOR;
extern UByte GRAB_Z_SPACE;
//extern const UByte SUPER_TIME;

extern float GRAVITY;
/** when is it considered to being in Z down */
extern float FALLING_LIMIAR;

/** flip attack can only be made between two frame limits */
extern float FLIP_ATTACK_MINIMUM;
extern float FLIP_ATTACK_MAXIMUM;
extern float JUMP_SPECIAL_MAX_SPEED;
//extern const float LOW_GRAVITY = -0.1f;

/** how many frames the character stops when hiting */
extern UByte HIT_PAUSE;
extern UByte KNOCK_PAUSE;
extern UByte GRAB_PAUSE;
extern UByte AFTER_ATTACK_PAUSE;
extern UByte ATTACK_WAIT_TOLERANCE;
/** time to ignore a hit in the same sircunstancies*/
extern UByte RECOVER_TIME;
extern UByte UNGRAB_TIME;

extern float GROUND_BOUNCE_VEL;
extern float KNOKED_X_VEL;
extern float KNOKED_Y_VEL;

extern float BLOCK_HIT_VEL;
extern UByte BLOCK_HIT_TIME;



//--------------------------------
// --- Scene and layers stuff ---
//--------------------------------

extern const int MAX_ANIMATIONS;
extern const int SCROLL_PIXELS;
extern const UByte H_SCROLL_LAYER_TYPE;
extern const UByte V_SCROLL_LAYER_TYPE;
extern const UByte MATRIX_LAYER_TYPE;
extern const int NULL_MATRIX_CELL;



//---------------------
// --- Audio stuff ---
//---------------------


extern const int NO_SOUND_INDEX;
extern const float SOUND_MIN_DISTANCE;
extern const float SOUND_ATTENUATION;
extern const float SOUND_LISTENER_DISTANCE;





//-------------------------------------------
// ---- Default object and action types ----
//-------------------------------------------

/** Action Types (hit, fire, etc) */
extern const int AT_KNOCK;
extern const int AT_ELECTROCUTION;
extern const int AT_BOMB;
extern const int AT_PEPPER;
extern const int AT_FIRE;
extern const int AT_BULLET;
extern const int AT_THROW;
extern const int AT_EFFECTS;



//--------------------------
// ---- SpecialEffects ----
//--------------------------

extern const int FX_SOUND;
extern const int FX_SMP_ANIM;




//----------------------------------------
// ---- Default Character Animations ----
//----------------------------------------

//______________________________
// --- involuntary stances ----

extern const UByte INTRODUCING;
extern const UByte INTRODUCING_END;
extern const UByte NORMAL;
extern const UByte WAITING;
extern const UByte CROUCHING_DOWN;
extern const UByte LYING;
extern const UByte STANDING_UP;

extern const UByte IN_AIR;
extern const UByte LAND;

extern const UByte BEING_GRABBED_FRONT;
extern const UByte BEING_GRABBED_BACK;
extern const UByte ATOMIC_FALLING;
extern const UByte BEING_HIT;
extern const UByte BEING_GRABBED_HIT_FRONT;
extern const UByte BEING_GRABBED_HIT_BACK;
extern const UByte BEING_KNOCKED;
extern const UByte BEING_THROWN;
extern const UByte SHOCK_IN_WALL_FRONT;
extern const UByte SHOCK_IN_WALL_BACK;
extern const UByte BEING_ELECTROCUTTED;
extern const UByte BEING_BURNED;


extern const UByte GRABBING_FRONT;
extern const UByte GRABBING_BACK;



//_______________________
// --- Action Moves ----

// normal moves:

extern const UByte WALK;
extern const UByte RUN;
extern const UByte PREPARE_JUMP;
extern const UByte STATIC_JUMP;
extern const UByte JUMP;
extern const UByte RUN_JUMP;
extern const UByte ROLL_UP;
extern const UByte ROLL_DOWN;

// if some not defined, the first one is used
extern const UByte ATTACK_1;
extern const UByte ATTACK_2;
extern const UByte ATTACK_3;
extern const UByte ATTACK_4;
extern const UByte ATTACK_5;

extern const UByte RUN_ATTACK_STAR_0;
extern const UByte RUN_ATTACK_STAR_1;
extern const UByte RUN_ATTACK_STAR_2;
extern const UByte RUN_ATTACK_STAR_3;

extern const UByte JUMP_STATIC_ATTACK;
extern const UByte JUMP_MOVE_ATTACK;
extern const UByte JUMP_RUN_ATTACK;
extern const UByte JUMP_DOWN_ATTACK;

extern const UByte DEFENCIVE_SPECIAL;
extern const UByte OFENCIVE_SPECIAL;
extern const UByte JUMP_SPECIAL;
extern const UByte BLOCK;

extern const UByte BACK_ATTACK;
extern const UByte KNOCK_ATTACK;

extern const UByte SUPPER;
extern const UByte HELP_CALL;

extern const UByte WEAPON_ATTACK;
extern const UByte WEAPON_THROW;


// grabbing moves:

// if some not defined, the first one is used
extern const UByte FRONT_GRAB_FRONT_ATTACK_1;
extern const UByte FRONT_GRAB_FRONT_ATTACK_2;
extern const UByte FRONT_GRAB_FRONT_ATTACK_3;
extern const UByte FRONT_GRAB_FRONT_ATTACK_4;
extern const UByte FRONT_GRAB_FRONT_ATTACK_5;

extern const UByte FRONT_GRAB_STATIC_ATTACK;
extern const UByte FRONT_GRAB_BACK_ATTACK;

extern const UByte BACK_GRAB_FRONT_ATTACK;
extern const UByte BACK_GRAB_STATIC_ATTACK;
extern const UByte BACK_GRAB_BACK_ATTACK;
extern const UByte GRAB_WALK;
extern const UByte GRAB_BACK_WALK;
extern const UByte GRAB_RUN;
extern const UByte GRAB_JUMP;

extern const UByte GRAB_RUN_ATTACK;
extern const UByte FRONT_GRAB_JUMP_ATTACK;
extern const UByte BACK_GRAB_JUMP_ATTACK;

extern const UByte FLIP_OVER;
extern const UByte FAILED_FLIP_OVER;
extern const UByte FLIP_OVER_ATTACK;

extern const UByte BEING_BACK_GRABBED_DEFENCE;
extern const UByte THROWS_WHOS_GRABBING;


// team moves:

extern const UByte TEAM_FLIP_OVER_ATTACK;
extern const UByte TEAM_FRONT_GRAB_STATIC_ATTACK;
extern const UByte TEAM_BACK_GRAB_STATIC_ATTACK;

// mixelaneous:
extern const UByte DYING;
extern const UByte GRABBING_UP;
extern const UByte FRONT_GRAB_JUMP_ATTACK_LAND;
extern const UByte BACK_GRAB_JUMP_ATTACK_LAND;

extern const UByte GROUND_BOUNCING;
extern const UByte SAFE_LANDING;



//----------------
// ---- KEYS ----
//----------------


extern const UByte NUM_KEYS;

namespace Key{
    enum key{
        UP,
        DOWN,
        LEFT,
        RIGHT,
        A,
        B,
        C,
        D,
        E,
        F,
        START,
        CALL
    //    PRESS_STATE;
    };
}
}






////----------------
//// ---- KEYS ----
////----------------
//
//
//
//
//enum key{
//    UP,
//    DOWN,
//    LEFT,
//    RIGHT,
//    A,
//    B,
//    C,
//    D,
//    E,
//    F,
//    START,
//    CALL
////    PRESS_STATE;
//};


//
//// TODO: move this out there?
//// Keys definition:
//namespace key{
//    extern const int UP;
//    extern const int DOWN;
//    extern const int LEFT;
//    extern const int RIGHT;
//    extern const int A;
//    extern const int B;
//    extern const int C;
//    extern const int D;
//    extern const int E;
//    extern const int F;
//    extern const int START;
//    extern const int CALL;
////    extern const int PRESS_STATE;
//}






//class GameInvariants {
//    public:
//        // TODO: some may become dinamic variables!
//
//        //---------------------------
//        // ---- File Extensions ----
//        //---------------------------
//
//        static const char* FRAMES_EXTENSION;
//        static const char* GOODIES_EXTENSION;
//        static const char* WEAPONS_EXTENSION;
//        static const char* SOUND_EXTENSION;
//        static const char* CHARACTER_EXTENSION;
//        static const char* PALLET_EXTENSION;
//        static const char* LANGUAGE_EXTENSION;
//
//
//
//        //-----------------------
//        // ---- Directories ----
//        //-----------------------
//
//        static const char* EDITORS_WORKING_DIR;
//
//        static const char* ANIMATIONS_DIR;
//        static const char* GOODIES_DIR;
//        static const char* WEAPONS_DIR;
//        static const char* AUDIO_DIR;
//        static const char* CHARACTERS_DIR;
//        static const char* PALLETS_DIR;
//        static const char* LANGUAGE_DIR;
//
//
//        static const char* UNDEFINED;   // TODO: what is this?
//
//
//
//        //---------------------------
//        // ---- Game properties ----
//        //---------------------------
//
//        static const UInt RANDOM_TB_SIZE;
//        static const UByte RANDOM_MAX_VAL;
//        static const UByte LIFE_BAR;
//        static const float VEL_DIVIDER;
//        static const float AIR_CONTROL;
//        static const float ELASTICITY;  // when bouncing against walls
//
//        static const UByte RUN_TIME;
//        static const float GRAVITY;
//        //static const float LOW_GRAVITY;
//
//        //--------------------------------
//        // ---- Default action types ----
//        //--------------------------------
//
//
//        /** Action Types (hit, fire, etc) */
//        static const UByte AT_KNOCK;
//        static const UByte AT_ELECTROCUTION;
//        static const UByte AT_BOMB;
//        static const UByte AT_PEPPER;
//        static const UByte AT_FIRE;
//        static const UByte AT_BULLET;
//        static const UByte AT_THROW;
//
//
//
//
//        //----------------------------------------
//        // ---- Default Character Animations ----
//        //----------------------------------------
//
//        //______________________________
//        // --- involuntary stances ----
//
//        static const UByte INTRODUCING;
//        static const UByte INTRODUCING_END;
//        static const UByte NORMAL;
//        static const UByte WAITING;
//        static const UByte CROUCHING_DOWN;
//        static const UByte LYING;
//        static const UByte STANDING_UP;
//
//        static const UByte IN_AIR;
//        static const UByte LAND;
//
//        static const UByte BEING_GRABBED_FRONT;
//        static const UByte BEING_GRABBED_BACK;
//
//        static const UByte BEING_HIT;
//        static const UByte BEING_GRABBED_HIT;
//        static const UByte BEING_KNOCKED;
//        static const UByte BEING_THROWN;
//        static const UByte SHOCK_IN_WALL_FRONT;
//        static const UByte SHOCK_IN_WALL_BACK;
//        static const UByte BEING_ELECTROCUTTED;
//        static const UByte BEING_BURNED;
//
//
//        static const UByte GRABBING_FRONT;
//        static const UByte GRABBING_BACK;
//
//
//
//        //_______________________
//        // --- Action Moves ----
//
//        // normal moves:
//
//        static const UByte WALK;
//        static const UByte RUN;
//        static const UByte JUMP;
//        static const UByte RUN_JUMP;
//        static const UByte ROLL_UP;
//        static const UByte ROLL_DOWN;
//
//        // if some not defined, the first one is used
//        static const UByte ATTACK_1;
//        static const UByte ATTACK_2;
//        static const UByte ATTACK_3;
//        static const UByte ATTACK_4;
//        static const UByte ATTACK_5;
//
//        static const UByte RUN_ATTACK_STAR_0;
//        static const UByte RUN_ATTACK_STAR_1;
//        static const UByte RUN_ATTACK_STAR_2;
//        static const UByte RUN_ATTACK_STAR_3;
//
//        static const UByte JUMP_STATIC_ATTACK;
//        static const UByte JUMP_MOVE_ATTACK;
//        static const UByte JUMP_RUN_ATTACK;
//        static const UByte JUMP_DOWN_ATTACK;
//
//        static const UByte DEFENCIVE_SPECIAL;
//        static const UByte OFENCIVE_SPECIAL;
//        static const UByte BLOCK;
//
//        static const UByte BACK_ATTACK;
//        static const UByte KNOCK_ATTACK;
//
//        static const UByte SUPPER;
//        static const UByte HELP_CALL;
//
//        static const UByte WEAPON_ATTACK;
//        static const UByte WEAPON_THROW;
//
//
//        // grabbing moves:
//
//        // if some not defined, the first one is used
//        static const UByte FRONT_GRAB_FRONT_ATTACK_1;
//        static const UByte FRONT_GRAB_FRONT_ATTACK_2;
//        static const UByte FRONT_GRAB_FRONT_ATTACK_3;
//        static const UByte FRONT_GRAB_FRONT_ATTACK_4;
//        static const UByte FRONT_GRAB_FRONT_ATTACK_5;
//
//        static const UByte FRONT_GRAB_STATIC_ATTACK;
//        static const UByte FRONT_GRAB_BACK_ATTACK;
//
//        static const UByte BACK_GRAB_FRONT_ATTACK;
//        static const UByte BACK_GRAB_STATIC_ATTACK;
//        static const UByte BACK_GRAB_BACK_ATTACK;
//
//        static const UByte GRAB_WALK;
//        static const UByte GRAB_RUN;
//        static const UByte GRAB_JUMP;
//
//        static const UByte GRAB_RUN_ATTACK;
//        static const UByte FRONT_GRAB_JUMP_ATTACK;
//        static const UByte BACK_GRAB_JUMP_ATTACK;
//
//        static const UByte FLIP_OVER;
//        static const UByte FAILED_FLIP_OVER;
//        static const UByte FLIP_OVER_ATTACK;
//
//        static const UByte BEING_BACK_GRABBED_DEFENCE;
//        static const UByte THROWS_WHOS_GRABBING;
//
//
//        // team moves:
//
//        static const UByte TEAM_FLIP_OVER_ATTACK;
//
//        static const UByte TEAM_FRONT_GRAB_STATIC_ATTACK;
//        static const UByte TEAM_BACK_GRAB_STATIC_ATTACK;
//
//
//
//
//};
//

#endif // GAMEINVARIANTS_H_INCLUDED
