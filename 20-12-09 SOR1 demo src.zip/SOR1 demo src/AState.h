#ifndef ASTATE_H_INCLUDED
#define ASTATE_H_INCLUDED

/**
 * Interface for generic state
 * all active objects must have a state notion
 * all the states must allow a deterministic reproduction
 * of the entire global game state
 *
 * @author Gil Costa
 */
class AState{
//    /** default constructor */
//    AState();
//    /** copy constructor */
//    AState(const AState& other);
};

#endif // ASTATE_H_INCLUDED
