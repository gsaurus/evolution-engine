#ifndef SMP_ANIM_EFFECT_H_INCLUDED
#define SMP_ANIM_EFFECT_H_INCLUDED

#include "AEffect.h"
#include "AObject.h"
#include "SimpleAnimation.h"
#include "SoundEffectHeader.h"

class SmpAnimEffect: public AEffect, public AObject{
 private:
    const SimpleAnimation* anim;
    sf::Vector3f pos;
    UInt time;
    UInt currFrame;

    void createView();
    void removeView();

 public:
    SmpAnimEffect(const SimpleAnimation* anim, float x, float y, float z);
    SmpAnimEffect(const SimpleAnimation* anim);
    ~SmpAnimEffect();

    void setPosition(float x, float y, float z);

    bool update();

    float getX() const;
    float getY() const;
    float getZ() const;

    void updateSprite(sf::Sprite& sprite);
};

#endif // SOUND_EFFECT_H_INCLUDED
