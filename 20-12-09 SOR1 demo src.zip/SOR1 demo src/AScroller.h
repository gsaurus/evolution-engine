#ifndef A_SCROLLER_H_INCLUDED
#define A_SCROLLER_H_INCLUDED

#include "ADisplayable.h"
#include "Layer.h"

class Layer;

/**
 * Abstract class for Scroller types
 * Possible scrollers: FreeScroller, RelativeScroller (relative to other scroller)
 *
 * @author Gil Costa
 */
class AScroller: public ADisplayable{
    protected:
        const Layer* layer;

    public:
        AScroller(Layer* layer):layer(layer){}
        virtual ~AScroller(){};
};

#endif // A_SCROLLER_H_INCLUDED
