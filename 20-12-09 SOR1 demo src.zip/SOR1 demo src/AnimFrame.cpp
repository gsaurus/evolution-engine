#include "AnimFrame.h"




//--------------------
// -- CONSTRUCTORS --
//--------------------

AnimFrame::AnimFrame():
    frameIndex(0),duration(8)
{}

AnimFrame::~AnimFrame(){

}

//---------------
// -- METHODS --
//---------------

void AnimFrame::readData(DataInputStream& dis) throw(IOException){
    frameIndex = dis.readInt16();
    duration = dis.readByte();
}

//void writeData(DataOutputStream& dos){ //throws IOException {
//    dos.writeShort(frameIndex);
//    duration.writeData(dos);
//}
