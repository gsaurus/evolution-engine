#include "SoundEffect.h"
#include "GameInvariants.h"
#include "AudioManager.h"

SoundEffect::SoundEffect(int soundIndex, float x, float y, float z, float minDistance, float attenuation, float pitch){
    data.soundIndex = soundIndex;
    data.position.x = x;
    data.position.y = y;
    data.position.z = z;
    data.minDistance = minDistance;
    data.attenuation = attenuation;
    data.pitch = pitch;
    playingSound = GameInvariants::NO_SOUND_INDEX; // TODO: what is this for ?
    start();
}


SoundEffect::SoundEffect(int soundIndex){
    data.soundIndex = soundIndex;
    playingSound = GameInvariants::NO_SOUND_INDEX;
}

SoundEffect::~SoundEffect(){
    // stop and remove sound
    AudioManager::stopSound(playingSound);
}


void SoundEffect::setPosition(float x, float y, float z){
    data.position.x = x;
    data.position.y = y;
    data.position.z = z;
    if (playingSound != GameInvariants::NO_SOUND_INDEX)
        AudioManager::setPosition(playingSound, x, y, z);
}
void SoundEffect::setAttenuation(float minDistance, float attenuation){
    data.minDistance = minDistance;
    data.attenuation = attenuation;
    if (playingSound != GameInvariants::NO_SOUND_INDEX)
        AudioManager::setAttenuation(playingSound, minDistance, attenuation);
}
void SoundEffect::setPitch(float pitch){
    data.pitch = pitch;
    if (playingSound != GameInvariants::NO_SOUND_INDEX)
        AudioManager::setPitch(playingSound, pitch);
}


void SoundEffect::start(){
    // play the sound
    playingSound = AudioManager::playSound(
            data.soundIndex, data.position.x, data.position.y, data.position.z,
            data.minDistance, data.attenuation, data.pitch
        );
//    AudioManager::setVolume(playingSound);
}

bool SoundEffect::update(){
    return AudioManager::isPlaying(playingSound);
}


int SoundEffect::getPlayingSoundKey() const{
    return playingSound;
}
