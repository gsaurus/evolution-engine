#ifndef ADISPLAYABLE_H_INCLUDED
#define ADISPLAYABLE_H_INCLUDED

#include <SFML/Graphics.hpp>

/**
 * Interface for displayable objects
 * (objects that can be drawn on a RenderTarget)
 *
 * @author Gil Costa
 */
class ADisplayable{
    public:
        virtual ~ADisplayable(){}
        /** display on a target */
        virtual void display(sf::RenderTarget* target) = 0;
};

#endif // ADISPLAYABLE_H_INCLUDED
