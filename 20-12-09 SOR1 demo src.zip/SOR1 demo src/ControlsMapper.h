#ifndef CONTROLS_MAPPER_H_INCLUDED
#define CONTROLS_MAPPER_H_INCLUDED

#include "AControlledEntity.h"
#include "AController.h"

/**
 * Controls the gameplay
 *    - controllers of entities
 *    - ...
 *
 * @author Gil Costa
 */
class ControlsMapper{
    public:
        // TODO: ??
        static AController* getController(AControlledEntity* entity, int ctrlKey);
};


#endif // CONTROLS_MAPPER_H_INCLUDED
