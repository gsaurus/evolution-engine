#ifndef HITINFO_H_INCLUDED
#define HITINFO_H_INCLUDED

#include "HitFrame.h"
#include "AEntityState.h"
#include "TypeUtils.h"


/**
 * Information about a hit
 *   - the data frame that has all info about the hit
 *   - who/what did the hit
 *   - in witch direction the hit comes
 *
 * @author Gil Costa
 */
class HitInfo{
    public:
        const HitFrame* hits;
        const AEntityState* hitterState;
        bool fromLeft;

        HitInfo(){}
        HitInfo(const HitFrame* hits, const AEntityState* hitterState, bool fromLeft = false):
            hits(hits),hitterState(hitterState), fromLeft(fromLeft)
        {}
};

#endif // HITINFO_H_INCLUDED
