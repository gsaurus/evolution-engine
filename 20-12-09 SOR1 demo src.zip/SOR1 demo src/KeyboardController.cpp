#include "KeyboardController.h"

#include "OSInput.h"
#include "GameInvariants.h"

#include <iostream>

//#include <iostream> //TODO: remove this

KeyboardController::KeyboardController():AController(){}
KeyboardController::KeyboardController(AControlledEntity* entity):AController(entity){}


void KeyboardController::setKeys(const sf::Key::Code up, sf::Key::Code down, sf::Key::Code left, sf::Key::Code right,
        sf::Key::Code a, sf::Key::Code b, sf::Key::Code c, sf::Key::Code d, sf::Key::Code e, sf::Key::Code f,
        sf::Key::Code start, sf::Key::Code call){
    keyMapper.insert(std::pair<sf::Key::Code,UInt>(up, GameInvariants::Key::UP));
    keyMapper.insert(std::pair<sf::Key::Code,UInt>(down, GameInvariants::Key::DOWN));
    keyMapper.insert(std::pair<sf::Key::Code,UInt>(left, GameInvariants::Key::LEFT));
    keyMapper.insert(std::pair<sf::Key::Code,UInt>(right, GameInvariants::Key::RIGHT));
    keyMapper.insert(std::pair<sf::Key::Code,UInt>(a, GameInvariants::Key::A));
    keyMapper.insert(std::pair<sf::Key::Code,UInt>(b, GameInvariants::Key::B));
    keyMapper.insert(std::pair<sf::Key::Code,UInt>(c, GameInvariants::Key::C));
    keyMapper.insert(std::pair<sf::Key::Code,UInt>(d, GameInvariants::Key::D));
    keyMapper.insert(std::pair<sf::Key::Code,UInt>(e, GameInvariants::Key::E));
    keyMapper.insert(std::pair<sf::Key::Code,UInt>(f, GameInvariants::Key::F));
    keyMapper.insert(std::pair<sf::Key::Code,UInt>(start, GameInvariants::Key::START));
    keyMapper.insert(std::pair<sf::Key::Code,UInt>(call, GameInvariants::Key::CALL));
}

void KeyboardController::setKey(sf::Key::Code key, UInt val){
    keyMapper.insert(std::pair<sf::Key::Code,UInt>(key, val));
}

void KeyboardController::applyKeys(){
    // search for mapping keys, extract them
    std::list<OSInput::KeyBut>::iterator it;
    std::list<std::list<OSInput::KeyBut>::iterator> toRemove;
    for(it = OSInput::keyButsBegin(); it!=OSInput::keyButsEnd(); ++it){
        std::map<sf::Key::Code,UInt>::const_iterator entry;
        entry = keyMapper.find(it->code);
        //std::cout << "let's see: " << it->code << "\n";
        if (entry != keyMapper.end()){
            KeyEntry wkey;
            wkey.key = entry->second;
            wkey.pressed = it->pressed;
            waitingKeys.push_back(wkey);
            toRemove.push_back(it);
        }
    }

    // remove the extracted keys
    std::list<std::list<OSInput::KeyBut>::iterator>::iterator rit;
    for(rit = toRemove.begin(); rit != toRemove.end() ; ++rit)
        OSInput::removeKeyBut(*rit);

    // do as on superclass
    AController::applyKeys();
}
