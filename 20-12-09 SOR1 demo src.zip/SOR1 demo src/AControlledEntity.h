#ifndef ACONTROLLED_ENTITY_H_INCLUDED
#define ACONTROLLED_ENTITY_H_INCLUDED


#include "AEntity.h"



/**
 * Specifies how the entity is controlled
 *
 * @author Gil Costa
 */
class AControlledEntity: public AEntity{
    public:

        // --------------------
        //  -- CONSTRUCTORS --
        // --------------------

        /** Destructor */
        virtual ~AControlledEntity();



        // ---------------
        //  -- METHODS --
        // ---------------
        // Interface for receive keys

        /**
         * Key control
         * specifies what to do when receiving a key signal
         */
        virtual bool takeKey(int k, bool pressed)=0;


        // --------------------------------------------------
        // Several usual tests related to controlled sprites
        virtual void testHit(AEntity* otherSprite);
        virtual void testThrow();
};

#endif // ACONTROLLED_ENTITY_H_INCLUDED

