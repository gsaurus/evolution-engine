#ifndef TYPESUTIL_H_INCLUDED
#define TYPESUTIL_H_INCLUDED

#include <map>
#include <string>
#include <sstream>
#include <math.h>


/**
 * util defenitions and methods over data types
 *
 * @author Gil Costa
 */

typedef signed char Byte;
typedef unsigned char UByte;
typedef unsigned int UInt;

// to string method for any object that defines '<<' operator
template <typename T>
void toString(const T& object, std::string & s){
    std::ostringstream os;
    os << object;
    s = os.str();
}



float toRadians (float d);
float toDegrees (float r);

void rotate(float& x, float& y, float angle);

double angleBetween(float x1, float y1, float x2, float y2);

#endif // TYPESUTIL_H_INCLUDED
