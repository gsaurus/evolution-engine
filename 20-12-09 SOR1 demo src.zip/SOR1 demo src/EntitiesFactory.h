#ifndef ENTITIESFACTORY_H_INCLUDED
#define ENTITIESFACTORY_H_INCLUDED

/**
 * Creates instances of entities from the headers in the database
 *
 * @author Gil Costa
 */
class EntitiesFactory{
    // TODO: some way to store EntityHeaders,
    // probably separated as sets of enemies, players, goodies, etc
};

#endif // ENTITIESFACTORY_H_INCLUDED
