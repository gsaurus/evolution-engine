#include "AITrivialFighter.h"

#include "OSInput.h"
#include "GameInvariants.h"
#include "CharState.h"

#include <SFML/System.hpp>

#include <iostream>

#include "Layer.h"
#include "Scene.h"

//#include <iostream> //TODO: remove this

AITrivialFighter::AITrivialFighter():AITrivialController(){}
AITrivialFighter::AITrivialFighter(AControlledEntity* entity):AITrivialController(entity){}


void AITrivialFighter::applyKeys(){

    if (Scene::currentScene->sceneState >= 20){
        copSuffer();
        AController::applyKeys();
        return;
    }

    AControlledEntity* tgEntity = 0;
    if (Scene::getCurrLayerId() != 4){
        if (Layer::getCurrentLayer()->controllers.players[0] != 0)
            tgEntity = Layer::getCurrentLayer()->controllers.players[0]->getEntity();
    }

    CharState* state = (CharState*)entity->getState();


    bool movingLeft = state->movingLeft;
    bool movingRight = state->movingRight;
    bool movingUp = state->movingUp;
    bool movingDown = state->movingDown;


    if (state->grabbedOne != 0 && state->grabbedOne != tgEntity ){
        stop();
        KeyEntry wkey;
        if (state->facedLeft)
            wkey.key = GameInvariants::Key::RIGHT;
        else wkey.key = GameInvariants::Key::LEFT;
        wkey.pressed = true;
        waitingKeys.push_back(wkey);
    }

    if ( tgEntity != 0 && (state->isFacedLeft() && tgEntity->getX() < state->getX() || !state->isFacedLeft() && tgEntity->getX() > state->getX()) &&
        Scene::getCurrLayerId() != 4 && !((CharEntity*)tgEntity)->isInvincibleAnimPlaying() &&
        (state->attackCounter == 0 && sf::Randomizer::Random(0, 10)==0 || state->attackCounter != 0 && sf::Randomizer::Random(0, 15)==0) &&
        (
            (state->getX()> tgEntity->getX()+15 && state->getX()< tgEntity->getX()+70 && state->isFacedLeft())
            || (state->getX()> tgEntity->getX()-70 && state->getX()< tgEntity->getX()-15 && !state->isFacedLeft())
        )
        && state->getZ()> tgEntity->getZ() - GameInvariants::GRAB_Z_SPACE && state->getZ()< tgEntity->getZ() + GameInvariants::GRAB_Z_SPACE
        && tgEntity->getY()==0
    ){
        KeyEntry wkey;
        wkey.key = GameInvariants::Key::B;
        wkey.pressed = true;
        waitingKeys.push_back(wkey);
        wkey.key = GameInvariants::Key::B;
        wkey.pressed = false;
        waitingKeys.push_back(wkey);
        TX = -1;
        TZ = -1;
        stop();
    }


    if ( tgEntity != 0 && !((
        (state->getX()> tgEntity->getX()+15 && state->isFacedLeft())
        || (state->getX()< tgEntity->getX()-15 && !state->isFacedLeft())
        )
        && state->getZ()> tgEntity->getZ() - GameInvariants::GRAB_Z_SPACE && state->getZ()< tgEntity->getZ() + GameInvariants::GRAB_Z_SPACE)
    ){

        if (TX == -1 && TZ == -1 && Scene::getCurrLayerId() != 4){
            if (sf::Randomizer::Random(0, 20)==0){
                if (tgEntity->getX() < state->getX())
                    TX = (int)(tgEntity->getX()+32 + sf::Randomizer::Random(0, 50));
                else
                    TX = (int)(tgEntity->getX()-32 - sf::Randomizer::Random(0, 50));
                TZ = (int)(tgEntity->getZ());
            }else{ AController::applyKeys(); return; }
        }
    }



    if (sf::Randomizer::Random(0, 40)==0){
        TX = sf::Randomizer::Random((int)(tgEntity->getX()-200), (int)(tgEntity->getX()+200));
        TZ = sf::Randomizer::Random(160, 224);
    }


    if (TX != -1 && TZ != -1){
        if (TZ < 160) TZ = 160;

        if (state->getX()-5>TX){
            if (!movingLeft){
                KeyEntry wkey;
                wkey.key = GameInvariants::Key::RIGHT;
                wkey.pressed = false;
                waitingKeys.push_back(wkey);
                wkey.key = GameInvariants::Key::LEFT;
                wkey.pressed = true;
                waitingKeys.push_back(wkey);
                if (sf::Randomizer::Random(0, 3)==0){
                    wkey.key = GameInvariants::Key::LEFT;
                    wkey.pressed = false;
                    waitingKeys.push_back(wkey);
                    wkey.key = GameInvariants::Key::LEFT;
                    wkey.pressed = true;
                    waitingKeys.push_back(wkey);
                }
            }
        }else if (state->getX()+5<TX){
            if (!movingRight){
                KeyEntry wkey;
                wkey.key = GameInvariants::Key::LEFT;
                wkey.pressed = false;
                waitingKeys.push_back(wkey);
                wkey.key = GameInvariants::Key::RIGHT;
                wkey.pressed = true;
                waitingKeys.push_back(wkey);
                if (sf::Randomizer::Random(0, 3)==0){
                    wkey.key = GameInvariants::Key::RIGHT;
                    wkey.pressed = false;
                    waitingKeys.push_back(wkey);
                    wkey.key = GameInvariants::Key::RIGHT;
                    wkey.pressed = true;
                    waitingKeys.push_back(wkey);
                }
            }
        }else{
            if (movingLeft){
                KeyEntry wkey;
                wkey.key = GameInvariants::Key::LEFT;
                wkey.pressed = false;
                waitingKeys.push_back(wkey);
            }
            if (movingRight){
                KeyEntry wkey;
                wkey.key = GameInvariants::Key::RIGHT;
                wkey.pressed = false;
                waitingKeys.push_back(wkey);
            }
        }



//        if (!movingOut && !movingIn){
            if (state->isFacedLeft() && sf::Randomizer::Random(0, 150)==0){
                KeyEntry wkey;
                wkey.pressed = false;
                waitingKeys.push_back(wkey);
                wkey.key = GameInvariants::Key::LEFT;
                wkey.pressed = true;
                wkey.key = GameInvariants::Key::LEFT;
                wkey.pressed = false;
                waitingKeys.push_back(wkey);
                wkey.key = GameInvariants::Key::LEFT;
                wkey.pressed = true;
                waitingKeys.push_back(wkey);
            }
            else if (!state->isFacedLeft() && sf::Randomizer::Random(0, 150)==0){
                KeyEntry wkey;
                wkey.pressed = false;
                waitingKeys.push_back(wkey);
                wkey.key = GameInvariants::Key::RIGHT;
                wkey.pressed = true;
                wkey.key = GameInvariants::Key::RIGHT;
                wkey.pressed = false;
                waitingKeys.push_back(wkey);
                wkey.key = GameInvariants::Key::RIGHT;
                wkey.pressed = true;
                waitingKeys.push_back(wkey);
            }
//        }


        if (state->getZ()-2>TZ){
            if (Scene::getCurrLayerId() == 4 && state->getZ()<160){
                stop();
                TZ = 161;
            }
            if (!movingUp){
                KeyEntry wkey;
                wkey.key = GameInvariants::Key::DOWN;
                wkey.pressed = false;
                waitingKeys.push_back(wkey);
                wkey.key = GameInvariants::Key::UP;
                wkey.pressed = true;
                waitingKeys.push_back(wkey);
            }
        }else if (state->getZ()+2<TZ){
            if (!movingDown){
                KeyEntry wkey;
                wkey.key = GameInvariants::Key::UP;
                wkey.pressed = false;
                waitingKeys.push_back(wkey);
                wkey.key = GameInvariants::Key::DOWN;
                wkey.pressed = true;
                waitingKeys.push_back(wkey);
            }
        }else{
            KeyEntry wkey;
            wkey.key = GameInvariants::Key::UP;
            wkey.pressed = false;
            waitingKeys.push_back(wkey);
            wkey.key = GameInvariants::Key::DOWN;
            wkey.pressed = false;
            waitingKeys.push_back(wkey);
        }

        if (state->getX()-5<=TX && state->getX()+5>=TX && state->getZ()-2<=TZ && state->getZ()+2>=TZ){
            stop();
        }
    } else{
        KeyEntry wkey;
        if (entity->getX() < tgEntity->getX()){
            wkey.key = GameInvariants::Key::RIGHT;
            wkey.pressed = true;
            waitingKeys.push_back(wkey);
        }
        else{
            wkey.key = GameInvariants::Key::LEFT;
            wkey.pressed = true;
            waitingKeys.push_back(wkey);
        }
        stop();
    }

    if (state->getZ()<160){
        stop();
    }

    // do as on superclass
    AController::applyKeys();
}


