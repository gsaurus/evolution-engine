#include "AEntityState.h"


// --------------------
//  -- Constructors --
// --------------------

AEntityState::AEntityState():
    active(false), waitingRemoval(false),pos(0,0,0)
{
    // Do nothing
}

AEntityState::AEntityState(const AEntityState* other):
//    id(other->id),
    active(other->active),
    waitingRemoval(other->waitingRemoval),
    pos(other->pos)
{
    // Do nothing
}

AEntityState::~AEntityState(){
    // Do nothing
}

// -----------------
//  --- GETTERS ---
// -----------------

bool AEntityState::isFacedLeft() const{
    return false;
}

bool AEntityState::isActive() const{ return active; }
bool AEntityState::isWaitingRemoval() const{ return waitingRemoval; }
//const sf::Vector3f& AEntityState::getPos() const{ return pos; }
float AEntityState::getX() const{ return pos.x; }
float AEntityState::getY() const{ return pos.y; }
float AEntityState::getZ() const{ return pos.z; }
