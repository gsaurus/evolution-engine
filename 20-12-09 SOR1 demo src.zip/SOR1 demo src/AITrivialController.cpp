#include "AITrivialController.h"

#include "OSInput.h"
#include "GameInvariants.h"
#include "CharState.h"

#include <SFML/System.hpp>


#include "Layer.h"
#include "Scene.h"

#include <iostream>

//#include <iostream> //TODO: remove this

AITrivialController::AITrivialController():AController(), TX(-1),TZ(-1),flag(false){}
AITrivialController::AITrivialController(AControlledEntity* entity):AController(entity), TX(-1),TZ(-1),flag(false){}


void AITrivialController::applyKeys(){

//    AControlledEntity* tgEntity = 0;
//    if (Scene::getCurrLayerId() != 4){
//        if (Layer::getCurrentLayer()->controllers.players[0] != 0)
//            tgEntity = Layer::getCurrentLayer()->controllers.players[0]->getEntity();
//    }
//
//    CharState* state = (CharState*)entity->getState();
//
//
//    bool movingLeft = state->movingLeft;
//    bool movingRight = state->movingRight;
//    bool movingUp = state->movingUp;
//    bool movingDown = state->movingDown;
//
////    if (state->getX()>4000){
////        std::cout << Scene::trainStopped << "!! " << trigger << movingIn << movingOut << ",  "<< state->getX() << "\n";
////    }
//
//    if (Scene::trainStopped && !trigger){
//        if (Scene::getCurrLayerId() == 4){
//            stop();
//            trigger = movingOut = true;
//        } else if (Scene::getCurrLayerId() == 6){
//            stop();
//            trigger = movingIn = true;
//        }
//    }
//
//    if (trigger){
//        if (movingOut)
//            moveOut();
//        else if (movingIn)
//            moveIn();
//    }
//
//
//
//    if (TX == -1 && TZ == -1 && Scene::getCurrLayerId() != 4 && !movingOut && !movingIn){
//        if (sf::Randomizer::Random(0, 30)==0){
//
//            if (Scene::getCurrLayerId() == 6){
//                TZ = sf::Randomizer::Random(165, 224);
//                TX = sf::Randomizer::Random(200, 1440-100);
//            }else{
//                TZ = sf::Randomizer::Random(230, 275);
//                TX = sf::Randomizer::Random(50, 1440/2-100);
//            }
//        }else{ AController::applyKeys(); return; }
//    }
//
//
//    if ( tgEntity != 0 && !movingIn && !movingOut && Scene::getCurrLayerId() != 4 &&
//        (state->attackCounter == 0 && sf::Randomizer::Random(0, 30)==0 || state->attackCounter == 0 && sf::Randomizer::Random(0, 15)==0) &&
//        (
//            (state->getX()> tgEntity->getX()+15 && state->getX()< tgEntity->getX()+70 && state->isFacedLeft())
//            || (state->getX()> tgEntity->getX()-70 && state->getX()< tgEntity->getX()-15 && !state->isFacedLeft())
//        )
//        && state->getZ()> tgEntity->getZ() - GameInvariants::GRAB_Z_SPACE && state->getZ()< tgEntity->getZ() + GameInvariants::GRAB_Z_SPACE
//    ){
//        KeyEntry wkey;
//        wkey.key = GameInvariants::Key::B;
//        wkey.pressed = true;
//        waitingKeys.push_back(wkey);
//        wkey.key = GameInvariants::Key::B;
//        wkey.pressed = false;
//        waitingKeys.push_back(wkey);
//        TX = -1;
//        TZ = -1;
//        stop();
//    }
//
//
//    if (TX != -1 && TZ != -1){
//
//        if (state->getX()-5>TX){
//            if (!movingLeft){
//                KeyEntry wkey;
//                wkey.key = GameInvariants::Key::RIGHT;
//                wkey.pressed = false;
//                waitingKeys.push_back(wkey);
//                wkey.key = GameInvariants::Key::LEFT;
//                wkey.pressed = true;
//                waitingKeys.push_back(wkey);
//                if (sf::Randomizer::Random(0, 2)==0){
//                    wkey.key = GameInvariants::Key::LEFT;
//                    wkey.pressed = false;
//                    waitingKeys.push_back(wkey);
//                    wkey.key = GameInvariants::Key::LEFT;
//                    wkey.pressed = true;
//                    waitingKeys.push_back(wkey);
//                }
//            }
//        }else if (state->getX()+5<TX){
//            if (!movingRight){
//                KeyEntry wkey;
//                wkey.key = GameInvariants::Key::LEFT;
//                wkey.pressed = false;
//                waitingKeys.push_back(wkey);
//                wkey.key = GameInvariants::Key::RIGHT;
//                wkey.pressed = true;
//                waitingKeys.push_back(wkey);
//                if (sf::Randomizer::Random(0, 2)==0){
//                    wkey.key = GameInvariants::Key::RIGHT;
//                    wkey.pressed = false;
//                    waitingKeys.push_back(wkey);
//                    wkey.key = GameInvariants::Key::RIGHT;
//                    wkey.pressed = true;
//                    waitingKeys.push_back(wkey);
//                }
//            }
//        }else{
//            if (movingLeft){
//                KeyEntry wkey;
//                wkey.key = GameInvariants::Key::LEFT;
//                wkey.pressed = false;
//                waitingKeys.push_back(wkey);
//            }
//            if (movingRight){
//                KeyEntry wkey;
//                wkey.key = GameInvariants::Key::RIGHT;
//                wkey.pressed = false;
//                waitingKeys.push_back(wkey);
//            }
//        }
//
//
//
//        if (!movingOut && !movingIn){
//            if (state->isFacedLeft() && sf::Randomizer::Random(0, 150)==0){
//                KeyEntry wkey;
//                wkey.pressed = false;
//                waitingKeys.push_back(wkey);
//                wkey.key = GameInvariants::Key::LEFT;
//                wkey.pressed = true;
//                wkey.key = GameInvariants::Key::LEFT;
//                wkey.pressed = false;
//                waitingKeys.push_back(wkey);
//                wkey.key = GameInvariants::Key::LEFT;
//                wkey.pressed = true;
//                waitingKeys.push_back(wkey);
//            }
//            else if (!state->isFacedLeft() && sf::Randomizer::Random(0, 150)==0){
//                KeyEntry wkey;
//                wkey.pressed = false;
//                waitingKeys.push_back(wkey);
//                wkey.key = GameInvariants::Key::RIGHT;
//                wkey.pressed = true;
//                wkey.key = GameInvariants::Key::RIGHT;
//                wkey.pressed = false;
//                waitingKeys.push_back(wkey);
//                wkey.key = GameInvariants::Key::RIGHT;
//                wkey.pressed = true;
//                waitingKeys.push_back(wkey);
//            }
//        }
//
//
//        if (state->getZ()-2>TZ){
//            if (Scene::getCurrLayerId() == 4 && state->getZ()<160){
//                stop();
//                TZ = 161;
//            }
//            if (!movingUp){
//                KeyEntry wkey;
//                wkey.key = GameInvariants::Key::DOWN;
//                wkey.pressed = false;
//                waitingKeys.push_back(wkey);
//                wkey.key = GameInvariants::Key::UP;
//                wkey.pressed = true;
//                waitingKeys.push_back(wkey);
//            }
//        }else if (state->getZ()+2<TZ){
//            if (!movingDown){
//                KeyEntry wkey;
//                wkey.key = GameInvariants::Key::UP;
//                wkey.pressed = false;
//                waitingKeys.push_back(wkey);
//                wkey.key = GameInvariants::Key::DOWN;
//                wkey.pressed = true;
//                waitingKeys.push_back(wkey);
//            }
//        }else{
//            KeyEntry wkey;
//            wkey.key = GameInvariants::Key::UP;
//            wkey.pressed = false;
//            waitingKeys.push_back(wkey);
//            wkey.key = GameInvariants::Key::DOWN;
//            wkey.pressed = false;
//            waitingKeys.push_back(wkey);
//        }
//
//        if (state->getX()-5<=TX && state->getX()+5>=TX && state->getZ()-2<=TZ && state->getZ()+2>=TZ){
//            stop();
//        }
//    } else{ stop(); }
//
//    if (!movingOut && Scene::getCurrLayerId() == 4 && state->getZ()<160){
//        stop();
//    }

    // do as on superclass
    AController::applyKeys();
}




void AITrivialController::stop(){
    TX = -1; TZ = -1;
    KeyEntry wkey;
    wkey.key = GameInvariants::Key::UP;
    wkey.pressed = false;
    waitingKeys.push_back(wkey);
    wkey.key = GameInvariants::Key::DOWN;
    wkey.pressed = false;
    waitingKeys.push_back(wkey);
    wkey.key = GameInvariants::Key::LEFT;
    wkey.pressed = false;
    waitingKeys.push_back(wkey);
    wkey.key = GameInvariants::Key::RIGHT;
    wkey.pressed = false;
    waitingKeys.push_back(wkey);
}


void AITrivialController::copSuffer(){
    CharState* state = (CharState*)entity->getState();
    if (state->currAnimIndex == GameInvariants::DYING || state->currAnimIndex == GameInvariants::BEING_KNOCKED || state->currAnimIndex == GameInvariants::GROUND_BOUNCING) return;

    if (!flag || state->currAnimIndex <100){
        state->pos.y = 0;
        state->facedLeft = sf::Randomizer::Random(0,1);
        ((CharEntity*)entity)->setAnimation(111+sf::Randomizer::Random(0,1) );
        flag = true;
    }
    if (Scene::getClocks()%30 == 0){
        ((CharEntity*)entity)->setAnimation(((CharEntity*)entity)->getCurrentAnimIndex());
        stop();
        KeyEntry wkey;
        if (state->facedLeft){
            wkey.key = GameInvariants::Key::RIGHT;
        }else wkey.key = GameInvariants::Key::LEFT;
        wkey.pressed = true;
        waitingKeys.push_back(wkey);
    }

}
