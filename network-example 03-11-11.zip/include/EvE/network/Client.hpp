////////////////////////////////////////////////////////////
//
// EvE - Evolution Engine
// Copyright (C) 2011 Gil Costa (gsaurus@gmail.com)
//
// TODO: License here
//
////////////////////////////////////////////////////////////

#ifndef EVE_CLIENT_HPP
#define EVE_CLIENT_HPP

////////////////////////////////////////////////////////////
// Headers
////////////////////////////////////////////////////////////
#include <EvE/Config.hpp>
#include <string>

namespace eve{

//forward declarations
class ClientListener;

////////////////////////////////////////////////////////////
/// \brief Manages providers.
///
////////////////////////////////////////////////////////////
class EVE_API Client{

public:

    ////////////////////////////////////////////////////////////
    /// \brief
    ///
    ////////////////////////////////////////////////////////////
    static Client* create(ClientListener& listener);

    virtual ~Client();

    bool connectionRequest(
            const std::string& ip,
            unsigned int port,
            unsigned int packetTime
    );

    void disconnect();

    bool isRunning() const;

    bool isConnected() const;

    virtual void send(const char* data, std::size_t size, bool priority = true) = 0;

    virtual unsigned int getPing() const = 0;


protected:

    Client(ClientListener& listener);

    void connectionAccepted();

    void connectionLost();


private:

    virtual bool onConnectionRequest(
            const std::string& ip,
            unsigned int port,
            unsigned int packetTime
    ) = 0;

    virtual void onDisconnect() = 0;


////////////////////////////////////////////////////////////
// Member data
////////////////////////////////////////////////////////////

protected:

    ClientListener& listener; ///< listener for incomming network events

private:

    bool running;   ///< flag telling if the client thread is running

    bool connected; ///< flag telling if the client is connected to a server

};

}   // namespace eve

#endif // EVE_CLIENT_HPP
