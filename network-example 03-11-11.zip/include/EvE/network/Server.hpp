////////////////////////////////////////////////////////////
//
// EvE - Evolution Engine
// Copyright (C) 2011 Gil Costa (gsaurus@gmail.com)
//
// TODO: License here
//
////////////////////////////////////////////////////////////

#ifndef EVE_SERVER_HPP
#define EVE_SERVER_HPP

////////////////////////////////////////////////////////////
// Headers
////////////////////////////////////////////////////////////
#include <EvE/Config.hpp>
#include <cstring>

namespace eve{

//forward declarations
class ServerListener;

////////////////////////////////////////////////////////////
/// \brief Manages providers.
///
////////////////////////////////////////////////////////////
class EVE_API Server{

public:

    ////////////////////////////////////////////////////////////
    /// \brief
    ///
    ////////////////////////////////////////////////////////////
    static Server* create(ServerListener& listener);

    virtual ~Server();

    bool start(
            unsigned int port,
            unsigned int maxClients,
            unsigned int packetTime
    );

    void stop();

    bool isRunning();

    virtual void send(unsigned int clientId, const char* data, std::size_t size, bool priority = true) = 0;

    virtual unsigned int getPing(unsigned int clientId) const = 0;


protected:

    Server(ServerListener& listener);

private:

    virtual bool onStart(
            unsigned int port,
            unsigned int maxClients,
            unsigned int packetTime
    ) = 0;

    virtual void onStop() = 0;


////////////////////////////////////////////////////////////
// Member data
////////////////////////////////////////////////////////////

protected:

    ServerListener& listener; ///< listener for incomming network events

private:

    bool running; ///< flag telling if the server is running

};

}   // namespace eve

#endif // EVE_SERVER_HPP
