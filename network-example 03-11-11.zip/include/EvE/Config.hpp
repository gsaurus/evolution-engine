////////////////////////////////////////////////////////////
//
// EvE - Evolution Engine
// Copyright (C) 2011 Gil Costa (gsaurus@gmail.com)
//
// TODO: License here
//
////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////
//
// Based on SFML configuration header
// SFML Config.hpp:
// http://www.sfml-dev.org/documentation/2.0/Config_8hpp_source.php
//
// Acknowledgements to Simple and Fast Multimedia Library
// http://www.sfml-dev.org/
//
////////////////////////////////////////////////////////////


#ifndef EVE_CONFIG_HPP
#define EVE_CONFIG_HPP


////////////////////////////////////////////////////////////
// Define portable import / export macros
////////////////////////////////////////////////////////////
#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__)

    #ifndef EVE_STATIC

        // Windows platforms
        #ifdef EVE_EXPORTS

            // From DLL side, we must export
            #define EVE_API __declspec(dllexport)

        #else

            // From client application side, we must import
            #define EVE_API __declspec(dllimport)

        #endif

    #else

        // No specific directive needed for static build
        #define EVE_API

    #endif

#else

    // Other platforms don't need to define anything
    #define EVE_API

#endif




#endif // EVE_CONFIG_HPP
