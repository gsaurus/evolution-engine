#include <EvE/Network.hpp>
#include <string>
#include <vector>
#include <iostream>
#include <sstream>

std::string username;
eve::Server* server = NULL;
eve::Client* client = NULL;


static const std::string SERVER_BOT = "SERVER: ";
static const unsigned int PORT = 27886;



class ChatServerListener: public eve::ServerListener{

public:

    void onConnectionRequest(unsigned int clientId, const std::string& ip){
        std::ostringstream os;
        os << SERVER_BOT << "Connection #" << clientId <<" requested from " << ip << std::endl;
        std::cout << os.str();
        if (clientId == clients.size()){
            clients.push_back("");
        }
        broadcastExcept(clientId, os.str());
    }

    void onConnectionLost(unsigned int clientId){
        std::ostringstream os;
        if (!clients[clientId].empty()){
            os << SERVER_BOT << clients[clientId] << " disconnected" << std::endl;
        }else{
            os << SERVER_BOT << "A login attempt failed" << std::endl;
            clients[clientId].clear();
        }
        std::cout << os.str();
        broadcastExcept(clientId, os.str());
    }

    void onDataReceived(unsigned int clientId, const char* data, std::size_t size, bool priority){
        std::ostringstream os;
        if (data[0] == 'n'){
            clients[clientId] = std::string(&data[1], size-1);
            os << SERVER_BOT << clients[clientId] << " loged in" << std::endl;
        }else{
            std::string message(&data[1], size-1);
            os << clients[clientId] << "(ping: " << server->getPing(clientId) <<"): " << message << std::endl;
        }
        std::cout << os.str();
        broadcastExcept(clientId, os.str());
    }

    void broadcastExcept(int clientId, const std::string& message){
        for (unsigned int i = 0 ; i < clients.size() ; ++i){
            if (!clients[i].empty() && static_cast<int>(i) != clientId)
                server->send(i, message.c_str(), message.size());
        }
    }

private:

    std::vector<std::string> clients;

};


void runServer(){
    ChatServerListener listener;
    server = eve::Server::create(listener);
    server->start(PORT, 8, 100);
    std::cout << SERVER_BOT << "Server is now running\n";

    std::string message;
    while(true){
        std::getline(std::cin, message);
        if (message.compare("exit")==0)
            break;
        std::ostringstream os;
        os << username << ": " << message << std::endl;
        listener.broadcastExcept(-1, os.str());
    }
    server->stop();
    delete server;
    server = NULL;
}










class ChatClientListener: public eve::ClientListener{

public:

    void onConnectionEstablished(){
        std::cout << SERVER_BOT << "Welcome " << username << std::endl;
        std::string anounce = "n" + username;
        client->send(anounce.c_str(), anounce.size());
    }

    void onConnectionLost(){
        std::cout << SERVER_BOT << "Server disconnected" << std::endl;
    }

    void onDataReceived(const char* data, std::size_t size, bool priority){
        std::string message(data,size);
        std::cout << message;
    }

};

void runClient(const std::string& serverIp){

    ChatClientListener listener;
    client = eve::Client::create(listener);
    client->connectionRequest(serverIp, PORT, 100);

    // active waiting... obviously this should be handled with wait/signal
    std::cout << "Connecting...\n";
    while(client->isRunning() && !client->isConnected());

    std::string message;
    while(client->isConnected()){
        std::getline(std::cin, message);
        if (message.compare("exit")==0)
            break;
        else if (message.compare("ping")==0){
            std::cout << "Your ping: " << client->getPing() << std::endl;
        }else{
            std::string realMessage = "x" + message;
            client->send(realMessage.c_str(), realMessage.size());
        }
    }
    client->disconnect();
    delete client;
    client = NULL;
}

int main(){
    std::cout << "EvE-Network test 1\n";
    std::cout << "Write \"s <your_name>\" to start a server, or\n";
    std::cout << "Write \"c <your_name> <server_ip>\" to start a client\n";
    std::cout << "Special commands: \"ping\"(only clients) and \"exit\"\n\n";
    char c;
    std::cin >> c;
    std::getline(std::cin, username);
    username = username.substr(username.find_first_of(' ')+1, username.size());
    if (c == 's' || c == 'S')
        runServer();
    else if (c == 'c' || c == 'C'){
        unsigned int pos = username.find_last_of(' ');
        std::string ip = username.substr(pos+1, username.size());
        username = username.substr(0, pos);
        runClient(ip);
    }

    std::cout << "Good bye\n";
    std::cout << "Press any key to exit";
    std::cin.ignore(10000, '\n');
    return 0;
}
