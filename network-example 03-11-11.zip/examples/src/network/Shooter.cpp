#include <EvE/Network.hpp>

#include <SFML/Graphics.hpp>
#include <string>
#include <vector>
#include <deque>
#include <set>
#include <list>
#include <iostream>
#include <sstream>
#include <cmath>

static const unsigned int PORT = 27886;

static const unsigned int FRAME_RATE = 17;

static const unsigned int WIDTH = 1024;
static const unsigned int HEIGHT = 768;

static const unsigned int MAX_STATES = 30;     // 30 states (5*30 -> 2s)
static const unsigned int STATES_INTERVAL = 5; // every 5 frames


static const unsigned int SHIP_RADIUS = 16;
static const unsigned int BULLET_RADIUS = 3;

static const float SHIP_VELOCITY   = 4.f;
static const float BULLET_VELOCITY = 9.f;
static const float SHIP_ROT_VEL  = 0.08f;

static sf::Texture SHIP_TEXTURE;
static sf::Texture BULLET_TEXTURE;


static const char MSG_STATE_UPDATE = 0;
static const char MSG_LOST_SHIP    = 1;
static const char MSG_KEY_EVENT    = 2;


static const unsigned int FIRE_DISTANCE = SHIP_RADIUS+BULLET_RADIUS+1;
static const float NO_INTERPOLATION = -1;
static const float INTERPOLATION_ACC = 0.2;
void init(){
    SHIP_TEXTURE.LoadFromFile("resources/spaceship1.png");
    BULLET_TEXTURE.LoadFromFile("resources/lazer.png");
}


//class SpaceshipState;
class State;
class Spaceship;
class Bullet;

class FullState{
private:
    std::vector<State*> ships;
    std::vector<State*> bullets;
    friend class EntitiesManager;
};

// TODO: ideally inherit from same as Sprite, and has state inheriting State
class EntitiesManager{
protected:

    static const unsigned int LEFT_PRESS = 0;
    static const unsigned int RIGHT_PRESS = 1;
    static const unsigned int DIR_RELEASE = 2;
    static const unsigned int FIRE_PRESS = 3;

    struct KeyEvent{
        unsigned int ship; // who
        unsigned int code; // what
    };

    // Game entities
    std::vector<Spaceship*> ships;
    std::set<Bullet*> bullets;

    unsigned int myShip;

    // Temporary deletions
    std::vector<unsigned int> deletedShips;
    std::set<Bullet*> deletedBullets;

    // States and logs
    std::deque<unsigned int> statesTime;
    std::map<unsigned int, std::list<KeyEvent> > keysLog;

    // TIME!
    unsigned int gameTime;
    float interpolation;

    // state experience
    FullState* aState;

public:

    EntitiesManager();

    virtual ~EntitiesManager();

//--------------------------------------
//            Entities Stuff
//--------------------------------------

    void addBullet(Bullet* bullet);
    void addSpaceship(unsigned int id, Spaceship* ship);
    void deleteBullet(Bullet* bullet);
    void deleteSpaceship(unsigned int ship);
    std::set<Bullet*>::iterator bulletsBegin();
    std::set<Bullet*>::iterator bulletsEnd();
    unsigned int shipsSize() const;
    bool shipExists(unsigned int i) const;

    unsigned int getTime() const;

//--------------------------------------
//            State Stuff
//--------------------------------------

    FullState* saveState();
    void loadState(const FullState& state);
    void reset();
    void restore(unsigned int time);


//--------------------------------------
//            Update Stuff
//--------------------------------------
// should be called by this order
    void readInput(sf::RenderWindow& window);
    void update();
    void draw(sf::RenderWindow& window);

// More update stuff
private:


    void updateSprites();
    void saveStatesControl();


//--------------------------------------
//              Keys Stuff
//--------------------------------------


    void applyKeysLog();
    void applyKey(KeyEvent& key);
    void addKeyEvent(KeyEvent& key, unsigned int time);
    void createKeyEvent(unsigned int key);


//--------------------------------------
//              Draw Stuff
//--------------------------------------
    void normalDraw(sf::RenderTarget& target);
    void interpolatedDraw(sf::RenderTarget& target);

    virtual void onNewSpaceships(){
        // Nothing by default
    }
    virtual void onKeyEvent(KeyEvent& event, unsigned int time) = 0;

};


class State{
private:
    float x, y, direction;
    friend class Sprite;
};

class Sprite: public sf::Sprite{
protected:
    float direction;
    const unsigned int radius;

private:
    std::deque<State*> states;
    State* oldState;     // visual state

public:

    Sprite(const sf::Texture &texture, unsigned int radius, unsigned int x, unsigned int y, float direction):
        sf::Sprite(texture), direction(direction), radius(radius)
    {
        SetOrigin(GetSize().x/2, GetSize().y/2);
        SetPosition(x,y);
    }
    virtual ~Sprite(){
        std::deque<State*>::iterator it;
        for (it = states.begin() ; it != states.end() ; ++it){
            delete *it;
        }

        deleteOldState();
    }


    float getRadius() const{
        return radius;
    }

//------------------------------------
//            STATE STUFF
//------------------------------------

    void saveState(){
        states.push_back( createState() );
        if (states.size() > MAX_STATES){
            delete states.front();
            states.pop_front();
        }
    }
    virtual void loadState(const State& state){
        SetPosition(state.x, state.y);
        direction = state.direction;
    }
    void restoreState(unsigned int stateId){

        // save current state
        deleteOldState();
        oldState = createState();

        // pop the required state
        for(unsigned int i = 0; i < stateId ; ++i){
            delete states.back();
            states.pop_back();
        }

        // load the state
        loadState( *states.back() );

    }


    virtual void externalize(State& state){
        /// "super"::externalize(state);
        /// state.childState = child.createState();
        state.x = GetPosition().x;
        state.y = GetPosition().y;
        state.direction = direction;
    }
    State* createState(){
        State* state = createStateObject();
        externalize(*state);
        return state;
    }


    virtual void preUpdate(EntitiesManager& manager){
        // Nothing by default
    }
    virtual void update(EntitiesManager& manager){
        // move
        float vel = getVelocity();
        Move(vel * std::cos(direction), vel * std::sin(direction));
        SetRotation(direction*180/3.1415f);
    }
    virtual void draw(sf::RenderTarget& target){
        target.Draw(*this);
    }
    virtual void drawInterpolation(sf::RenderTarget& target, float t){
        if (!oldState)
            draw(target);
        else{
            sf::Vector2f currPos = GetPosition();
            sf::Vector2f interPos;
            float interDir;
            interPos.x = interpolate(oldState->x, currPos.x, t);
            interPos.y = interpolate(oldState->y, currPos.y, t);
            interDir = interpolate(oldState->direction, direction, t);
            SetPosition(interPos);
            SetRotation(interDir);
            target.Draw(*this);
            SetPosition(currPos); // restore position
        }
    }

    bool intersects(const Sprite& other) const{
        const sf::Vector2f& p1 = GetPosition();
        const sf::Vector2f& p2 = other.GetPosition();
        return ::sqrt( ::pow(p2.x-p1.x, 2) + ::pow(p2.y-p1.y, 2) ) < radius + other.getRadius()-1;
    }

protected:
    static float interpolate(float xi, float xf, float t){
        return xf*t + xi*(1-t);
    }



private:

    virtual float getVelocity() const = 0;

    virtual State* createStateObject(){
        return new State();
    }
    void deleteOldState(){
        if (oldState){
            delete oldState;
            oldState = NULL;
        }
    }

};



class SpaceshipState: public State{
private:
    float dirVel;
    friend class Spaceship;
};

class Bullet:public Sprite{

public:

    Bullet(unsigned int x, unsigned int y, float direction, bool own):
        Sprite(BULLET_TEXTURE, BULLET_RADIUS,x,y,direction)
    {
        if (own) SetColor(sf::Color::Green);
        else SetColor(sf::Color::Red);
        Resize(32,32);
    }


    void update(EntitiesManager& manager){
        Sprite::update(manager);

        // basic edge control
        const sf::Vector2f& pos = GetPosition();
        if (pos.x < 0 || pos.x > WIDTH || pos.y < 0 || pos.y > HEIGHT){
            manager.deleteBullet(this);
        }
    }

private:

    float getVelocity() const{
        return BULLET_VELOCITY;
    }

};

class Spaceship:public Sprite{
private:
    float dirVel;
    bool own;
    bool willReset;

public:

    Spaceship(bool own = false):
        Sprite(SHIP_TEXTURE, SHIP_RADIUS,0,0,0.f), dirVel(0.f), own(own)
    {
        if (own) SetColor(sf::Color(100,255,100));
        else SetColor(sf::Color(255,100,100));
        Resize((SHIP_RADIUS+3)*2,(SHIP_RADIUS+3)*2);
        reset();
    }


    void rotateLeft(){
        dirVel = -SHIP_ROT_VEL;
    }
    void rotateRight(){
        dirVel = +SHIP_ROT_VEL;
    }
    void stop(){
        dirVel = 0.f;
    }

    void shoot(EntitiesManager& manager){
        sf::Vector2f pos = GetPosition();
        pos.x += FIRE_DISTANCE * std::cos(direction);
        pos.y += FIRE_DISTANCE * std::sin(direction);
        manager.addBullet( new Bullet(pos.x, pos.y, direction, own) );
    }

    void loadState(const State& state){
        Sprite::loadState(state);
        const SpaceshipState& theState = static_cast<const SpaceshipState&>(state);
        dirVel = theState.dirVel;
    }
    void externalize(State& state){
        Sprite::externalize(state);
        SpaceshipState& theState = static_cast<SpaceshipState&>(state);
        theState.dirVel = dirVel;
    }

    void preUpdate(EntitiesManager& manager){
        std::set<Bullet*>::iterator it;
        for (it = manager.bulletsBegin() ; it != manager.bulletsEnd() ; ++it){
            if ( intersects(**it) ){
                manager.deleteBullet(*it);
                willReset = true;
            }
        }
    }

    void update(EntitiesManager& manager){
        Sprite::update(manager);
        if (willReset){
            reset();
        }else{
            // basic edge control (not dependant of others)
            const sf::Vector2f& pos = GetPosition();
            if (pos.x < 0) SetX(pos.x + WIDTH);
            if (pos.x > WIDTH) SetX(pos.x - WIDTH);
            if (pos.y < 0) SetY(pos.y + HEIGHT);
            if (pos.y > HEIGHT) SetY(pos.y - HEIGHT);
        }
        direction += dirVel;
    }

private:

    void reset(){
        SetPosition(0, SHIP_RADIUS*2);
        direction = 0.f;
        willReset = false;
    }

    float getVelocity() const{
        return SHIP_VELOCITY;
    }
    State* createStateObject(){
        return new SpaceshipState();
    }

};


EntitiesManager::EntitiesManager():
    myShip(0), gameTime(0), interpolation(NO_INTERPOLATION), aState(NULL)
{
    // ?
}

EntitiesManager::~EntitiesManager(){
    reset();
    delete aState;
}

//--------------------------------------
//            Entities Stuff
//--------------------------------------

void EntitiesManager::addBullet(Bullet* bullet){
    bullets.insert(bullet);
}
void EntitiesManager::addSpaceship(unsigned int id, Spaceship* ship){
    if (id > ships.size()) return;
    if (ships.size() == id){
        ships.push_back(ship);
    }else{
        if (ships[id]) delete ships[id]; // ??!!...
        ships[id] = ship;
    }
}
void EntitiesManager::deleteBullet(Bullet* bullet){
    deletedBullets.insert(bullet);
}
void EntitiesManager::deleteSpaceship(unsigned int ship){
    deletedShips.push_back(ship);
}
std::set<Bullet*>::iterator EntitiesManager::bulletsBegin(){
    return bullets.begin();
}
std::set<Bullet*>::iterator EntitiesManager::bulletsEnd(){
    return bullets.end();
}
unsigned int EntitiesManager::shipsSize() const{
    return ships.size();
}
bool EntitiesManager::shipExists(unsigned int i) const{
    return ships[i] != NULL;
}

unsigned int EntitiesManager::getTime() const{
    return gameTime;
}

//--------------------------------------
//            State Stuff
//--------------------------------------

FullState* EntitiesManager::saveState(){
    FullState* res = new FullState();
    std::vector<State*>& ss = res->ships;
    std::vector<State*>& bs = res->bullets;
    // Save ships state
    ss.reserve(ships.size());
    for (unsigned int i = 0 ; i < ships.size() ; ++i){
        if (ships[i]) ss.push_back( ships[i]->createState() );
        else ss.push_back(NULL);
    }
    // Save bullets state
    bs.reserve(bullets.size());
    std::set<Bullet*>::iterator it;
    for (it = bullets.begin() ; it != bullets.end() ; ++it){
        bs.push_back( (*it)->createState() );
    }
    return res;
}
void EntitiesManager::loadState(const FullState& state){
    reset();
    const std::vector<State*>& ss = state.ships;
    const std::vector<State*>& bs = state.bullets;

    // create ships
    ships.reserve(ss.size());
    for(unsigned int i = 0 ; i < ss.size() ; ++i){
        if (ss[i]){
            Spaceship* s = new Spaceship(i == myShip);
            s->loadState(*ss[i]);
            ships.push_back(s);
        }else ships.push_back(NULL);
    }

    // Create bullets
    std::vector<State*>::const_iterator it;
    for (it = bs.begin() ; it != bs.end() ; ++it){
        Bullet* b = new Bullet(0,0,0, false); // TODO: I know, ignore false
        b->loadState(**it);
        bullets.insert(b);
    }
}
void EntitiesManager::reset(){ // called by loadState
    // delete ships
    std::vector<Spaceship*>::iterator sit;
    for (sit = ships.begin() ; sit != ships.end() ; ++sit){
        if (*sit) delete *sit;
    }
    ships.clear();

    // delete bullets
    std::set<Bullet*>::iterator it;
    for (it = bullets.begin() ; it != bullets.end() ; ++it){
        delete *it;
    }
    bullets.clear();

    deletedBullets.clear();
    deletedShips.clear();
}
void EntitiesManager::restore(unsigned int time){
    // find the previous correct state
    unsigned int stateId = 0;
    while (statesTime.back() > time){
        statesTime.pop_back();
        ++stateId;
    }

    // kill recent keylogs (NOTE: this is stupid, find then erase instead..)
    while(keysLog.begin()->first < time){
        keysLog.erase(keysLog.begin());
    }

    // restore states of sprites
    std::vector<Spaceship*>::iterator sit;
    for(sit = ships.begin() ; sit != ships.end() ; ++sit){
        (*sit)->restoreState(stateId);
    }
    std::set<Bullet*>::iterator bit;
    for(bit = bullets.begin() ; bit != bullets.end() ; ++bit){
        (*bit)->restoreState(stateId);
    }

}


//--------------------------------------
//            Update Stuff
//--------------------------------------
// should be called by this order
void EntitiesManager::readInput(sf::RenderWindow& window){
    sf::Event event;
    static bool firePressed;
    Spaceship* s;
    while (window.PollEvent(event)){
         // Request for closing the window
         if (event.Type == sf::Event::Closed)
             window.Close();

         // Key presses & releases
         if (event.Type == sf::Event::KeyPressed){
             switch(event.Key.Code){
                 case sf::Keyboard::Left:   createKeyEvent(LEFT_PRESS);  break;
                 case sf::Keyboard::Right:  createKeyEvent(RIGHT_PRESS); break;
                 case sf::Keyboard::Escape: window.Close(); break;
                 case sf::Keyboard::Home:
                    gameTime = 0;
                    reset();
                    s = new Spaceship(false);
                    //s->SetColor(sf::Color::Yellow);
                    addSpaceship(0, s);
                    break;
                case sf::Keyboard::Insert:
                    if (aState) delete aState;
                    aState = saveState();
                    break;
                case sf::Keyboard::Delete:
                    if (aState)
                        loadState(*aState);
                default:
                    if (!firePressed){
                        createKeyEvent(FIRE_PRESS);
                        firePressed = true;
                    }
             }
         }else if (event.Type == sf::Event::KeyReleased){
             switch(event.Key.Code){
                 case sf::Keyboard::Left:
                    if (!sf::Keyboard::IsKeyPressed(sf::Keyboard::Right))
                        createKeyEvent(DIR_RELEASE);
                    else createKeyEvent(RIGHT_PRESS);
                    break;
                 case sf::Keyboard::Right:
                    if (!sf::Keyboard::IsKeyPressed(sf::Keyboard::Left))
                        createKeyEvent(DIR_RELEASE);
                    else createKeyEvent(LEFT_PRESS);
                    break;
                default: firePressed = false;
             }
         }
     }
}
void EntitiesManager::update(){
    // apply whatever keys that were requested for this frame
    applyKeysLog();

    // update sprites
    updateSprites();

    // possibly save state
    saveStatesControl();

    // update frame
    gameTime++;
}
void EntitiesManager::draw(sf::RenderWindow& window){
    if (interpolation == NO_INTERPOLATION)
        normalDraw(window);
    else interpolatedDraw(window);
}

void EntitiesManager::updateSprites(){

    // pre-update
    std::vector<Spaceship*>::iterator sit;
    for(sit = ships.begin() ; sit != ships.end() ; ++sit){
        (*sit)->preUpdate(*this);
    }
    std::set<Bullet*>::iterator bit;
    for(bit = bullets.begin() ; bit != bullets.end() ; ++bit){
        (*bit)->preUpdate(*this);
    }

    // update
    for(sit = ships.begin() ; sit != ships.end() ; ++sit){
        (*sit)->update(*this);
    }
    for(bit = bullets.begin() ; bit != bullets.end() ; ++bit){
        (*bit)->update(*this);
    }


    // remove destroyed objects
    std::vector<unsigned int>::iterator dsit;
    for (dsit = deletedShips.begin() ; dsit != deletedShips.end() ; ++dsit){
        if (ships[*dsit]){
            delete ships[*dsit];
            ships[*dsit] = NULL;
        }
    }
    deletedShips.clear();
    std::set<Bullet*>::iterator dbit;
    for (dbit = deletedBullets.begin() ; dbit != deletedBullets.end() ; ++dbit){
        std::set<Bullet*>::iterator pos = bullets.find(*dbit);
        if (pos != bullets.end()){
            bullets.erase(pos);
            delete *pos; // TODO: crashing here on debug mostly
        }
    }
    deletedBullets.clear();
}
void EntitiesManager::saveStatesControl(){
    if (gameTime % STATES_INTERVAL == 0){
        // record state time
        statesTime.push_back(gameTime);
        //..this can be improved so that sprites do not have the same if..
        if (statesTime.size() > MAX_STATES){
            statesTime.pop_front();
        }

        // save states of sprites
        std::vector<Spaceship*>::iterator sit;
        for(sit = ships.begin() ; sit != ships.end() ; ++sit){
            (*sit)->saveState();
        }
        std::set<Bullet*>::iterator bit;
        for(bit = bullets.begin() ; bit != bullets.end() ; ++bit){
            (*bit)->saveState();
        }
    }
}


//--------------------------------------
//              Keys Stuff
//--------------------------------------


void EntitiesManager::applyKeysLog(){
    std::map<unsigned int, std::list<KeyEvent> >::iterator it;
    it = keysLog.find(gameTime);
    if (it!=keysLog.end()){
        std::list<KeyEvent>& lst = it->second;
        std::list<KeyEvent>::iterator kit;
        for(kit = lst.begin() ; kit != lst.end() ; ++kit){
            applyKey(*kit);
        }
    }
}
void EntitiesManager::applyKey(KeyEvent& key){
    Spaceship* ship = ships[key.ship];
    switch (key.code){
        case LEFT_PRESS: ship->rotateLeft(); break;
        case RIGHT_PRESS: ship->rotateRight(); break;
        case DIR_RELEASE: ship->stop(); break;
        case FIRE_PRESS: ship->shoot(*this); break;
        default: ;// supress warning
    }
}
void EntitiesManager::addKeyEvent(KeyEvent& key, unsigned int time){
    keysLog[time].push_back(key);
    // LATER: remove old keys
    onKeyEvent(key, time);
}
void EntitiesManager::createKeyEvent(unsigned int key){
    unsigned int time = gameTime + 0; // TODO: add lag compensation variable
    KeyEvent evt;
    evt.code = key;
    evt.ship = myShip;
    addKeyEvent(evt, time);
}


//--------------------------------------
//              Draw Stuff
//--------------------------------------
void EntitiesManager::normalDraw(sf::RenderTarget& target){
    // draw sprites
    std::set<Bullet*>::iterator bit;
    for(bit = bullets.begin() ; bit != bullets.end() ; ++bit){
        (*bit)->draw(target);
    }
    std::vector<Spaceship*>::iterator sit;
    for(sit = ships.begin() ; sit != ships.end() ; ++sit){
        (*sit)->draw(target);
    }
}
void EntitiesManager::interpolatedDraw(sf::RenderTarget& target){
    // draw sprites
    std::set<Bullet*>::iterator bit;
    for(bit = bullets.begin() ; bit != bullets.end() ; ++bit){
        (*bit)->drawInterpolation(target, interpolation);
    }
    std::vector<Spaceship*>::iterator sit;
    for(sit = ships.begin() ; sit != ships.end() ; ++sit){
        (*sit)->drawInterpolation(target, interpolation);
    }

    // interpolation control
    interpolation += INTERPOLATION_ACC;
    if (interpolation >= 1.f){
        interpolation = NO_INTERPOLATION;
    }
}




class Server: public EntitiesManager{
private:
    eve::Server* server;
private:

    void onNewSpaceships(){
        // Nothing by default
    }
    void onKeyEvent(KeyEvent& event, unsigned int time){
//        sf::Packet dos;
//        dos << MSG_KEY_EVENT;
//        dos << static_cast<sf::Uint8>(event.code);
//        dos << static_cast<sf::Uint8>(event.ship);
//        dos << static_cast<sf::Uint32>(time);
//        broadcastExcept(event.ship-1, dos);
    }

//    void broadcastExcept(int clientId, const sf::Packet& packet){
//        unsigned int size = entities.shipsSize();
//        for (unsigned int i = 0 ; i < size ; ++i){
//            if (entities.shipExists(i) && static_cast<int>(i) != clientId)
//                server->send(i, packet.GetData(), packet.GetDataSize());
//        }
//    }

};

//
//class NetworkManager{
//public:
//
//
//};
//
//
//
//
class ServerListener: public eve::ServerListener{
private:
    EntitiesManager& entities;

public:

    ServerListener(EntitiesManager& entities): entities(entities){
        // ?
    }

    void onConnectionRequest(unsigned int clientId, const std::string& ip){
        entities.addSpaceship(clientId, new Spaceship());
        // message will be broadcasted after state computation
    }

    void onConnectionLost(unsigned int clientId){
        entities.deleteSpaceship(clientId);
//        sf::Packet dos;
//        dos << MSG_LOST_SHIP << static_cast<sf::Uint8>(clientId);
//        dos << static_cast<sf::Uint32>(entities.getTime());
//        broadcastExcept(clientId, dos);
    }

    void onDataReceived(unsigned int clientId, const char* data, std::size_t size, bool priority){
//        std::ostringstream os;
//        if (data[0] == 'n'){
//            clients[clientId] = std::string(&data[1], size-1);
//            os << SERVER_BOT << clients[clientId] << " loged in" << std::endl;
//        }else{
//            std::string message(&data[1], size-1);
//            os << clients[clientId] << "(ping: " << server->getPing(clientId) <<"): " << message << std::endl;
//        }
//        std::cout << os.str();
//        broadcastExcept(clientId, os.str());
    }

};

class ClientListener: public eve::ClientListener{

};




int main(){

    init();

    unsigned int count = 0;
    sf::Clock clock;    // time controller
    sf::RenderWindow app(sf::VideoMode(WIDTH, HEIGHT), "Network prototype tests..");

    sf::Text fps;{
        fps.SetColor(sf::Color::White);
        fps.SetCharacterSize(15);
        fps.SetStyle(sf::Text::Bold);
        fps.SetPosition(5,app.GetHeight()-20);
    }

    //EntitiesManager mg;
    Server mg;
    mg.addSpaceship(0,new Spaceship(true));

    sf::Sleep(1000);

    while (app.IsOpened()){

        count += clock.GetElapsedTime(); //app.GetFrameTime();
        std::stringstream outFPS;
        outFPS << "FPS: " << ::round(1000.f/count);
        fps.SetString(outFPS.str());

        mg.readInput(app);

        // --- States cycle ---
        while (count>=FRAME_RATE){
            count -=FRAME_RATE;
            // Update
            mg.update();
        }

        app.Clear();
        mg.draw(app);
        app.Draw(fps);
        app.Display();


        count += clock.GetElapsedTime();
        // makes the game sleep, releasing CPU usage
        if (count < FRAME_RATE){
            sf::Sleep(FRAME_RATE - count);
            count = FRAME_RATE;
        }else{
            std::cout << "I can't sleep!\n";
        }
        clock.Reset();
    }
    return 0;
}




//
//
//
//class ChatServerListener: public eve::ServerListener{
//
//public:
//
//    void onConnectionRequest(unsigned int clientId, const std::string& ip){
//        std::ostringstream os;
//        os << SERVER_BOT << "Connection #" << clientId <<" requested from " << ip << std::endl;
//        std::cout << os.str();
//        if (clientId == clients.size()){
//            clients.push_back("");
//        }
//        broadcastExcept(clientId, os.str());
//    }
//
//    void onConnectionLost(unsigned int clientId){
//        std::ostringstream os;
//        if (!clients[clientId].empty()){
//            os << SERVER_BOT << clients[clientId] << " disconnected" << std::endl;
//        }else{
//            os << SERVER_BOT << "A login attempt failed" << std::endl;
//            clients[clientId].clear();
//        }
//        std::cout << os.str();
//        broadcastExcept(clientId, os.str());
//    }
//
//    void onDataReceived(unsigned int clientId, const char* data, std::size_t size, bool priority){
//        std::ostringstream os;
//        if (data[0] == 'n'){
//            clients[clientId] = std::string(&data[1], size-1);
//            os << SERVER_BOT << clients[clientId] << " loged in" << std::endl;
//        }else{
//            std::string message(&data[1], size-1);
//            os << clients[clientId] << "(ping: " << server->getPing(clientId) <<"): " << message << std::endl;
//        }
//        std::cout << os.str();
//        broadcastExcept(clientId, os.str());
//    }
//
//    void broadcastExcept(int clientId, const std::string& message){
//        for (unsigned int i = 0 ; i < clients.size() ; ++i){
//            if (!clients[i].empty() && static_cast<int>(i) != clientId)
//                server->send(i, message.c_str(), message.size());
//        }
//    }
//
//private:
//
//    std::vector<std::string> clients;
//
//};
//
//
//void runServer(){
//    ChatServerListener listener;
//    server = eve::Server::create(listener);
//    server->start(PORT, 8, 100);
//    std::cout << SERVER_BOT << "Server is now running\n";
//
//    std::string message;
//    while(true){
//        std::getline(std::cin, message);
//        if (message.compare("exit")==0)
//            break;
//        std::ostringstream os;
//        os << username << ": " << message << std::endl;
//        listener.broadcastExcept(-1, os.str());
//    }
//    server->stop();
//    delete server;
//    server = NULL;
//}
//
//
//
//
//
//
//
//
//
//
//class ChatClientListener: public eve::ClientListener{
//
//public:
//
//    void onConnectionEstablished(){
//        std::cout << SERVER_BOT << "Welcome " << username << std::endl;
//        std::string anounce = "n" + username;
//        client->send(anounce.c_str(), anounce.size());
//    }
//
//    void onConnectionLost(){
//        std::cout << SERVER_BOT << "Server disconnected" << std::endl;
//    }
//
//    void onDataReceived(const char* data, std::size_t size, bool priority){
//        std::string message(data,size);
//        std::cout << message;
//    }
//
//};
//
//void runClient(const std::string& serverIp){
//
//    ChatClientListener listener;
//    client = eve::Client::create(listener);
//    client->connectionRequest(serverIp, PORT, 100);
//
//    // active waiting... obviously this should be handled with wait/signal
//    std::cout << "Connecting...\n";
//    while(client->isRunning() && !client->isConnected());
//
//    std::string message;
//    while(client->isConnected()){
//        std::getline(std::cin, message);
//        if (message.compare("exit")==0)
//            break;
//        else if (message.compare("ping")==0){
//            std::cout << "Your ping: " << client->getPing() << std::endl;
//        }else{
//            std::string realMessage = "x" + message;
//            client->send(realMessage.c_str(), realMessage.size());
//        }
//    }
//    client->disconnect();
//    delete client;
//    client = NULL;
//}

//int main(){
//
//    init();
//
//    std::cout << "EvE-Network test 1\n";
//    std::cout << "Write \"s <your_name>\" to start a server, or\n";
//    std::cout << "Write \"c <your_name> <server_ip>\" to start a client\n";
//    std::cout << "Special commands: \"ping\"(only clients) and \"exit\"\n\n";
//    char c;
//    std::cin >> c;
//    std::getline(std::cin, username);
//    username = username.substr(username.find_first_of(' ')+1, username.size());
//    if (c == 's' || c == 'S')
//        runServer();
//    else if (c == 'c' || c == 'C'){
//        unsigned int pos = username.find_last_of(' ');
//        std::string ip = username.substr(pos+1, username.size());
//        username = username.substr(0, pos);
//        runClient(ip);
//    }
//
//    std::cout << "Good bye\n";
//    std::cout << "Press any key to exit";
//    std::cin.ignore(10000, '\n');
//    return 0;
//}
