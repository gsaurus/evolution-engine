////////////////////////////////////////////////////////////
//
// EvE - Evolution Engine
// Copyright (C) 2011 Gil Costa (gsaurus@gmail.com)
//
// TODO: License here
//
////////////////////////////////////////////////////////////

#ifndef RENET_CONNECTION_HPP
#define RENET_CONNECTION_HPP

////////////////////////////////////////////////////////////
// Headers
////////////////////////////////////////////////////////////
#include <Renet/Config.hpp>
#include <Renet/PacketMessage.hpp>

#include <SFML/System.hpp>
#include <SFML/Network.hpp>
#include <set>

namespace rn{

// forward declarations
class Station;

////////////////////////////////////////////////////////////
/// \brief Manages providers.
///
////////////////////////////////////////////////////////////
class Connection{

////////////////////////////////////////////////////////////
// Structures
////////////////////////////////////////////////////////////

private:

    enum MessageType{
        ConnectionRequest  = 0,
        ConnectionAccepted = 1,
        Disconnected       = 2,
        Ping = 3,
        Pong = 4,
        Data = 5,
        PacketEnd = 7
        // TODO: sinchronize?
    };

    struct PacketInfo{
        unsigned int sequence;  ///< Packet sequence number
        unsigned int time;      ///< Time of sent/received packet
        friend bool operator<(PacketInfo const& a, PacketInfo const& b);
    };


////////////////////////////////////////////////////////////
// Operations
////////////////////////////////////////////////////////////

public:


    ////////////////////////////////////////////////////////////
    /// \brief
    ///
    ////////////////////////////////////////////////////////////
    Connection(
        Receiver& receiver, sf::UdpSocket& socket,
        const sf::IpAddress& myIp, const sf::IpAddress& remoteIp,
        sf::Uint8 connectionId, sf::Uint8 remoteConnectionId = INVALID_CONNECTION_ID
    );

    ~Connection();

    const sf::IpAddress& getRemoteIP() const;

    sf::Socket::Status ping();

    void sendMessage(const PacketMessage& message);

    sf::Socket::Status transmit();


private:

    void initPacket();

    void connect(const sf::IpAddress& myIp);

    sf::Socket::Status disconnect();

    void acceptConnection();

    void pong(sf::Uint32 time);

    bool processPacketBody(sf::Packet& packet);


    void onConnectionAccepted(sf::Packet& packet);

    void onDisconnection();

    void onDataReceived(sf::Packet& packet);

    void onPingReceived(sf::Packet& packet);

    void onPongReceived(sf::Packet& packet);


    void writeHeader();

    void writeFooter();

    void readFooter(sf::Packet& packet);


////////////////////////////////////////////////////////////
// Static Operations
////////////////////////////////////////////////////////////

public:

    static sf::Uint32 getProtocolId();

    static void setProtocolId(sf::Uint32 protocolId);

    static void setReceiver(Receiver& receiver);

    static void processPacket(
        Station& station,
        sf::Packet& packet
    );

    static void onConnectionRequest(
        Station& station,
        sf::Packet& packet,
        unsigned int target
    );

private:

    static unsigned int readHeader(sf::Packet& packet);

////////////////////////////////////////////////////////////
// Member data
////////////////////////////////////////////////////////////

public:

    static const sf::Uint8 INVALID_CONNECTION_ID;
    static const unsigned int INVALID_PROTOCOL_ID;

private:

    static const unsigned int HEADER_SIZE;

    static Station& station;      ///< station to which connections are linked

    sf::IpAddress remoteIp;       ///< identification of the other side
    sf::Uint8 connectionId;       ///< identification of the connection in the station
    sf::Uint8 remoteConnectionId; ///< identification of the connection in the other station

    sf::Uint32 localSequence;     ///< local sequence number

    // TODO: I think it doesn't have to be a field
    sf::Uint32 remoteSequence;    ///< remote sequence number

    sf::Packet packet;            ///< cached data to be sent
    bool areAcksPending;          ///< tell if there are any pending acks

    // TODO: need actual packets if want to resend
    // TODO: use something simpler than std::set
    std::set<PacketInfo> sentPackets;     ///< sorted set of sent packets awaiting ack
    std::set<PacketInfo> receivedPackets; ///< sorted set of received packets

    // TODO: flow control variables

};

}   // namespace rn

#endif // RENET_CONNECTION_HPP
