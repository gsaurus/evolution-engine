////////////////////////////////////////////////////////////
//
// EvE - Evolution Engine
// Copyright (C) 2011 Gil Costa (gsaurus@gmail.com)
//
// TODO: License here
//
////////////////////////////////////////////////////////////

#ifndef RENET_STATION_HPP
#define RENET_STATION_HPP

////////////////////////////////////////////////////////////
// Headers
////////////////////////////////////////////////////////////
#include <Renet/Config.hpp>

#include <SFML/System.hpp>
#include <SFML/Network.hpp>

namespace rn{

// forward declarations
class Connection;

////////////////////////////////////////////////////////////
/// \brief Manages providers.
///
////////////////////////////////////////////////////////////
class Station{


public:

//    enum Mode{
//        Client,
//        Server
//    };


    ////////////////////////////////////////////////////////////
    /// \brief
    ///
    ////////////////////////////////////////////////////////////
    Station(Receiver& receiver, unsigned int protocolId, unsigned int packetTime, unsigned int timeout);

    ~Station();

    bool start(unsigned short port);

    void stop();

    void connectTo(const sf::IpAddress& ip);

//    void send(const PacketMessage& message);

    void run();

private:

    void processPacket(sf::Packet& packet);

//    void sendConnectionRequest(Connection& connection, const sf::IpAddress& ip);

//    unsigned int readHeader(const char* data) const;
//
//    void createHeader(std::vector<char>& header) const;


////////////////////////////////////////////////////////////
// Member data
////////////////////////////////////////////////////////////

private:

    static bool singleton;   ///< Singleton controller

    Receiver& receiver;    ///< object to notify on incoming packets
    sf::Uint32 protocolId; ///< Application protocol identification
    sf::Clock time;        ///< local time
    sf::UdpSocket socket;  ///< Socket used
    sf::IpAddress myIp;    ///< Public IP adress of this computer
    std::vector<Connection*> connections; ///< Active connections

//    Mode mode;               ///< Server or Client
    unsigned int packetTime; ///< Send packets at every packetTime miliseconds
    unsigned int timeout;    ///< Timeout for disconnection, in miliseconds

    bool running;            ///< Flag telling if the network is running
    sf::Thread* thread;      ///< Network thread


    friend class Connection;

};

}   // namespace rn

#endif // RENET_STATION_HPP
