////////////////////////////////////////////////////////////
//
// EvE - Evolution Engine
// Copyright (C) 2011 Gil Costa (gsaurus@gmail.com)
//
// TODO: License here
//
////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////
// Headers
////////////////////////////////////////////////////////////
#include <Renet/Connection.hpp>
#include <Renet/Station.hpp>
#include <algorithm>
#include <cstdio>

namespace rn{


////////////////////////////////////////////////////////////
const sf::Uint8 Connection::INVALID_CONNECTION_ID = 255;
const sf::Uint8 Connection::INVALID_PROTOCOL_ID = 666;

////////////////////////////////////////////////////////////
const unsigned int Connection::HEADER_SIZE = 9;


////////////////////////////////////////////////////////////
Connection::Connection(
    sf::UdpSocket& socket,
    const sf::IpAddress& myIp, const sf::IpAddress& remoteIp,
    sf::Uint8 connectionId, sf::Uint8 remoteConnectionId
):
    socket(socket),
    remoteIp(remoteIp),
    connectionId(connectionId),
    remoteConnectionId(remoteConnectionId),
    areAcksPending(false)
{
    initPacket();
    connect(myIp);
}


////////////////////////////////////////////////////////////
Connection::~Connection(){
    disconnect();
}


bool Connection::operator<(PacketInfo const& a, PacketInfo const& b){
    // TODO: Use max sequence trick
    return a.sequence < b.sequence;
}


////////////////////////////////////////////////////////////
const sf::IpAddress& Connection::getRemoteIP() const{
    return remoteIp;
}


////////////////////////////////////////////////////////////
void Connection::initPacket(){
    packet.Clear();
    writeHeader();
}


////////////////////////////////////////////////////////////
void Connection::connect(const sf::IpAddress& myIp){
    // 1 byte for message type, 4 bytes for our ip, 1 byte for our connectionId
    packet << static_cast<sf::Uint8>(MessageType::ConnectionRequest);
    packet << myIp.ToInteger();
    packet << connectionId;
    transmit();
}


////////////////////////////////////////////////////////////
sf::Socket::Status Connection::disconnect(){
    // 1 byte for message type only
    packet << static_cast<sf::Uint8>(MessageType::Disconnected);
    // send imediately
    return transmit();
}


////////////////////////////////////////////////////////////
void Connection::acceptConnection(){
    // 1 byte for message type, 1 byte for our connectionId
    packet << static_cast<sf::Uint8>(MessageType::ConnectionAccepted);
    packet << connectionId;
}


////////////////////////////////////////////////////////////
sf::Socket::Status Connection::ping(){
    // 1 byte for message type, 4 bytes for current time
    packet << static_cast<sf::Uint8>(MessageType::Ping);
    packet << time.GetElapsedTime();
    // send imediately
    return transmit();
}


////////////////////////////////////////////////////////////
void Connection::pong(sf::Uint32 time){
    // 1 byte for message type, 4 bytes for time
    packet << static_cast<sf::Uint8>(MessageType::Pong);
    packet << time;
    // send imediately
    transmit();
}


////////////////////////////////////////////////////////////
void Connection::sendData(const PacketMessage& message){
    // 1 byte for message type, leave the responsability of the data written to message
    packet << static_cast<sf::Uint8>(MessageType::Data);
    // TODO: hope it change in SFML 2 or 3... I can create a separated packet though
    message.write(packet);
}


////////////////////////////////////////////////////////////
sf::Socket::Status Connection::transmit(){
    if ( packet.GetDataSize() > HEADER_SIZE){
        // write footer (acks, etc)
        writeFooter();
        sf::Socket::Status status = socket.Send(packet, remoteIp, socket.GetLocalPort());
        if (status == sf::Socket::Done){
            // TODO: update sentPackets
        }else{
            receiver.onDataLost(connectionId);
        }
        // reset packet
        initPacket();
        return status;
    }else return sf::Socket::Done; // nothing to send
}


////////////////////////////////////////////////////////////
void Connection::processPacket(
        Station& station,
        sf::Packet& packet
){

    std::vector<Connection*>& connections = station.connections;

    unsigned int target = readHeader(packet);

    if (target == INVALID_PROTOCOL_ID) return;
    if (target == INVALID_CONNECTION_ID || !connections[target]){
        // check if it's a new connection request
        sf::Uint8 messageType;
        packet >> messageType;
        if (messageType == MessageType::ConnectionRequest){
            onConnectionRequest(station, packet, target);
        } // else ignore packet
    }else{
        // deliver messages:
        if (!connections[target]->processPacketBody(packet)){
            // disconnected, remove connection
            delete connections[target];
            connections[target] = NULL;
            // notify connection lost
            receiver.onConnectionLost(target);
        }
    }
}


bool Connection::processPacketBody(sf::Packet& packet){
    // read message type
    sf::Uint8 messageType;
    do{
        packet >> messageType;
        switch(messageType){
            case MessageType::ConnectionAccepted:
                onConnectionAccepted(packet);
                break;
            case MessageType::Disconnected:
                onDisconnection();
                return false; // dead connection, return imediately
            case MessageType::Data:
                onDataReceived(packet);
                break;
            case MessageType::Ping:
                onPingReceived(packet);
                break;
            case MessageType::Pong:
                onPongReceived(packet);
                break;
        }
    }while(messageType != MessageType::PacketEnd);
    // processs acks, etc
    readFooter(packet);
    return true;
}


////////////////////////////////////////////////////////////
void Connection::onConnectionRequest(
        Station& station,
        sf::Packet& packet,
        unsigned int target
){
    // read request
    sf::Uint32 remoteIntIp;
    sf::Uint8 remoteId;
    packet >> remoteIntIp;
    packet >> remoteId;

    // create connection
    Connection* newConnection;
    std::vector<Connection*>& connections = station.connections;
    if (target == INVALID_CONNECTION_ID){
        target = connections.size();
    }
    sf::IpAddress remoteIp(remoteIntIp);
    newConnection = new Connection(
        station.socket, station.myIp,
        remoteIp, target, remoteId
    );
    if (target < connections.size())
        connections[target] = newConnection;
    else connections.push_back(newConnection);
    // notification
    if (!receiver.onConnectionAccepted(target, remoteIp)){
        // connection canceled, remove connection
        connections[target]->disconnect();
        delete connections[target];
        connections[target] = NULL;
    }else{
        // connection was accepted, send notification back
        connections[target]->acceptConnection();
    }
}


////////////////////////////////////////////////////////////
void Connection::onConnectionAccepted(sf::Packet& packet){
    // 1 byte for remoteConnectionId
    packet >> remoteConnectionId;
    receiver.onConnectionAccepted(connectionId, remoteIp)
}


////////////////////////////////////////////////////////////
void Connection::onDisconnection(){
    receiver.onDisconnection(connectionId);
}


////////////////////////////////////////////////////////////
void Connection::onDataReceived(sf::Packet& packet){
    receiver.onDataReceived(connectionId, packet);
}


////////////////////////////////////////////////////////////
void Connection::onPingReceived(sf::Packet& packet){
    sf::Uint32 time;
    packet >> time;
    pong(time);
    transmit();
}


////////////////////////////////////////////////////////////
void Connection::onPongReceived(sf::Packet& packet){
    sf::Uint32 pingTime;
    packet >> pingTime;
    sf::UInt32 ping = time.GetElapsedTime()-pingTime;
    // TODO: other operations with ping
    // TODO: probably tell the average ping instead
    receiver.onPing(connectionId, ping);
}


////////////////////////////////////////////////////////////
void Connection::writeHeader(){
    // 4 bytes for protocol id, 1 byte for remote connection ID, 4 bytes for sequence number
    packet << protocolId;
    packet << remoteConnectionId;
    packet << localSequence++;
}


////////////////////////////////////////////////////////////
unsigned int Connection::readHeader(sf::Packet& packet){
    sf::Uint32 id;
    packet >> id;
    if (id != protocolId) return INVALID_PROTOCOL_ID;
    sf::Uint8 target;
    sf::Uint32 receivedSequence;
    packet >> target;
    packet >> receivedSequence;

    // TODO: update acks
    if (receivedSequence < remoteSequence) remoteSequence = receivedSequence;
    // TODO: update acks

    return target;
}


////////////////////////////////////////////////////////////
void Connection::writeFooter(){
    // 1 byte for message type
    packet << static_cast<sf::Uint8>(MessageType::PacketEnd);
    packet <<
}


////////////////////////////////////////////////////////////
unsigned int Connection::readFooter(sf::Packet& packet){
    // TODO acks and that stuff
}


////////////////////////////////////////////////////////////
sf::Uint32 Connection::getProtocolId(){
    return protocolId;
}


////////////////////////////////////////////////////////////
void Connection::setProtocolId(sf::Uint32 protocolId){
    this->protocolId = protocolId;
}


////////////////////////////////////////////////////////////
void Connection::setReceiver(Receiver& receiver){
    Connection::receiver = receiver;
}


} //namespace rn
