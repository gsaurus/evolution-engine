////////////////////////////////////////////////////////////
//
// EvE - Evolution Engine
// Copyright (C) 2011 Gil Costa (gsaurus@gmail.com)
//
// TODO: License here
//
////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////
// Headers
////////////////////////////////////////////////////////////
#include <Renet/Station.hpp>
#include <Renet/Connection.hpp>

#include <algorithm>
#include <cstdio>

namespace rn{


////////////////////////////////////////////////////////////
Station::Station(Receiver& receiver, unsigned int protocolId, unsigned int packetTime, unsigned int timeout):
    receiver(receiver), protocolId(protocolId),
    packetTime(packetTime), timeOut(timeOut),
    running(false), thread(NULL)
{
    if (singleton){
        // TODO: error (exception in ctr? I think so)
    } else{
        singleton = true;
    }
}


////////////////////////////////////////////////////////////
Station::~Station(){

    // stop thread
    stop();

    // delete connections
    std::vector<Connection*>::iterator it;
    for(it = connections.begin() ; it != connections.end() ; ++it){
        delete *it;
    }
    connections.clear();
    singleton = false;
}


////////////////////////////////////////////////////////////
void Station::stop(){
    if (thread){
        running = false; // TODO: use mutex?
        delete thread;
    }
}


////////////////////////////////////////////////////////////
bool Station::start(unsigned short port){

    // if the network is running, stop it
    stop();

    // Get the ip of this station. If it reach the timeout, return failure
    myIp = sf::IpAddress::GetPublicAddress(timeout);
    if (myIp == sf::IpAddress::None) return false;

    // Bind socket to the desired port
    if (socket.Bind(port) == sf::Socket::Error)
        return false;

    // Launch the network thread
    running = true;
    thread = new Thread(&Station::run, *this);
    thread.Launch();

    return true;

}


////////////////////////////////////////////////////////////
void Station::connectTo(const sf::IpAddress& ip){
    // TODO:
}


////////////////////////////////////////////////////////////
void Station::run(){
    sf::Clock clock;             // clock to count time
    sf::SocketSelector selector; // selector to wait on the socket
    selector.AddSocket(socket);

    int timeLeft;   // time to wait until send next packets

    while(running){

        timeLeft = packetTime - clock.GetElapsedTime();

        // Listen for incomming packets
        do{
            if (selector.Wait( static_cast<sf::Uint32>(std::max(timeLeft, 0)) ){
                sf::Packet packet;
                if (socket.Receive(packet) == sf::Socket::Done){
                    Connection::processPacket(packet);
                }
            }
            timeLeft -= clock.GetElapsedTime();
            clock.Reset();
        }while( timeLeft > 0);

        // Send cached data
        std::vector<Connection*>::iterator it;
        for(it = connections.begin() ; it != connections.end() ; ++it){
            if (it->transmit(socket) != sf::Socket::Done){
                // TODO: I disconected myself, I think
                // we will stop at least
                break;
            }
        }

}


} //namespace rn









 ENetEvent event;

/* Wait up to 1000 milliseconds for an event. */
while (enet_host_service (client, & event, 1000) > 0)
{
    switch (event.type)
    {
    case ENET_EVENT_TYPE_CONNECT:
        printf ("A new client connected from %x:%u.\n",
                event.peer -> address.host,
                event.peer -> address.port);

        /* Store any relevant client information here. */
        event.peer -> data = "Client information";

        break;

    case ENET_EVENT_TYPE_RECEIVE:
        printf ("A packet of length %u containing %s was received from %s on channel %u.\n",
                event.packet -> dataLength,
                event.packet -> data,
                event.peer -> data,
                event.channelID);

        /* Clean up the packet now that we're done using it. */
        enet_packet_destroy (event.packet);

        break;

    case ENET_EVENT_TYPE_DISCONNECT:
        printf ("%s disconected.\n", event.peer -> data);

        /* Reset the peer's client information. */

        event.peer -> data = NULL;
    }
}
