////////////////////////////////////////////////////////////
//
// EvE - Evolution Engine
// Copyright (C) 2011 Gil Costa (gsaurus@gmail.com)
//
// TODO: License here
//
////////////////////////////////////////////////////////////

#ifndef EVE_ENET_CONNECTION_BASE_HPP
#define EVE_ENET_CONNECTION_BASE_HPP

////////////////////////////////////////////////////////////
// Headers
////////////////////////////////////////////////////////////
#include <SFML/System.hpp>
#include <enet/enet.h>
#include <vector>

namespace eve{

////////////////////////////////////////////////////////////
/// \brief Manages providers.
///
////////////////////////////////////////////////////////////
class EnetConnectionBase{


////////////////////////////////////////////////////////////
// Data Structures
////////////////////////////////////////////////////////////

protected:

    struct Connection{
        ENetPeer* peer;         ///< Information about the connected peer
        std::vector<char> data; ///< Data buffered to be sent in channel 0
        std::vector<char> secondaryData; ///< Data buffered to be sent in channel 1
    };


////////////////////////////////////////////////////////////
// Functions
////////////////////////////////////////////////////////////

public:

    ////////////////////////////////////////////////////////////
    /// \brief
    ///
    ////////////////////////////////////////////////////////////
    EnetConnectionBase();

    void run();

protected:

    void startThread(unsigned int packetsRate);

    void stopThread();

    void destroyHost();

    static bool initialize();

    static void send(Connection& connection, const char* data, std::size_t size, bool priority);

    static unsigned int getPing(const Connection& connection);

    static void destroyConnection(Connection& connection);

    static void sendCachedData(Connection& connection);

private:

    void forwardEvent(ENetEvent& event);
    virtual void onConnectEvent(ENetEvent& event) = 0;
    virtual void onDisconnectEvent(ENetEvent& event) = 0;
    virtual void onReceiveDataEvent(ENetEvent& event) = 0;

    virtual bool isNetworkRunning() = 0;


    virtual void disconnectPeers() = 0;

    virtual void destroyConnections() = 0;

    virtual void sendCachedData() = 0;

    static void sendPacket(ENetPeer* peer, std::vector<char>& data, unsigned int channel);


////////////////////////////////////////////////////////////
// Member data
////////////////////////////////////////////////////////////
protected:

    ENetHost* host;              ///< ENet Host

private:

    static bool isEnetInitiated; ///< Flag telling if ENet was already initialized
    unsigned int packetsRate;    ///< Miliseconds between each packet send
    sf::Thread* thread;          ///< Client thread to send/receive packets

};

}   // namespace eve

#endif // EVE_ENET_CLIENT_HPP
