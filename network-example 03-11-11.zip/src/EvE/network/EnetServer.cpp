////////////////////////////////////////////////////////////
//
// EvE - Evolution Engine
// Copyright (C) 2011 Gil Costa (gsaurus@gmail.com)
//
// TODO: License here
//
////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////
// Headers
////////////////////////////////////////////////////////////
#include <EvE/Network/EnetServer.hpp>
#include <EvE/Network/ServerListener.hpp>
#include <cstring>
#include <cstdio>


namespace eve{


////////////////////////////////////////////////////////////
EnetServer::EnetServer(ServerListener& listener):
    Server(listener) // super class init
{
    // Nothing to do
}


////////////////////////////////////////////////////////////
//EnetServer::~EnetServer(){
//
//}


////////////////////////////////////////////////////////////
bool EnetServer::onStart(
        unsigned int port,
        unsigned int maxClients,
        unsigned int packetsRate
){
    // Global ENet initialization
    if ( !initialize() ) return false;

    // ENet server initialization
    if ( !enetServerInitialization(port, maxClients) ){
        // Failure, finalize server
        destroyHost();
        return false;
    }

    // Server ready, launch the thread
    connections.reserve(maxClients);
    startThread(packetsRate);

    // Server successfully started
    return true;
}


////////////////////////////////////////////////////////////
bool EnetServer::enetServerInitialization(unsigned int port, unsigned int maxClients){
    ENetAddress address;
    address.host = ENET_HOST_ANY; // localhost
    address.port = port;          // bind to the specified port
    host = enet_host_create(&address, maxClients, 2, 0, 0);
    if (host == NULL){
        fprintf (stderr, "ENet server initialization failed.\n");
        return false;
    }
    return true;
}


////////////////////////////////////////////////////////////
void EnetServer::onStop(){
    destroyHost();
}


////////////////////////////////////////////////////////////
void EnetServer::disconnectPeers(){

    std::vector<Connection>::iterator it;
    for (it = connections.begin() ; it != connections.end() ; ++it){
        Connection& c = *it;
        if (c.peer) enet_peer_disconnect(c.peer, NULL);
    }
}


void EnetServer::destroyConnections(){
    std::vector<Connection>::iterator it;
    for (it = connections.begin() ; it != connections.end() ; ++it){
        destroyConnection(*it);
    }
    std::vector<Connection>().swap(connections);
}


////////////////////////////////////////////////////////////
void EnetServer::sendCachedData(){
    // Send cached data for every connection
    for(unsigned int i = 0 ; i < connections.size() ; ++i){
        EnetConnectionBase::sendCachedData(connections[i]);
    }
}


////////////////////////////////////////////////////////////
void EnetServer::onConnectEvent(ENetEvent& event){
    unsigned int id = addPeer(event.peer);
    listener.onConnectionRequest(id, ipAsString(event.peer->address));
}


////////////////////////////////////////////////////////////
void EnetServer::onDisconnectEvent(ENetEvent& event){
    unsigned int id = readPeerId(event.peer);
    // Reset peer
    destroyConnection(connections[id]);
    listener.onConnectionLost(id);
}


////////////////////////////////////////////////////////////
void EnetServer::onReceiveDataEvent(ENetEvent& event){
    unsigned int id = readPeerId(event.peer);
    listener.onDataReceived(id, reinterpret_cast<char*>(event.packet->data), event.packet->dataLength, event.channelID == 0);
    // clean packet after using it
    enet_packet_destroy (event.packet);
}


////////////////////////////////////////////////////////////
unsigned int EnetServer::addPeer(ENetPeer* peer){
    unsigned int id;
    for (id = 0 ; id < connections.size() && connections[id].peer != NULL; ++id);
    if (id == connections.size())
        connections.push_back(Connection());
    connections[id].peer = peer;
    writePeerId(peer, id);
    return id;
}



////////////////////////////////////////////////////////////
std::string EnetServer::ipAsString(const ENetAddress& ip){
    char ipName[15];
    enet_address_get_host_ip(&ip, ipName, 15);
    return std::string(ipName);
}


////////////////////////////////////////////////////////////
unsigned int EnetServer::readPeerId(const ENetPeer* peer){
    if (peer->data == NULL) return 0;
    return *static_cast<unsigned char*>(peer->data);
}


////////////////////////////////////////////////////////////
void EnetServer::writePeerId(ENetPeer* peer, unsigned int id){
    if (peer->data == NULL) peer->data = malloc(1);
    *static_cast<unsigned char*>(peer->data) = static_cast<unsigned char>(id);
}


////////////////////////////////////////////////////////////
void EnetServer::send(unsigned int clientId, const char* data, std::size_t size, bool priority){
    EnetConnectionBase::send(connections[clientId], data, size, priority);
}


////////////////////////////////////////////////////////////
unsigned int EnetServer::getPing(unsigned int clientId) const{
    return EnetConnectionBase::getPing(connections[clientId]);
}


////////////////////////////////////////////////////////////
bool EnetServer::isNetworkRunning(){
    return isRunning();
}


} //namespace eve
