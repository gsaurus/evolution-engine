////////////////////////////////////////////////////////////
//
// EvE - Evolution Engine
// Copyright (C) 2011 Gil Costa (gsaurus@gmail.com)
//
// TODO: License here
//
////////////////////////////////////////////////////////////

#ifndef EVE_ENET_SERVER_HPP
#define EVE_ENET_SERVER_HPP

////////////////////////////////////////////////////////////
// Headers
////////////////////////////////////////////////////////////
#include <EvE/Network/Server.hpp>
#include <EvE/Network/EnetConnectionBase.hpp>
#include <SFML/System.hpp>
#include <enet/enet.h>
#include <vector>

namespace eve{

////////////////////////////////////////////////////////////
/// \brief Manages providers.
///
////////////////////////////////////////////////////////////
class EnetServer: public Server, private EnetConnectionBase{

public:

    ////////////////////////////////////////////////////////////
    /// \brief
    ///
    ////////////////////////////////////////////////////////////
    EnetServer(ServerListener& listener);

    void send(unsigned int clientId, const char* data, std::size_t size, bool priority = true);

    unsigned int getPing(unsigned int clientId) const;


private:

    bool onStart(
            unsigned int port,
            unsigned int maxClients,
            unsigned int packetsRate
    );

    void onStop();

    bool enetServerInitialization(unsigned int port, unsigned int maxClients);

    unsigned int addPeer(ENetPeer* peer);

    void onConnectEvent(ENetEvent& event);
    void onDisconnectEvent(ENetEvent& event);
    void onReceiveDataEvent(ENetEvent& event);

    void disconnectPeers();

    void destroyConnections();

    void sendCachedData();

    bool isNetworkRunning();

    static std::string ipAsString(const ENetAddress& ip);

    static unsigned int readPeerId(const ENetPeer* peer);

    static void writePeerId(ENetPeer* peer, unsigned int id);


////////////////////////////////////////////////////////////
// Member data
////////////////////////////////////////////////////////////

private:

    std::vector<Connection> connections; ///< List of connected peers and their outgoing packets

};

}   // namespace eve

#endif // EVE_ENET_SERVER_HPP
