////////////////////////////////////////////////////////////
//
// EvE - Evolution Engine
// Copyright (C) 2011 Gil Costa (gsaurus@gmail.com)
//
// TODO: License here
//
////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////
// Headers
////////////////////////////////////////////////////////////
#include <EvE/Network/EnetClient.hpp>
#include <EvE/Network/ClientListener.hpp>
#include <cstring>
#include <cstdio>


namespace eve{


////////////////////////////////////////////////////////////
EnetClient::EnetClient(ClientListener& listener):
    Client(listener), // super class init
    client(NULL),     // no ENet client yet
    thread(NULL)
{
    // Nothing to do
}


////////////////////////////////////////////////////////////
//EnetClient::~EnetClient(){
//
//}


////////////////////////////////////////////////////////////
bool EnetClient::onConnectionRequest(
            const std::string& ip,
            unsigned int port,
            unsigned int packetsRate
){
    // Global ENet initialization
    if ( !initialize() ) return false;

    // ENet server initialization
    if ( !enetClientInitialization(ip, port) ){
        // Failure, finalize client
        destroyHost();
        return false;
    }

    // Client ready, launch the thread
    startThread(packetsRate);

    // Client successfully started
    return true;
}


////////////////////////////////////////////////////////////
bool EnetClient::enetClientInitialization(const std::string& ip, unsigned int port){
    // Create ENet client
     host = enet_host_create (NULL, 1, 2, 0, 0);
    if (host == NULL){
        fprintf(stderr, "ENet client initialization failed.\n");
        return false;
    }

    // Connection request
    ENetAddress address;
    enet_address_set_host( &address, ip.c_str() );
    address.port = port;
    server.peer = enet_host_connect( host, &address, 2, 0 );
    if (server.peer == NULL){
        fprintf(stderr, "No available peers for initiating an ENet connection to the server.\n");
        return false;
    }
    enet_host_flush(host);
    return true;
}


////////////////////////////////////////////////////////////
void EnetClient::onDisconnect(){
    destroyHost();
}


////////////////////////////////////////////////////////////
void EnetClient::disconnectPeers(){
    if (server.peer) enet_peer_disconnect(server.peer, NULL);
}


////////////////////////////////////////////////////////////
void EnetClient::destroyConnections(){
    destroyConnection(server);
}


void EnetClient::sendCachedData(){
    EnetConnectionBase::sendCachedData(server);
}


////////////////////////////////////////////////////////////
void EnetClient::onConnectEvent(ENetEvent& event){
    server.peer = event.peer;
    connectionAccepted();
}


////////////////////////////////////////////////////////////
void EnetClient::onDisconnectEvent(ENetEvent& event){
    // Reset peer
    connectionLost();
    destroyConnection(server);
}


////////////////////////////////////////////////////////////
void EnetClient::onReceiveDataEvent(ENetEvent& event){
    listener.onDataReceived(reinterpret_cast<char*>(event.packet->data), event.packet->dataLength, event.channelID == 0);
    // clean packet after using it
    enet_packet_destroy (event.packet);
}


////////////////////////////////////////////////////////////
void EnetClient::send(const char* data, std::size_t size, bool priority){
    EnetConnectionBase::send(server, data, size, priority);
}


////////////////////////////////////////////////////////////
unsigned int EnetClient::getPing() const{
    return EnetConnectionBase::getPing(server);
}


////////////////////////////////////////////////////////////
bool EnetClient::isNetworkRunning(){
    return isRunning();
}


} //namespace eve
