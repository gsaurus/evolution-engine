////////////////////////////////////////////////////////////
//
// EvE - Evolution Engine
// Copyright (C) 2011 Gil Costa (gsaurus@gmail.com)
//
// TODO: License here
//
////////////////////////////////////////////////////////////

#ifndef EVE_ENET_CLIENT_HPP
#define EVE_ENET_CLIENT_HPP

////////////////////////////////////////////////////////////
// Headers
////////////////////////////////////////////////////////////
#include <EvE/Network/Client.hpp>
#include <EvE/Network/EnetConnectionBase.hpp>
#include <SFML/System.hpp>
#include <enet/enet.h>
#include <vector>

namespace eve{

////////////////////////////////////////////////////////////
/// \brief Manages providers.
///
////////////////////////////////////////////////////////////
class EnetClient: public Client, private EnetConnectionBase{

public:

    ////////////////////////////////////////////////////////////
    /// \brief
    ///
    ////////////////////////////////////////////////////////////
     EnetClient(ClientListener& listener);

//    ~EnetClient();

    void run();

    void send(const char* data, std::size_t size, bool priority = true);

    unsigned int getPing() const;


private:

    bool onConnectionRequest(
            const std::string& ip,
            unsigned int port,
            unsigned int packetsRate
    );

    void onDisconnect();

    void disconnectPeers();

    void destroyConnections();

    bool enetClientInitialization(const std::string& ip, unsigned int port);

    void sendCachedData();

    void onConnectEvent(ENetEvent& event);
    void onDisconnectEvent(ENetEvent& event);
    void onReceiveDataEvent(ENetEvent& event);

    void resetServer();

    bool isNetworkRunning();


////////////////////////////////////////////////////////////
// Member data
////////////////////////////////////////////////////////////

private:

    Connection server;           ///< connection to server
    unsigned int packetsTime;    ///< Miliseconds between each packet send

    ENetHost* client;            ///< ENet Client
    sf::Thread* thread;          ///< Client thread to send/receive packets

};

}   // namespace eve

#endif // EVE_ENET_CLIENT_HPP
