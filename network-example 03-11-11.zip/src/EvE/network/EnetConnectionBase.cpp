////////////////////////////////////////////////////////////
//
// EvE - Evolution Engine
// Copyright (C) 2011 Gil Costa (gsaurus@gmail.com)
//
// TODO: License here
//
////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////
// Headers
////////////////////////////////////////////////////////////
#include <EvE/Network/EnetConnectionBase.hpp>
#include <cstring>
#include <cstdio>


namespace eve{


bool EnetConnectionBase::isEnetInitiated = false;


////////////////////////////////////////////////////////////
EnetConnectionBase::EnetConnectionBase():
    host(NULL),
    thread(NULL)
{
    // Nothing to do
}


////////////////////////////////////////////////////////////
bool EnetConnectionBase::initialize(){
    if (!isEnetInitiated){
        // initialize ENet
        if (enet_initialize() != 0){
            fprintf (stderr, "ENet initialization failed\n");
            return false;
        }
        atexit(enet_deinitialize);
        isEnetInitiated = true;
    }
    return true;
}


////////////////////////////////////////////////////////////
void EnetConnectionBase::startThread(unsigned int packetsRate){
    stopThread(); // if a thread is previously running, stop it
    this->packetsRate = packetsRate;
    thread = new sf::Thread(&EnetConnectionBase::run, this);
    thread->Launch();
}


////////////////////////////////////////////////////////////
void EnetConnectionBase::stopThread(){
    if (thread){
        thread->Wait();
        delete thread;
        thread = NULL;
    }
}


////////////////////////////////////////////////////////////
void EnetConnectionBase::destroyHost(){

    // stop thread
    stopThread();

    // get rid of peer(s)
    disconnectPeers();
    enet_host_flush(host);

    // destroy host
    if (host){
        enet_host_destroy(host);
        host = NULL;
    }

    // destroy peers
    destroyConnections();
}


////////////////////////////////////////////////////////////
void EnetConnectionBase::destroyConnection(Connection& connection){
    if (connection.peer){
        enet_peer_reset(connection.peer);
        if (connection.peer->data){
            free(connection.peer->data);
            connection.peer->data = NULL;
        }
        connection.peer = NULL;
        connection.data.clear();
        connection.secondaryData.clear();
    }
}

////////////////////////////////////////////////////////////
void EnetConnectionBase::send(Connection& connection, const char* data, std::size_t size, bool priority){
    if (data && size >0 && connection.peer){
        std::vector<char>* packet;
        if (priority) packet = &connection.data;
        else packet = &connection.secondaryData;
        std::size_t start = packet->size();
        packet->resize(start + size);
        std::memcpy(&((*packet)[start]), data, size);
    }
}


////////////////////////////////////////////////////////////
unsigned int EnetConnectionBase::getPing(const Connection& connection){
    if (connection.peer){
        return connection.peer->roundTripTime;
    }else{
        fprintf (stderr, "Requesting ping from a disconnected peer.\n");
        return 0;
    }
}


////////////////////////////////////////////////////////////
void EnetConnectionBase::run(){
    sf::Clock clock; // clock to count time
    ENetEvent event; // incomming events

    int timeLeft;    // time to wait until send next packets

    while( isNetworkRunning() ){ // TODO: isRunning...

        timeLeft = packetsRate - clock.GetElapsedTime();

        // Listen for incomming packets
        do{
            if (enet_host_service(host, &event, static_cast<enet_uint32>(std::max(timeLeft, 0)) > 0) ){
                forwardEvent(event);
            }
            timeLeft -= clock.GetElapsedTime();
            clock.Reset();
        }while( timeLeft > 0);

        // Send cached data
        sendCachedData();
        enet_host_flush(host);
    }
}


////////////////////////////////////////////////////////////
void EnetConnectionBase::forwardEvent(ENetEvent& event){
    switch (event.type){
        case ENET_EVENT_TYPE_RECEIVE:
            onReceiveDataEvent(event);
            break;
        case ENET_EVENT_TYPE_CONNECT:
            onConnectEvent(event);
            break;
        case ENET_EVENT_TYPE_DISCONNECT:
            onDisconnectEvent(event);
            break;
        default: break; // supress warning
    }
}


////////////////////////////////////////////////////////////
void EnetConnectionBase::sendCachedData(Connection& connection){
    if ( connection.peer ){
        if( !connection.data.empty() )
            sendPacket(connection.peer, connection.data, 0);
        if( !connection.secondaryData.empty() )
            sendPacket(connection.peer, connection.secondaryData, 1);
    }
}


////////////////////////////////////////////////////////////
void EnetConnectionBase::sendPacket(ENetPeer* peer, std::vector<char>& data, unsigned int channel){
    // create ENet Packet
    ENetPacket* packet = enet_packet_create(
            &data[0],
            data.size(),
            ENET_PACKET_FLAG_RELIABLE
    );
    // send it
    enet_peer_send(peer, channel, packet);
    // clear buffer
    data.clear();
}


} //namespace eve
