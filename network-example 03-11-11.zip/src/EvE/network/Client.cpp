////////////////////////////////////////////////////////////
//
// EvE - Evolution Engine
// Copyright (C) 2011 Gil Costa (gsaurus@gmail.com)
//
// TODO: License here
//
////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////
// Headers
////////////////////////////////////////////////////////////
#include <EvE/Network/Client.hpp>
#include <EvE/Network/ClientListener.hpp>
#include <EvE/Network/EnetClient.hpp>

namespace eve{


////////////////////////////////////////////////////////////
Client* Client::create(ClientListener& listener){
    return new EnetClient(listener);
}


////////////////////////////////////////////////////////////
Client::Client(ClientListener& listener):
    listener(listener),
    running(false),
    connected(false)
{
    // Nothing to do
}


////////////////////////////////////////////////////////////
Client::~Client(){
    disconnect();
}


////////////////////////////////////////////////////////////
bool Client::connectionRequest(
        const std::string& ip,
        unsigned int port,
        unsigned int packetTime
){
    disconnect();
    running = onConnectionRequest(ip, port, packetTime);
    return running;
}


////////////////////////////////////////////////////////////
void Client::disconnect(){
    if (running){
        running = connected = false;
        onDisconnect();
    }
}


////////////////////////////////////////////////////////////
bool Client::isRunning() const{
    return running;
}


////////////////////////////////////////////////////////////
bool Client::isConnected() const{
    return running && connected;
}


////////////////////////////////////////////////////////////
void Client::connectionAccepted(){
    connected = true;
    listener.onConnectionEstablished();
}


////////////////////////////////////////////////////////////
void Client::connectionLost(){
    if (running){
        listener.onConnectionLost();
        running = connected = false;
    }
}



} //namespace eve
